﻿#ifndef __DRV_4G_DEV_H__
#define __DRV_4G_DEV_H__

#include <socket4g/sock4glib.h>


#ifdef __cplusplus
extern "C" {
#endif

bool Initial4GDev(const char *path, char *simid);
void BeginParse(void);
void ParseRcvBuff(void);
void ResetRcvBuff(void);
short Create4GSock(short sock);
bool Connect4G(int id, const char *host, unsigned short port);
bool Close4GSock(int id);
int Send4G(int sock, char *buff, int len);
int Recv4G(int sock, char *buf, unsigned len);
Status4G Get4gStat(int sock);
void Close4G(void);
bool GetSimId(void);
bool ParseSimId(char *buff, unsigned len);

#ifdef __cplusplus
}
#endif

#endif //__DRV_4G_DEV_H__
