﻿
#include "drv4gdev.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#if defined _WIN32 || defined WIN64
#include <windows.h>
#include "sysfunc.h"
#else
#include <drivers/drv_hrt.h>
#include <board_config.h>
#include <stm32_gpio.h>
#include <px4_time.h>
#include <px4_log.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#define INVALID_HANDLE_VALUE -1
#endif

#if defined _WIN32 || defined WIN64
FILE *s_log = NULL;
#ifdef PX4_WARN
#undef PX4_WARN
#define PX4_WARN(fmt, ...) unexpectLog(s_log, fmt, ##__VA_ARGS__)
#endif
#endif

#define INVALIDIP 0xffffffff
#define MaxSockCom 8
#define MaxSinIDLen 20

enum {
    CMD_AT = 0,         //at命令通道
    CMD_ATE0,           //关闭回显
    CMD_AT_CPIN,        //有无SIM
    CMD_AT_SIMID,       //读SIMID
    CMD_AT_CREG,        //有无服务
    CMD_AT_CSQ,         //信号强度
    CMD_AT_CIPMODE0,    //数据传输模式0:AT 1:透传
    CMD_AT_CIPRXGET,    //设置接收数据读取方式 0为数据自动输出，1为指令输出
    CMD_AT_NETOPEN,     //打开NET网络
    CMD_AT_NETCLOSE,    //关闭NET网络
    CMD_AT_CIPOPEN,     //连接
    CMD_AT_DNSIP,     	//DNS解析
    CMD_AT_CIPSEND,     //发送数据准备AT+CIPSEND=<socketid>,<data len>
    CMD_AT_CIPCLOSE,    //关闭tcp链路AT+CIPCLOSE=<socketid>
    CMD_AT_CRESET,      //reset
    CMD_AT_INQNET,      //查询4G
    CMD_DONE,
    CMD_AT_COUNT = CMD_DONE,
};

enum {
    TMOUT_ATE0 = 40,
    TMOUT_CPIN = 40,
    TMOUT_SIMID = 40,
    TMOUT_CREG = 40,
    TMOUT_CSQ = 400,
    TMOUT_NETOPEN = 20000,
    TMOUT_NECLOSE = 1600,
    TMOUT_CONNECT = 4000,
    TMOUT_DNS = 3000,
    TMOUT_SENDECHO = 100,
    TMOUT_SENDBUFF = 3500,
    TMOUT_CLOSE = 1000,
    TMOUT_RESET = 60000,
    TMOUT_CSQINV = 5000,
};

///////////////// AT命令执行后的返回标识/////////////////
#define OK_FLAG    		   "OK\r\n"  //初始化设备
#define SMS_DONE            "SMS DONE\r\n"
#define INITDONE_FLAG       "PB DONE\r\n"       //初始化设备正常返回
#define INITDONE_FLAG_LEN   9
#define SERVER_FLAG    	    "+CREG: 0"         //有服务正常返回
#define NETOPENED_FLAG      "+NETOPEN:"        //打开网络正常返回
#define NETOPENED_FLAG_LEN  9
#define NETCLOSED_FLAG      "+NETCLOSE:"
#define SIM_FLAG            "+CPIN: READY\r\n"  //SIM正常返回
#define SIM_FLAG_LEN        14
#define SIMID_FLAG            "+ICCID: "  	//SIMID正常返回
#define SIMID_FLAG_LEN        8
#define SIGSTR_FLAG         "+CSQ: "            //信号强度
#define SIGSTR_FLAG_LEN     6
#define CONNECTED_FLAG      "+CIPOPEN: "        //TCP连接返回
#define CONNECTED_FLAG_LEN  10
#define NDSIP_FLAG          "+CDNSGIP:"         //dns解析返回
#define NDSIP_FLAG_LEN  	9
#define SENDRDY_FLAG 	    ">"                 //发送数据就绪
#define SENDRDY_FLAG_LEN 	1
#define SENDED_FLAG         "+CIPSEND:"         //发送数据返回
#define SENDED_FLAG_LEN     9
#define RECV_FLAG 	        "RECV FROM:"        //接收数据
#define RECV_FLAG_LEN 	    10
#define RECVLEN_FLAG        "+IPD"
#define RECVLEN_FLAG_LEN    4
#define CLOSEDNTF_FLAG 	    "+IPCLOSE:"        //端口关闭通知
#define CLOSEDNTF_FLAG_LEN 	9
#define CLOSED_FLAG 	    "+CIPCLOSE:"        //关闭端口返回
#define CLOSED_FLAG_LEN     10
#define ERROR_FLAG          "ERROR\r\n"
#define ERROR_FLAG_LEN      7
#define RETURN_FLAG         "\r\n"
#define RETURN_FLAG_LEN     2
#define CONNCTERR_FLAG      "+CIPERROR:"
#define CONNCTERR_FLAG_LEN  10

typedef struct _tagSock{
    bool            used : 1;
    bool            sending : 1;
    short           stat : 14;
    unsigned short  port;
    unsigned        ip;
}Sock4GInfo;

static char s_buffCmd[64];
typedef struct _socks {
    Sock4GInfo  socks[MaxSockCom];
    uint8_t     bCsq:4;
    uint8_t     sockCur:4;
    short       sockCurRcv:4;
    uint32_t    remaind:20;
    char        *simId;
}SockInfos;

SockInfos s_sockInfos = {0};

const char *s_atCmd[CMD_AT_COUNT] = {
    "AT\r\n",
    "ATE0\r\n",
    "AT+CPIN?\r\n",
    "AT+CICCID\r\n",
    "AT+CREG?\r\n",
    "AT+CSQ\r\n",
    "AT+CIPMODE=0\r\n",	                    //数据传输模式0:AT 1:透传
    "AT+CIPRXGET=0\r\n",                    //设置接收数据读取方式 0为数据自动输出，1为指令输出		
    "AT+NETOPEN\r\n",	                    //打开NET网络
    "AT+NETCLOSE\r\n",                      //
    "AT+CIPOPEN=%d,\"TCP\",\"%s\",%d\r\n",  //AT+CIPOPEN=<socketid>,"TCP","<IP>",<port>
    "AT+CDNSGIP=\"%s\"\r\n",	            //dns解析，如AT+CDNSGIP="www.baidu.com"
    "AT+CIPSEND=%d,%d\r\n",                 //发送数据准备AT+CIPSEND=<socketid>,<data len>
    "AT+CIPCLOSE=%d\r\n", 	                //关闭
    "AT+CRESET\r\n",                        //reset
    "AT+NETOPEN?\r\n"                       //inquiry 4G is opened
};

static int s_curCmd = -1;
#if defined WIN32 || defined WIN64
static HANDLE s_file = INVALID_HANDLE_VALUE;
#else
static int s_file = INVALID_HANDLE_VALUE;
#endif

static char s_rcvBuff[512] = { 0 };
static char *s_sndBuff = NULL;
static unsigned short s_szBuffRcv = 0;
static unsigned short s_szBuffSnd = 0;
static unsigned short s_szBuffParsed = 0;
static unsigned s_tmLastCmd = 0;
static unsigned s_tmFirstCsq = 0;

static void resetDev(void);
static int write2Dev(const char *buff, int len);
static void setParsed(int nPos);
static int getSockinfoByIPAndPort(unsigned ip, unsigned short port);
static Sock4GInfo *getSockinfoBySock(int sock);
static int getUnusedSock(void);
static void parseClosEcho(void);
static void parseCPin(void);
static void parseSimId(void);
static void parseCsqValid(void);
static void parseServer(void);
static int parseOpenNetResult(void);
static void parseOpenNet(void);
static void parseConnect(void);
static void parseDNSIP(void);
static void parseSending(void);
static int parseRecvSock(int pos, int *packLen, int *beg, int *packBeg);
static int prcsRemain(short sock, char *buff, int len);
static bool parseClose(bool bNtf);
static void parseReset(void);
static void parseInqNet(void);
static bool check4G(void);
static bool isConnect(short st);

#if !defined _WIN32 && !defined WIN64
static void gpio_sim76_rst (bool st);
static void gpio_sim76_pwrkey(bool st);
#endif
static bool SendCmd(const char *buff, int cmd);
static void PrcsNormalUnexpect(short curCmd, unsigned, unsigned);
static bool PrcsSendUnexpect(Sock4GInfo *info, unsigned);
static bool UnexpectPrcs (short sock, short curCmd);

#if !defined _WIN32 && !defined WIN64
static void gpio_sim76_rst (bool st)
{
	stm32_configgpio(GPIO_REST_PB15);
	if(st)
		stm32_gpiowrite(GPIO_REST_PB15, 0);
	else
		stm32_gpiowrite(GPIO_REST_PB15, 1);
}

static void gpio_sim76_pwrkey (bool st)
{
	stm32_configgpio(GPIO_PWRKEY_PB14);	
	if(st)
		stm32_gpiowrite(GPIO_PWRKEY_PB14, 0);
	else
		stm32_gpiowrite(GPIO_PWRKEY_PB14, 1);
}
#endif

///////////////////////////////////////////////////////////
//设备读/写/初始化
///////////////////////////////////////////////////////////
static int write2Dev(const char *buff, int len)
{
    if (len <= 0)
        return 0;
	
    if (s_file == INVALID_HANDLE_VALUE)
        return 0;
#if defined WIN32 || defined WIN64
    DWORD nW;
    WriteFile(s_file, buff, len, &nW, NULL);
    fwrite(buff, 1, len, s_log);
    return nW;
#else
	
    return write(s_file, buff, len);
#endif
}

//////////////////////////////////////////////////
//Unexpect
//////////////////////////////////////////////////
static void PrcsNormalUnexpect(short curCmd, unsigned maxTmOut, unsigned tmCur)
{
    if (tmCur >= maxTmOut)
    {
        if (curCmd == CMD_AT_CRESET)
            resetDev();
        else
            SendCmd(s_atCmd[curCmd], curCmd);
    }
}

static bool PrcsSendUnexpect(Sock4GInfo *info, unsigned tmTimeout)
{
    if (!info)
        return false;
    if (info->sending && s_szBuffSnd > 0)
    {
        int tmpW = write2Dev(s_sndBuff, s_szBuffSnd);
		s_szBuffSnd -= tmpW;
		if (s_szBuffSnd > 0)
			memcpy(s_sndBuff, s_sndBuff+tmpW, s_szBuffSnd);
		
        s_tmLastCmd = hrt_absolute_time() / 1000 ;
		return false;
    }
		
    if ( (!info->sending && tmTimeout < TMOUT_SENDECHO)
      || (info->sending && tmTimeout < TMOUT_SENDBUFF) )
        return false;

    if (s_szBuffSnd > 0 && !info->sending)
    {
        sprintf(s_buffCmd, s_atCmd[CMD_AT_CIPSEND], s_sockInfos.sockCur, s_szBuffSnd);
        info->stat = Sock_Sending;
        info->sending = false;
        SendCmd(s_buffCmd, CMD_AT_CIPSEND);
        return false;
    }

    if (info && 0==s_szBuffSnd)
    {
        PX4_WARN("Unexpect send time out!!!");
        info->stat = Sock_SendFail;
        return check4G();
    }
    return false;
}
static bool UnexpectPrcs (short sock, short curCmd)
{
    Sock4GInfo *info = getSockinfoBySock(sock);
    bool ret = false;
    unsigned tmPassLastCmd = hrt_absolute_time() / 1000 - s_tmLastCmd;
    switch (curCmd)
    {
    case CMD_ATE0:
	    PrcsNormalUnexpect(curCmd, TMOUT_ATE0, tmPassLastCmd);
        break;
    case CMD_AT_CPIN:
	    PrcsNormalUnexpect(curCmd, TMOUT_CPIN, tmPassLastCmd);
        break;
    case CMD_AT_SIMID:
	    PrcsNormalUnexpect(curCmd, TMOUT_SIMID, tmPassLastCmd);
        break;
    case CMD_AT_CREG:
	    PrcsNormalUnexpect(curCmd, TMOUT_CREG, tmPassLastCmd);
        break;
    case CMD_AT_CSQ:
	    PrcsNormalUnexpect(curCmd, TMOUT_CSQ, tmPassLastCmd);
        break;
    case CMD_AT_NETCLOSE:
	    PrcsNormalUnexpect(curCmd, TMOUT_NECLOSE, tmPassLastCmd);
        break;
    case CMD_AT_NETOPEN:
	    PrcsNormalUnexpect(curCmd, TMOUT_NETOPEN, tmPassLastCmd);
        break;
    case CMD_AT_CIPOPEN:
        if (tmPassLastCmd < TMOUT_CONNECT)
            return ret;
        if (info)
            info->stat = Sock_ConnectErr;
        ret = check4G();
        break;
    case CMD_AT_DNSIP:
        if (tmPassLastCmd >= TMOUT_DNS)
            return ret;
        if (info)
            info->stat = Sock_ConnectErr;
        ret = check4G();
        break;
    case CMD_AT_CIPSEND:
        ret = PrcsSendUnexpect(info, tmPassLastCmd);
        break;
    case CMD_AT_CIPCLOSE:
        if (tmPassLastCmd < TMOUT_CLOSE)
            return ret;
        if (info)
            info->stat = Sock_Closed;
        ret = true;
        break;
    case CMD_AT_CRESET:
        PrcsNormalUnexpect(curCmd, TMOUT_RESET, tmPassLastCmd);
        break;
    case CMD_AT_INQNET:
        if (tmPassLastCmd < TMOUT_ATE0)
            return ret;
        SendCmd(s_atCmd[CMD_AT_INQNET], CMD_AT_INQNET);
        break;
    default:
        return false;
    }
    
    if (ret)	
        s_curCmd = CMD_DONE;
    
    return ret;
}

static bool SendCmd(const char *buff, int cmd)
{
	int len = buff? strlen(buff) : 0;
	if (len > 0 && cmd>=0 && cmd<CMD_DONE)
	{
		if (write2Dev(buff, len) > 0)
		{
            s_tmLastCmd = hrt_absolute_time() / 1e3;
			s_curCmd = cmd;
			return true;
		}
        PX4_WARN("SendCmd error!!!");
	}
	return false;
}

static void resetDev(void)
{
#if defined WIN32 || defined WIN64
    SendCmd(s_atCmd[CMD_AT_CRESET], CMD_AT_CRESET);
#else
	gpio_sim76_rst(false);
	usleep(5e5);
	gpio_sim76_rst(true);
	usleep(3e5);
	gpio_sim76_pwrkey(false);	
	usleep(1e6);
    gpio_sim76_pwrkey(true);
    s_curCmd = CMD_AT_CRESET;
    s_tmLastCmd = hrt_absolute_time() / 1e3;
#endif
    s_szBuffRcv = 0;
    s_szBuffSnd = 0;
    s_szBuffParsed = 0;
    memset(&s_sockInfos, 0, sizeof(s_sockInfos));
    s_sockInfos.sockCurRcv = -1;
    s_sockInfos.bCsq = true;
}

static void setParsed(int nPos)
{
    s_szBuffParsed = nPos <= s_szBuffRcv ? nPos : s_szBuffRcv;
}

static int getSockinfoByIPAndPort(unsigned ip, unsigned short port)
{
    for (uint32_t i = 0; i < MaxSockCom; ++i)
    {
        Sock4GInfo *info = s_sockInfos.socks + i;
        if (info->used && info->ip == ip && info->port == port)
            return i;
    }

    return -1;
}

static Sock4GInfo *getSockinfoBySock(int sock)
{
    Sock4GInfo *info = NULL;
    if (sock < 0 || sock>MaxSockCom)
        return NULL;

    info = s_sockInfos.socks + sock;
    if (info->used)
        return info;

    return NULL;
}

static int getUnusedSock(void)
{
    Sock4GInfo *info = s_sockInfos.socks;
    int i = 0;
    for (; i < MaxSockCom; ++i)
    {
        if (!info->used)
            return i;
        ++info;
    }

    return -1;
}

static void parseClosEcho(void)
{
    if (findString(s_rcvBuff, s_szBuffRcv, OK_FLAG, 0) >= 0)
    {
        s_szBuffRcv = 0;
        SendCmd(s_atCmd[CMD_AT_CPIN], CMD_AT_CPIN);
    }
}
static void parseCPin(void)
{
    if (findString(s_rcvBuff, s_szBuffRcv, SIM_FLAG, 0) >= 0)
    {
        s_szBuffRcv = 0;
        SendCmd(s_atCmd[CMD_AT_SIMID], CMD_AT_SIMID);		
        PX4_WARN("Sim OK!!!");
    }
    else if (findString(s_rcvBuff, s_szBuffRcv, ERROR_FLAG, 0) >= 0)
    {
        s_szBuffRcv = 0;
        SendCmd(s_atCmd[CMD_AT_CPIN], CMD_AT_CPIN);
    }
}

static void parseSimId(void)
{
    int pos = findString(s_rcvBuff, s_szBuffRcv, SIMID_FLAG, 0) + SIMID_FLAG_LEN;
    int posRet = findString(s_rcvBuff, s_szBuffRcv, "\r\n", pos);
    if (pos >= SIGSTR_FLAG_LEN && pos<posRet)
    {
        strncpy(s_sockInfos.simId, s_rcvBuff + pos, MaxSinIDLen);
        s_szBuffRcv = 0;
        SendCmd(s_atCmd[CMD_AT_CSQ], CMD_AT_CSQ);		
        PX4_WARN("SimId: %s", s_sockInfos.simId);
    }
    else if (findString(s_rcvBuff, s_szBuffRcv, ERROR_FLAG, 0) >= 0)
    {
        s_szBuffRcv = 0;
        SendCmd(s_atCmd[CMD_AT_CPIN], CMD_AT_CPIN);
    }
}

static void parseCsqValid(void)
{
    int pos = findString(s_rcvBuff, s_szBuffRcv, SIGSTR_FLAG, 0) + SIGSTR_FLAG_LEN;
    int posRet = findString(s_rcvBuff, s_szBuffRcv, "\r\n", pos);
    if (pos >= SIGSTR_FLAG_LEN && pos<posRet)
    {
        bool b;
        bool b2;
        int tmp = findString(s_rcvBuff, posRet, ",", pos);
        int csq = str2int(s_rcvBuff + pos, tmp - pos, &b);
        int max = str2int(s_rcvBuff + tmp + 1, posRet - tmp - 1, &b2);
		
        if (b && b2)
        {
            if (csq < max)
			{
                SendCmd(s_atCmd[CMD_AT_CREG], CMD_AT_CREG);
                s_sockInfos.bCsq = true;
                s_szBuffRcv = 0;
                return;
            }

            if (max == 0)
            {
                unsigned tmCur = hrt_absolute_time() / 1000;
                if (s_sockInfos.bCsq)
                {
                    s_tmFirstCsq = tmCur;
                    s_sockInfos.bCsq = false;
                }
                else if (tmCur - s_tmFirstCsq > TMOUT_CSQINV)
                {
                    resetDev();
                    s_szBuffRcv = 0;
                    return;
                }
            }
            SendCmd(s_atCmd[CMD_AT_CSQ], CMD_AT_CSQ);
            usleep(5e5);
        }
    }
}

static void parseServer(void)
{
    int pos = findString(s_rcvBuff, s_szBuffRcv, SERVER_FLAG, 0);
    if (pos >= 0)
    {
        s_szBuffRcv = 0;
        SendCmd(s_atCmd[CMD_AT_NETOPEN], CMD_AT_NETOPEN);
    }
}

static int parseOpenNetResult(void)
{
    int pos = findString(s_rcvBuff, s_szBuffRcv, NETOPENED_FLAG, 0) + NETOPENED_FLAG_LEN;
    int tmp = -1;
	if(pos >= NETOPENED_FLAG_LEN)
		tmp = findString(s_rcvBuff, s_szBuffRcv, RETURN_FLAG, pos);

    if (tmp > 0)
    {
        setParsed(tmp + 2);
        return str2int(s_rcvBuff + pos, tmp - pos, NULL);
    }
	return -1;
}

static void parseOpenNet(void)
{
    int res = parseOpenNetResult();
    if (res>=0)
    {
    	s_curCmd = CMD_DONE;
        if (res > 0)
        {
            usleep(2e6);
            SendCmd(s_atCmd[CMD_AT_NETOPEN], CMD_AT_NETOPEN);
            PX4_WARN("4G Open Net fail!!!");
        }
        else
        {
            PX4_WARN("4G Open Net OK!!!");
        }
    }
	else if (findString(s_rcvBuff, s_szBuffRcv, ERROR_FLAG, 0) >= 0)
	{
		SendCmd(s_atCmd[CMD_AT_NETCLOSE], CMD_AT_NETCLOSE);
	}
}

static void parseCloseNet(void)
{
    if ( findString(s_rcvBuff, s_szBuffRcv, NETCLOSED_FLAG, 0) >= 0
		|| findString(s_rcvBuff, s_szBuffRcv, ERROR_FLAG, 0) >= 0 )
    {
        s_szBuffRcv = 0;
        SendCmd(s_atCmd[CMD_AT_NETOPEN], CMD_AT_NETOPEN);
    }
}

static void parseConnect(void)
{
    Sock4GInfo *info = getSockinfoBySock(s_sockInfos.sockCur);
    int pos = findString(s_rcvBuff, s_szBuffRcv, CONNECTED_FLAG, 0) + CONNECTED_FLAG_LEN;
    if (pos > CONNECTED_FLAG_LEN)
    {
        int end = findString(s_rcvBuff, s_szBuffRcv, RETURN_FLAG, pos);
        if (end > pos)
        {
            int tmp = findString(s_rcvBuff, end, ",", pos) + 1;
            setParsed(end + RETURN_FLAG_LEN);
            end = (tmp > 0 && tmp < end) ? str2int(s_rcvBuff + tmp, end - tmp, NULL) : 0;
            s_curCmd = CMD_DONE;
            if (0 == end)
            {
                if (info)
                    info->stat = Sock_Connected;
                return;
            }
            if (2 == end)
            {
                if (info)
                    info->stat = Sock_Disconnected;
                check4G();
                return;
            }
            if (info)
            {
                sprintf(s_buffCmd, s_atCmd[CMD_AT_CIPCLOSE], s_sockInfos.sockCur);
                SendCmd(s_buffCmd, CMD_AT_CIPCLOSE);
                info->stat = Sock_Closing;
            }
        }
    }
    else if ((pos = findString(s_rcvBuff, s_szBuffRcv, ERROR_FLAG, 0)) >= 0)
    {
        s_curCmd = CMD_DONE;
        if (info)
            info->stat = Sock_ConnectErr;
        setParsed(pos + ERROR_FLAG_LEN);
        check4G();
    }
}

static void parseDNSIP(void)
{
    int pos = findString(s_rcvBuff, s_szBuffRcv, ERROR_FLAG, 0);
    Sock4GInfo *info = getSockinfoBySock(s_sockInfos.sockCur);
    if (pos >= 0)
    {
        if (info)
            info->stat = Sock_ConnectErr;

        s_curCmd = CMD_DONE;
        setParsed(pos + ERROR_FLAG_LEN);
    }
    else 
    {
        pos = findString(s_rcvBuff, s_szBuffRcv, NDSIP_FLAG, 0) + NDSIP_FLAG_LEN;
        if (pos >= NDSIP_FLAG_LEN)
        {
			char ip[16]= {0};
        	int tmp = findString(s_rcvBuff, s_szBuffRcv, "\",\"", pos) + 3;
        	pos = tmp>=3 ? findString(s_rcvBuff, s_szBuffRcv,"\"\r\n", tmp) : -1;
			info->ip = INVALIDIP;
			if (pos > tmp)
			{
				memcpy(ip, s_rcvBuff+tmp, pos-tmp);
            	info->ip = str2Ip(ip, pos-tmp);
        		setParsed(pos + RETURN_FLAG_LEN);
			}

			if (info->ip!=INVALIDIP)
			{
                sprintf(s_buffCmd, s_atCmd[CMD_AT_CIPOPEN], s_sockInfos.sockCur, ip, info->port);
                SendCmd(s_buffCmd, CMD_AT_CIPOPEN);
                PX4_WARN("DNS connect: %s!!!", s_buffCmd);
			}
        }
    }
}

static void parseSending(void)
{
    int pos = findString(s_rcvBuff, s_szBuffRcv, CONNCTERR_FLAG, 0) + CONNCTERR_FLAG_LEN;
	int tmp = findString(s_rcvBuff, s_szBuffRcv, ERROR_FLAG, 0) + ERROR_FLAG_LEN;
    Sock4GInfo *info = getSockinfoBySock(s_sockInfos.sockCur);
	if (!info)
		return;
	
	if (pos >= CONNCTERR_FLAG_LEN)
	{
        s_curCmd = CMD_DONE;
        info->stat = Sock_Disconnected;
        check4G();
        setParsed(pos);
        PX4_WARN("sock disconnected !!!");
	}
    else if (tmp >= ERROR_FLAG_LEN)
    {
        s_curCmd = CMD_DONE;
        info->stat = Sock_SendFail;
        setParsed(tmp);
        PX4_WARN("sock send fail!!!");
        check4G();
    }
    else if (s_szBuffSnd > 0)
    {
        if (!info->sending)
        {
			if ((pos = findString(s_rcvBuff, s_szBuffRcv, SENDRDY_FLAG, 0)) < 0)
				return;
			
            setParsed(pos + SENDRDY_FLAG_LEN);
			info->sending = true;
        }
        if (s_szBuffSnd > 0 && s_sndBuff)
        {
            int tmpW = write2Dev(s_sndBuff, s_szBuffSnd);
			s_szBuffSnd -= tmpW;
			if (s_szBuffSnd > 0)
				memcpy(s_sndBuff, s_sndBuff+tmpW, s_szBuffSnd);
			
            s_tmLastCmd = hrt_absolute_time() / 1000 ;
        }
    }
    else
    {   
        tmp = -1;
        pos = findString(s_rcvBuff, s_szBuffRcv, SENDED_FLAG, 0)+SENDED_FLAG_LEN;
        if  (pos >= SENDED_FLAG_LEN)
            tmp = findString(s_rcvBuff, s_szBuffRcv, RETURN_FLAG, pos);

		if (tmp > pos)
        {
			int snded = -1;
            int snding = -1;
            int t1 = findString(s_rcvBuff, s_szBuffRcv, ",", pos) + 1;
            if (t1 > pos)
                pos = findString(s_rcvBuff, s_szBuffRcv, ",", t1) + 1;

            if (pos > t1 && tmp > pos && t1>0)
            {
                snded = str2int(s_rcvBuff + t1, pos - 1 - t1, NULL);
                snding = str2int(s_rcvBuff + pos, tmp - pos, NULL);
            }
			
			info->stat = Sock_SendFail;
			if (snding>0 && snding == snded)
				info->stat = Sock_Sended;
            else
                PX4_WARN("send Stat: %d, %d!!!", snded, snding);

            s_curCmd = CMD_DONE;
            setParsed(tmp + RETURN_FLAG_LEN);
        }
    }
}

static int prcsRemain(short sock, char *buff, int len)
{
    int ret = 0;
    int nTmp = len < s_szBuffRcv ? len : s_szBuffRcv;
    if (nTmp > s_sockInfos.remaind)
        nTmp = s_sockInfos.remaind;

    if (0 == nTmp)
        return ret;

    if (sock == s_sockInfos.sockCurRcv && nTmp>0 && buff)
    {
        memcpy(buff, s_rcvBuff, nTmp);
        ret = nTmp;
    }

    if (sock == s_sockInfos.sockCurRcv || s_sockInfos.sockCurRcv < 0 || !getSockinfoBySock(s_sockInfos.sockCurRcv))
    {
        if (s_szBuffRcv > nTmp)
            memcpy(s_rcvBuff, s_rcvBuff + nTmp, s_szBuffRcv - nTmp);
        s_sockInfos.remaind -= nTmp;
        s_szBuffRcv -= nTmp;
    }

    return ret;
}

static int parseRecvSock(int pos, int *packLen, int *beg, int *packBeg)
{
    if (!packLen || !beg || !packBeg)
        return -2;

    *beg = findString(s_rcvBuff, s_szBuffRcv, RECV_FLAG, pos);
    if (*beg >= 0)
    {
        int ipBeg = *beg + RECV_FLAG_LEN;
        int ipEnd = -1;
        int tmp = 0;
        int tmp2 = 0;
        ipEnd = findString(s_rcvBuff, s_szBuffRcv, RETURN_FLAG, ipBeg);
        if (ipEnd <= ipBeg)
            return -2;

        tmp = findString(s_rcvBuff, s_szBuffRcv, RECVLEN_FLAG, ipEnd + RETURN_FLAG_LEN) + RECVLEN_FLAG_LEN;
        if (tmp < RECVLEN_FLAG_LEN)
            return -2;

        tmp2 = findString(s_rcvBuff, s_szBuffRcv, RETURN_FLAG, tmp);
        if (tmp2 <= tmp)
            return -2;

        *packLen = str2int(s_rcvBuff + tmp, tmp2 - tmp, NULL);
        *packBeg = tmp2 + RETURN_FLAG_LEN;
        if (*packLen > 0)
        {
            int nSplit = findString(s_rcvBuff, ipEnd, ":", ipBeg);
            if (nSplit > ipBeg && nSplit < ipEnd)
            {
                unsigned ip = str2Ip(s_rcvBuff + ipBeg, nSplit - ipBeg);
                unsigned short port = str2int(s_rcvBuff + nSplit + 1, ipEnd - nSplit - 1, NULL);
                return getSockinfoByIPAndPort(ip, port);
            }
        }
        return -2;
    }

    return -2;
}

static bool parseClose(bool bNtf)
{
    int pos = bNtf ? findString(s_rcvBuff, s_szBuffRcv, CLOSEDNTF_FLAG, 0) + CLOSEDNTF_FLAG_LEN
        : findString(s_rcvBuff, s_szBuffRcv, CLOSED_FLAG, 0) + CLOSED_FLAG_LEN;
    int tmp = -1;
    if (pos >= CLOSED_FLAG_LEN)
        tmp = findString(s_rcvBuff, s_szBuffRcv, RETURN_FLAG, pos);

    if (tmp > 0)
    {
        Sock4GInfo *info = NULL;
        bool suc = false;
        setParsed(tmp + RETURN_FLAG_LEN);
        tmp = findString(s_rcvBuff, s_szBuffRcv, ",", pos);
        tmp = str2int(s_rcvBuff + pos, tmp - pos, &suc);
        info = getSockinfoBySock(tmp);
        if (suc && tmp==s_sockInfos.sockCur)
            s_curCmd = CMD_DONE;
        else
            PX4_WARN("Sock(%d) disconnect!!", s_curCmd, tmp);

        if (suc && info)
        {
            info->stat = Sock_Closed;
            return true;
        }
    }
    return false;
}

static void parseReset(void)
{
    if (findString(s_rcvBuff, s_szBuffRcv, INITDONE_FLAG, 0) >= 0)
    {
        PX4_WARN("4G dev initial!!");
        s_szBuffRcv = 0;
        SendCmd(s_atCmd[CMD_ATE0], CMD_ATE0);
    }
    else if (s_szBuffRcv > INITDONE_FLAG_LEN)
    {
        s_szBuffRcv = 9;
    }
}

static void parseInqNet(void)
{
    int res = parseOpenNetResult();
    Sock4GInfo *info = getSockinfoBySock(s_sockInfos.sockCur);
    if (res == 0)
    {
        for (int i = 0; i < MaxSockCom; ++i)
        {
            s_sockInfos.socks[i].used = false;
        }
        SendCmd(s_atCmd[CMD_AT_CSQ], CMD_AT_CSQ);
        s_szBuffSnd = 0;
    }
    else if(info)
    {
        sprintf(s_buffCmd, s_atCmd[CMD_AT_CIPCLOSE], s_sockInfos.sockCur);
        SendCmd(s_buffCmd, CMD_AT_CIPCLOSE);
        info->stat = Sock_Closing;
    }
}

static bool check4G(void)
{
    bool bAllDisConnect = true;
    for (int i = 0; i < MaxSockCom; ++i)
    {
        if (s_sockInfos.socks[i].used && isConnect(s_sockInfos.socks[i].stat))
        {
            bAllDisConnect = false;
            break;
        }
    }
    if (bAllDisConnect)
        SendCmd(s_atCmd[CMD_AT_INQNET], CMD_AT_INQNET);

    return !bAllDisConnect;
}

static bool isConnect(short st)
{
    return  st == Sock_Connected
         || st== Sock_Sending
         || st == Sock_Sended;
}
///////////////////////////////////////////////////////
//Initial4GDev
///////////////////////////////////////////////////////
bool Initial4GDev(const char *path, char *simid)
{
    if (s_file != INVALID_HANDLE_VALUE)
		return true;

#if defined WIN32 || defined WIN64
    bool errC = true;
    s_file = CreateFileA(path, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);//独占方式打开串口
    if (s_file != INVALID_HANDLE_VALUE)
    {
        DCB dcb;
        if (!GetCommState(s_file, &dcb))
            return false;
        dcb.BaudRate = 115200;      //波特率为9600  
        dcb.ByteSize = 8;           //每个字节有8位  
        dcb.StopBits = ONESTOPBIT;  //停止位
        dcb.Parity = NOPARITY;      //无奇偶校验位
        if (SetCommState(s_file, &dcb))
        {
            COMMTIMEOUTS ts;
            if (GetCommTimeouts(s_file, &ts))
            {
                ts.ReadIntervalTimeout = -1;
                ts.ReadTotalTimeoutMultiplier = 0;
                ts.ReadTotalTimeoutConstant = 0;
                errC = !SetCommTimeouts(s_file, &ts);
            }
        }
    }
    s_log = fopen("log.dat", "wb");
    if (errC)
#else
    s_file = open(path, O_RDWR|O_NOCTTY|O_NONBLOCK);
    if (s_file < 0)
#endif
        return false;

    resetDev();
    s_sockInfos.simId = simid;
    return true;
}

void BeginParse(void)
{
#if defined WIN32 || defined WIN64
    DWORD len = 0;
    ReadFile(s_file, s_rcvBuff + s_szBuffRcv, sizeof(s_rcvBuff) - s_szBuffRcv, &len, NULL);
    if (len > 0 && s_file)
        fwrite(s_rcvBuff + s_szBuffRcv, 1, len, s_log);
#else
    int len = read(s_file, s_rcvBuff + s_szBuffRcv, sizeof(s_rcvBuff) - s_szBuffRcv);
#endif
    if (len > 0)
        s_szBuffRcv += len;
}

void ParseRcvBuff()
{
    if (s_szBuffRcv > 0)
    {
        switch (s_curCmd)
        {
        case CMD_ATE0:  // = 0,//关闭回显
            parseClosEcho();
            break;
        case CMD_AT_CPIN://,//有无SIM
            parseCPin();
            break;
        case CMD_AT_SIMID://,//SIMID
            parseSimId();
            break;
        case CMD_AT_CSQ:    //信号强度
            parseCsqValid();
            break;
        case CMD_AT_CREG:   //有无服务
            parseServer();
            break;
        case CMD_AT_NETOPEN:    //打开NET网络
            parseOpenNet();
            break;
        case CMD_AT_NETCLOSE://,    //关闭NET网络
            parseCloseNet();
            break;
        case CMD_AT_CIPOPEN://,     //连接
            parseConnect();
            break;
    	case CMD_AT_DNSIP:
    		parseDNSIP();
            break;
        case CMD_AT_CIPSEND://,     //发送数据准备AT+CIPSEND=<socketid>,<data len>
            parseSending();
            break;
        case CMD_AT_CIPCLOSE:
            parseClose(false);
            break;
        case CMD_AT_CRESET://
            parseReset();
            break;
        case CMD_AT_INQNET://
            parseInqNet();
            break;
        default:
            break;
        }
    }
    parseClose(true);//断开可能是gsm模块发出来的
	UnexpectPrcs(s_sockInfos.sockCur, s_curCmd);
}

void ResetRcvBuff(void)
{
    if (s_szBuffRcv < s_szBuffParsed)
        s_szBuffParsed = s_szBuffRcv;

    int sz = s_szBuffRcv - s_szBuffParsed;
    if (sz > 64)
    {
        sz = 64;
        s_szBuffParsed = s_szBuffRcv - 64;
    }
    if (sz > 0 && s_szBuffParsed>0)
        memcpy(s_rcvBuff, s_rcvBuff + s_szBuffParsed, sz);

    s_szBuffRcv = sz;
    s_szBuffParsed = 0;
}

short Create4GSock(short sock)
{
    Sock4GInfo *info = NULL;
    if (sock >= 0 && sock < MaxSockCom)
        info = s_sockInfos.socks + sock;
    else if ((sock = getUnusedSock())>=0)
        info = s_sockInfos.socks + sock;

    if (info)
    {
        info->used = true;
        info->stat = Sock_OK;
        return sock;
    }
    return -1;
}

bool Connect4G(int id, const char *host, unsigned short port)
{
    if (s_curCmd == CMD_DONE)
    {
        Sock4GInfo *sock = getSockinfoBySock(id);
        int st = sock ? sock->stat : Sock_UnCreate;
        if ( Sock_OK == st
		  || Sock_ConnectErr == st
		  || Sock_Disconnected == st
		  || Sock_Closed == st )
        {
            sock->port = port;
            sock->ip = str2Ip(host, -1);
            if (sock->ip != INVALIDIP)
            {
                sprintf(s_buffCmd, s_atCmd[CMD_AT_CIPOPEN], id, host, port);
                if (!SendCmd(s_buffCmd, CMD_AT_CIPOPEN))
                    return false;
            }
			else
			{
                sprintf(s_buffCmd, s_atCmd[CMD_AT_DNSIP], host);
                if (!SendCmd(s_buffCmd, CMD_AT_DNSIP))
                    return false;
			}
            s_sockInfos.sockCur = id;
            sock->stat = Sock_Connecting;
            return true;
        }
    }

    PX4_WARN("Connect4G fail(curCmd:%d, sock:%d)!!", s_curCmd, id);
    return false;
}

bool Close4GSock(int id)
{
    if (s_curCmd == CMD_DONE)
    {
        Sock4GInfo *sock = getSockinfoBySock(id);
        if (sock && sock->stat != Sock_UnCreate)
        {
            sprintf(s_buffCmd, s_atCmd[CMD_AT_CIPCLOSE], id);
            if (!SendCmd(s_buffCmd, CMD_AT_CIPCLOSE))
                return false;

			sock->used = false;
            s_sockInfos.sockCur = id;
            sock->stat = Sock_Closing;
            return true;
        }
    }
    return false;
}

int Send4G(int sock, char *buff, int len)
{
    Sock4GInfo *sockInfo = getSockinfoBySock(sock);
    if (s_curCmd != CMD_DONE || !sockInfo)
        return 0;

    if (sockInfo->stat == Sock_Connected || sockInfo->stat == Sock_Sended || sockInfo->stat == Sock_SendFail)
    {
        int nSend = len;
        sprintf(s_buffCmd, s_atCmd[CMD_AT_CIPSEND], sock, nSend);
        if (!SendCmd(s_buffCmd, CMD_AT_CIPSEND))
            return 0;

        s_sndBuff = buff;
        s_szBuffSnd = nSend;
        s_sockInfos.sockCur = sock;
        sockInfo->stat = Sock_Sending;
		sockInfo->sending = false;
        return nSend;
    }
    return 0;
}

int Recv4G(int sock, char *buf, unsigned len)
{
    int pos = 0;
    int rcv = 0;
    int packLen = 0;
    int psBeg = 0;
    int buffBeg = 0;
    Sock4GInfo *info = getSockinfoBySock(sock);
    if (!info || !isConnect(info->stat))
        return 0;

    rcv = prcsRemain(sock, buf, len);
    while (pos < s_szBuffRcv)
    {
        int sockTmp = parseRecvSock(pos, &packLen, &psBeg, &buffBeg);
        if (sockTmp<-1 || psBeg<0)
            break;

        pos = buffBeg + packLen;
        if (pos > s_szBuffRcv)
            pos = s_szBuffRcv;

        if (sockTmp == sock)
        {
            int cp = packLen;
            cp = s_szBuffRcv - buffBeg;
            if (rcv+cp > (int)len)
                return 0;

            if (cp > 0)
            {
                memcpy(buf+rcv, s_rcvBuff + buffBeg, cp);
                rcv += cp;
            }
        }

        if (sockTmp == sock || sockTmp == -1)
        {
            if (packLen + buffBeg > s_szBuffRcv)
            {
                s_sockInfos.sockCurRcv = sock;
                s_sockInfos.remaind = packLen + buffBeg - s_szBuffRcv;
            }

            if (s_szBuffRcv > pos)
                memcpy(s_rcvBuff + psBeg, s_rcvBuff + pos, s_szBuffRcv - pos);

            s_szBuffRcv = psBeg + s_szBuffRcv - pos;
            pos = psBeg;
            setParsed(psBeg+packLen);
        }
    }
	
	return rcv;
}

Status4G Get4gStat(int sock)
{
    Sock4GInfo *info = getSockinfoBySock(sock);
    if (!info)
        return Sock_UnCreate;

    if ((s_curCmd != CMD_DONE && s_sockInfos.sockCur != sock) || s_curCmd==CMD_AT_INQNET)
        return Sock_Bussy;


    if (s_curCmd == CMD_AT_CRESET || s_curCmd < CMD_AT_CIPOPEN)
        return Sock_DevIniting;

    return (Status4G)info->stat;
}

void Close4G(void)
{
    if (s_file < 0)
        return;

    for (int i = 0; i < MaxSockCom; ++i)
    {
        if (s_sockInfos.socks[i].used)
            Close4GSock(i);
    }
#if defined WIN32 || defined WIN64
    CloseHandle(s_file);
    s_file = INVALID_HANDLE_VALUE;
#else
   	close(s_file);
    s_file = -1;
#endif
}

