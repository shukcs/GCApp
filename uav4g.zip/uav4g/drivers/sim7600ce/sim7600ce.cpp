﻿/****************************************************************************
 *
 *   Copyright (c) 2012-2017 PX4 Development Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name PX4 nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

/**
 * @file sim7600ce.cpp
 *
 * @author Lorenz Meier <lorenz@px4.io>
 * @author Julian Oes <julian@oes.ch>
 * @author Thomas Gubler <thomas@px4.io>
 * @author Anton Babushkin <anton@px4.io>
 * @author Beat Küng <beat-kueng@gmx.net>
 */

#if defined _WIN32 || defined WIN64
#include <Windows.h>
#include "sysfunc.h"
#include <sim7600ce.h>
#define  __EXPORT
#else
#include <board_config.h>
#include <px4_config.h>
#include <px4_module.h>
#include <px4_getopt.h>
#include <px4_posix.h>
#include <px4_tasks.h>
#include <px4_time.h>

#include <fcntl.h>
#include <poll.h>
#include <unistd.h>
#include <errno.h>
#include <math.h>
#include <mathlib/mathlib.h>
#include <drivers/drv_hrt.h>
#include <drivers/drv_rc_input.h>
#include <drivers/drv_adc.h>
#include <drivers/drv_airspeed.h>
#include <drivers/drv_px4flow.h>
#include <systemlib/airspeed.h>
#include <systemlib/systemlib.h>
#include <systemlib/param/param.h>
#include <systemlib/err.h>
#include <systemlib/perf_counter.h>
#include <systemlib/battery.h>
#include <conversion/rotation.h>
#include <DevMgr.hpp>
#endif // !_WIN32

#include "drv4gdev.h"
#include <socket4g/ShareMemory.h>
#include <socket4g/LoopQue.h>
#include <socket4g/socket4g.h>

#if !defined _WIN32 && !defined WIN64
#define UART_PATH_4G "/dev/ttyS1"
#else
#define UART_PATH_4G "COM5"
#endif // !_WIN32
#define MinTmCreateShm 1000
//using namespace DriverFramework;

/**
 * Sim7600ce AT driver start / stop handling function
 *
 * @ingroup drivers
 */

extern "C" __EXPORT int sim7600ce_main(int argc, char *argv[]);
static bool processSnd(ShareMemory *sh, short &sock);
static short processRcv(ShareMemory *sh, short sock, bool change, short lstSt);
static char s_buffSnd[512] = { 0 };
static char s_buffRcv[512] = { 0 };

class Sim7600ce
#if !defined _WIN32 && !defined WIN64
    : public ModuleBase<Sim7600ce>
#endif // !_WIN32
{
public:
	Sim7600ce();

	~Sim7600ce() {}

#if !defined _WIN32 && !defined WIN64
	/** @see ModuleBase */
	static int task_spawn(int argc, char *argv[]);

	/** @see ModuleBase */
	static Sim7600ce *instantiate(int argc, char *argv[]);

	/** @see ModuleBase */
	static int custom_command(int argc, char *argv[]);

	/** @see ModuleBase */
	static int print_usage(const char *reason = nullptr);
	/** @see ModuleBase::print_status() */
	int print_status() override;
#else
    static bool should_exit() { return false; }
#endif
    /** @see ModuleBase::run() */
#if !defined _WIN32 && !defined WIN64
    void run() override;
private:
	hrt_abstime	_last_adc{0};			/**< last time we took input from the ADC */
#else
    static DWORD run();
#endif //_WIN32
};

static bool processSnd(ShareMemory *sh, short &sock)
{
    if (!sh || !sh->IsValid())
        return false;

    bool ret = false;
    int statCur = Get4gStat(sock);
    Sock4GBuff &buff = *(Sock4GBuff *)sh->GetShmAddr();
    if ((statCur >= 0 || statCur == Sock_UnCreate) && (buff.changed & Change_Snd))
    {
        buff.changed &= ~Change_Snd;
        switch (buff.ctrl)
        {
        case Uorb4G_Create:
            sock = (short)Create4GSock(sock);
            break;
        case Uorb4G_Connect:
            Connect4G(sock, buff.bufSnd.host, buff.bufSnd.port);
            ret = true;
            break;
        case Uorb4G_Send:
            {
                LoopQue que(&buff.bufSnd, sizeof(buff.bufSnd));
                uint16_t sz = que.Pop(s_buffSnd, sizeof(s_buffSnd));
                Send4G(sock, s_buffSnd, sz);
                ret = true;
            }
            break;
        case Uorb4G_Disconnect:
        case Uorb4G_Close:
            Close4GSock(sock);
            sock = -1;
            ret = true;
            break;
        default:
            break;
        }
    }

    if (0==buff.valid)
    {
        sh->Clear();
    }

	return ret;
}

static short processRcv(ShareMemory *sh, short sock, bool change, short statLst)
{
    if (sock < 0 || !sh || !sh->IsValid())
        return statLst;

    Sock4GBuff *buff = (Sock4GBuff *)sh->GetShmAddr();
    int statCur = Get4gStat(sock);
    buff->stat = statCur;
    if (statCur != statLst || change)
        buff->changed |= Change_Rcv;

    return statCur;
}

Sim7600ce::Sim7600ce()
{
	//initialize_parameter_handles(_parameter_handles);
}

#if !defined _WIN32 && !defined WIN64
void Sim7600ce::run()
#else
DWORD Sim7600ce::run()
#endif //_WIN32
{
    if (!Initial4GDev(UART_PATH_4G, Socket4G::GetSimId()))
#if defined _WIN32 || defined WIN64
        return 0;
#else
        return;
#endif //_WIN32

	ShareMemory *socketBuff[MaxSock] = {NULL, NULL};
	short sock4G[MaxSock] = {-1, -1};
    short sock4GStat[MaxSock] = { Sock_UnCreate, Sock_UnCreate};

	for (int i=0; i< MaxSock; ++i)
	{
        if (!socketBuff[i])
            socketBuff[i] = new ShareMemory(sizeof(Sock4GBuff), ShareMemory::Exist, i);
	}

	usleep(5e6);
	PX4_WARN("Sim7600ce::run()rcvsock 0x%08X, 0x%08X!!!!", socketBuff[MaxSock-1], socketBuff[MaxSock-1]->GetShmAddr());
    int curParse = 0;
    LoopQue queTmp;
    Sock4GBuff *buffSock = NULL;
    int sndStat = 0;
	while (!should_exit())
    {
        BeginParse();
        for (int i = 0; i < MaxSock; ++i)
        {
            if (socketBuff[i]->IsValid())
            {
                buffSock = (Sock4GBuff *)socketBuff[i]->GetShmAddr();
                int tmp = Recv4G(sock4G[i], s_buffRcv, sizeof(s_buffRcv));
                if (tmp > 0)
                {
                    queTmp.InitLoopQue(&buffSock->bufRcv, sizeof(buffSock->bufRcv));
                    queTmp.Push(s_buffRcv, tmp);
                    buffSock->changed |= Change_Rcv;
                }
            }
        }
		ParseRcvBuff();
        for (int i = 0; i < MaxSock; ++i)
        {
            if (!socketBuff[i]->IsValid())
            {
                if (socketBuff[i]->CreateShm(sizeof(Sock4GBuff), ShareMemory::Exist, i))
                    PX4_WARN("Open share memory 0x%08X", socketBuff[i]->GetShmAddr());
            }
        }
        for (int i = 0; i < MaxSock; ++i)
		{
            int cur = curParse;
            curParse = (curParse + 1) % MaxSock;
            if (!processSnd(socketBuff[cur], sock4G[cur]))
                continue;

            sndStat |= i << cur;
            break;
		}

      	for (int i=0; i < MaxSock; ++i)
        {
            sock4GStat[i] = processRcv(socketBuff[i], sock4G[i], (sndStat & (1 << i)), sock4GStat[i]);
        }
		ResetRcvBuff();
		usleep(8e3);
        sndStat = 0;
	}

	Close4G();
	for (int i=0; i < MaxSock; ++i)
	{
		if (sock4G[i] < 0 || !socketBuff[i] || !socketBuff[i]->IsValid())
			continue;

        buffSock = (Sock4GBuff *)socketBuff[i]->GetShmAddr();
        buffSock->stat = Sock_UnCreate;
        buffSock->changed &= ~Change_Rcv;
        buffSock->bufRcv.beg = 0;
        buffSock->bufRcv.end = 0;
        delete socketBuff[i];
	}

	usleep(2e4);

#if defined _WIN32 || defined WIN64
    return 0;
#endif //_WIN32
}

#if !defined _WIN32 && !defined WIN64
int Sim7600ce::task_spawn(int argc, char *argv[])
{
	/* start the task */
	_task_id = px4_task_spawn_cmd("sim7600ce",
				      SCHED_DEFAULT,
				      SCHED_PRIORITY_SENSOR_HUB,
				      1024,
				      (px4_main_t)&run_trampoline,
				      (char * const*)argv);

	if (_task_id < 0) {
		_task_id = -1;
		return -errno;
	}

	return 0;
}

int Sim7600ce::print_status()
{

	return 0;
}

int Sim7600ce::custom_command(int argc, char *argv[])
{
	return print_usage("unknown command");
}

int Sim7600ce::print_usage(const char *reason)
{
	if (reason)
		PX4_WARN("%s\n", reason);

	PRINT_MODULE_DESCRIPTION(
		R"DESCR_STR(
### Description
The sensors module is central to the whole system. It takes low-level output from drivers, turns
it into a more usable form, and publishes it for the rest of the system.

The provided functionality includes:
- Read the output from the sensor drivers (`sensor_gyro`, etc.).
  If there are multiple of the same type, do voting and failover handling.
  Then apply the board rotation and temperature calibration (if enabled). And finally publish the data; one of the
  topics is `sensor_combined`, used by many parts of the system.
- Do RC channel mapping: read the raw input channels (`input_rc`), then apply the calibration, map the RC channels
  to the configured channels & mode switches, low-pass filter, and then publish as `rc_channels` and
  `manual_control_setpoint`.
- Read the output from the ADC driver (via ioctl interface) and publish `battery_status`.
- Make sure the sensor drivers get the updated calibration parameters (scale & offset) when the parameters change or
  on startup. The sensor drivers use the ioctl interface for parameter updates. For this to work properly, the
  sensor drivers must already be running when `sensors` is started.
- Do preflight sensor consistency checks and publish the `sensor_preflight` topic.

### Implementation
It runs in its own thread and polls on the currently selected gyro topic.

)DESCR_STR");

	PRINT_MODULE_USAGE_NAME("sensors", "system");
	PRINT_MODULE_USAGE_COMMAND("start");
	PRINT_MODULE_USAGE_PARAM_FLAG('h', "Start in HIL mode", true);
	PRINT_MODULE_USAGE_DEFAULT_COMMANDS();

	return 0;
}

Sim7600ce *Sim7600ce::instantiate(int argc, char *argv[])
{
	bool error_flag = false;
	int myoptind = 1;
	int ch;
	const char *myoptarg = nullptr;

	while ((ch = px4_getopt(argc, argv, "h", &myoptind, &myoptarg)) != EOF)
	{
		switch (ch)
		{
		case 'h':
			break;

		case '?':
			error_flag = true;
			break;

		default:
			PX4_WARN("unrecognized flag");
			error_flag = true;
			break;
		}
	}

	if (error_flag) {
		return nullptr;
	}

	return new Sim7600ce();
}

int sim7600ce_main(int argc, char *argv[])
{
	return Sim7600ce::main(argc, argv);
}
#else
void beginThread()
{
    ::CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)Sim7600ce::run, 0, 0, NULL);
}
#endif //!defined _WIN32 && !defined WIN64