﻿#include "socket4g.h"

#if defined _WIN32 || defined WIN64
#include "sysfunc.h"
#else
#include <px4_tasks.h>
#include <px4_log.h>
#include <px4_posix.h>
#include <drivers/drv_hrt.h>
#endif

#include "sock4glib.h"
#include "ShareMemory.h"
#include "LoopQue.h"
#include <string.h>

/****************************************************************************
***Socket4G
****************************************************************************/
char Socket4G::s_SimIdBuf[21] = {0};
Socket4G::Socket4G(uint32_t id):m_sockBuff(NULL)
, m_bufRcv(NULL), m_bufSnd(NULL)
{
    m_sockBuff = new ShareMemory(sizeof(Sock4GBuff), ShareMemory::Create, id);
    if (m_sockBuff && m_sockBuff->IsValid())
    {
        Sock4GBuff &skBuff = *(Sock4GBuff*)m_sockBuff->GetShmAddr();
        m_bufRcv = new LoopQue(&skBuff.bufRcv, sizeof(skBuff.bufRcv));
        m_bufSnd = new LoopQue(&skBuff.bufSnd, sizeof(skBuff.bufSnd));
        if (m_bufRcv)
            m_bufRcv->Clear();
        if (m_bufSnd)
            m_bufSnd->Clear();

        skBuff.stat = Sock_UnCreate;
        skBuff.ctrl = Uorb4G_NoCtrl;
        skBuff.changed = Change_No;
    }
    Create4GSock();
}
	
Socket4G::~Socket4G()
{
	Close4GSock();
    usleep(8000);
    delete m_bufRcv;
    delete m_bufSnd;
    delete m_sockBuff;
}

Socket4G::StatSock Socket4G::Poll(unsigned us)
{
    if (us > 0)
        usleep(us * 1000);

    if (!IsCreated())
        return None;

    Sock4GBuff &skBuff = *(Sock4GBuff*)m_sockBuff->GetShmAddr();
    bool bChange = skBuff.changed & Change_Rcv;
    switch (skBuff.stat)
    {
    case Sock_OK:
        return Created;
    case Sock_Connected:
        return Connected;
    case Sock_Sended:
        return Sended;
    case Sock_Disconnected:
    case Sock_Closed:
    case Sock_ConnectErr:
        return Disconnected;
    case Sock_SendFail:
        return SendFail;
    }

    if(bChange)
        skBuff.changed &= ~Change_Rcv;

    return None;
}

void Socket4G::Create4GSock()
{
    if (!m_sockBuff || !m_sockBuff->IsValid())
        return;

    Sock4GBuff &buff = *(Sock4GBuff*)m_sockBuff->GetShmAddr();
    buff.changed |= Change_Snd;
    buff.ctrl = Uorb4G_Create;
    buff.valid = true;
}

bool Socket4G::IsCreated()const
{
    if (!m_sockBuff || !m_sockBuff->IsValid())
        return false;

    Sock4GBuff &rcvData = *(Sock4GBuff*)m_sockBuff->GetShmAddr();
	return rcvData.valid && rcvData.stat != Sock_UnCreate;
}

bool Socket4G::Close4GSock()
{
	if (IsCreated())
	{
        Sock4GBuff &buff = *(Sock4GBuff*)m_sockBuff->GetShmAddr();
        buff.ctrl = Uorb4G_Disconnect;
        buff.valid = false;
        buff.changed |= Change_Snd;
        usleep(30000);
		return true;
	}

	return false;
}

int Socket4G::SendBuff(const void *buff, unsigned len)
{
  	if (IsCreated() && m_bufSnd)
    {
        Sock4GBuff &buff4G = *(Sock4GBuff*)m_sockBuff->GetShmAddr();
        buff4G.ctrl = Uorb4G_Send;
        buff4G.changed |= Change_Snd;
        buff4G.stat = Sock_Sending;
        if (m_bufSnd->Push(buff, len))
            return len;

        return 0;
	}
    return -1;
}

int Socket4G::RecvBuff(void *buff, unsigned len)
{
    if (IsCreated() && m_bufRcv)
        return m_bufRcv->Pop(buff, len);

    return -1;
}

int Socket4G::RecvLength()const
{
    if (IsCreated() && m_bufRcv)
        return m_bufRcv->Count();

    return 0;
}

void Socket4G::Connect(const char *host, unsigned short port)
{
	if (IsCreated())
	{
        Sock4GBuff &buff = *(Sock4GBuff*)m_sockBuff->GetShmAddr();
        buff.ctrl = Uorb4G_Connect;
        buff.stat = Sock_Connecting;
		strcpy(buff.bufSnd.host, host);
        buff.bufSnd.port = port;
        buff.changed |= Change_Snd;
	}
}

unsigned char *Socket4G::ToBigendian(unsigned char *buf, unsigned data)
{
	if (!buf)
		return NULL;
	
	for (uint32_t i=0; i<sizeof(uint32_t); ++i)
	{
		*(buf++) = ((uint8_t *)&data)[sizeof(uint32_t)-i-1];
	}
    return buf;
}

const unsigned char *Socket4G::FromBigendian(const unsigned char *buf, unsigned &data)
{
	if (!buf)
		return NULL;
	
	for (uint32_t i=0; i<sizeof(uint32_t); ++i)
	{
		((uint8_t *)&data)[sizeof(uint32_t)-i-1] = *(buf++);
	}
	
    return buf;
}

char *Socket4G::GetSimId()
{
    return s_SimIdBuf;
}
