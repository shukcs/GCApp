﻿#include "ShareMemory.h"
#include <sys/types.h>
#include <stdio.h>

#define MAXCOUNTSHM 2

#ifdef LINUX
#include <sys/ipc.h>
#include <sys/shm.h>
#define IPCKEY 0x0fed0000
#elif defined _WIN32 || defined _WIN64
#include <windows.h>
#define IPCNAME "$VGSHM%d"
#else
typedef struct {
    char buff[1080];
}ShareItem;

ShareItem gShareItem[MAXCOUNTSHM];
static uint32_t  s_useFlag = 0;
#endif

ShareMemory::ShareMemory(uint32_t sz, uint32_t tp, uint32_t id)
: m_type(tp)
#if defined _WIN32 || defined _WIN32
, m_idShm(NULL)
#elif defined LINUX
, m_idShm(-1)
#else
, m_idShm(-1)
#endif
, m_shmAddr(NULL)
{
    CreateShm(sz, tp, id);
}

ShareMemory::~ShareMemory()
{
    detach();
}

bool ShareMemory::CreateShm(uint32_t sz, uint32_t tp, uint32_t id)
{
    if ((tp!=Exist && tp!=Create) || m_shmAddr || id>=MAXCOUNTSHM)
        return false;

#if defined _WIN32 || defined _WIN32
    char name[16];
    sprintf(name, IPCNAME, id);
    if (tp == Create)
        m_idShm = ::CreateFileMappingA(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, sz, name);
    else
        m_idShm = ::OpenFileMappingA(FILE_MAP_ALL_ACCESS, FALSE, name);

    if (m_idShm)
        m_shmAddr = MapViewOfFile(m_idShm, FILE_MAP_ALL_ACCESS, 0, 0, sz);
#elif defined LINUX
    int flag = tp!=Create ? IPC_CREAT|0666 : 0666;
    m_idShm = shmget((key_t)(IPCKEY + id), sz, flag);
    if (m_idShm == -1)
    {
        printf("open share memory file!");
        return false;
    }

    m_shmAddr = shmat(m_idShm, 0, 0);
    if (m_shmAddr == (void*)-1)
    {
        m_shmAddr = NULL;
        printf("open share memory address fail!");
    }
#else
    if (sz>sizeof(ShareItem))
        return false;

    if (tp == Create)
    {
        if (s_useFlag&(1 << id))
            return false;
        s_useFlag |= (1 << id);
    }
    else if(!(s_useFlag&(1 << id)))
    {
        return false;
    }
    m_shmAddr = &gShareItem[id];
    m_idShm = id;
#endif
    m_type = tp;
    return m_shmAddr!=NULL;
}

void *ShareMemory::GetShmAddr()
{
    return m_shmAddr;
}

bool ShareMemory::IsValid()
{
    return m_shmAddr != NULL;
}

void ShareMemory::Clear()
{
    detach();
}

void ShareMemory::detach()
{
    if (!m_shmAddr)
        return;
#if defined _WIN32 || defined _WIN32
    ::UnmapViewOfFile(m_shmAddr);
    CloseHandle(m_idShm);
    m_idShm = NULL;
#elif defined LINUX
    shmdt(m_shmAddr);
    if ()
        shmctl(m_idShm, IPC_RMID, NULL);
    m_idShm = -1;
#else
    if (m_type == Create)
        s_useFlag &= ~(1 << m_idShm);
    m_idShm = -1;
#endif
    m_shmAddr = NULL;
    m_type = 0;
}
