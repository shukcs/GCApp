﻿#ifndef __SHARE_MEMORY_H__
#define __SHARE_MEMORY_H__

#include <stdbool.h>
#include <stdint.h>

class ShareMemory {
public:
    enum ShareType
    {
        Create = 1,
        Exist,
    };
public:
    ShareMemory(uint32_t sz=0, uint32_t tp=Exist, uint32_t id=0);
    ~ShareMemory();
    bool CreateShm(uint32_t sz = 0, uint32_t tp=0, uint32_t id = 0);
    void *GetShmAddr();
    bool IsValid();
    void Clear();
protected:
    void detach();
private:
    uint32_t    m_type;
#if defined _WIN32 || defined _WIN32
    void        *m_idShm;
#elif defined LINUX
    int         m_idShm;
#else
    int         m_idShm;
#endif//
    void        *m_shmAddr;
};

#endif //__SHARE_MEMORY_H__
