﻿#include "LoopQue.h"
#include <string.h>

LoopQue::LoopQue(void *buff, uint16_t sz):m_sizeMax(0)
, m_offset(NULL), m_end(NULL), m_buffLoop(NULL)
{
    InitLoopQue(buff, sz);
}

bool LoopQue::InitLoopQue(void *buff, uint16_t sz)
{
    if (!buff || sz < 5)
    {
        m_buffLoop = NULL;
        return false;
    }

    m_sizeMax = sz - 4;
    uint16_t *tmp = (uint16_t *)buff;
    m_offset = tmp++;
    m_end = tmp++;
    if (*m_end > m_sizeMax || *m_offset >= m_sizeMax)
    {
        m_buffLoop = NULL;
        return false;
    }

    m_buffLoop = (uint8_t*)tmp;
    return true;
}

bool LoopQue::PushOne(uint8_t val)
{
    if (m_buffLoop && Count() +1 < m_sizeMax)
    {
        m_buffLoop[*m_end] = val;
        *m_end = (*m_end+1)%m_sizeMax;
        return true;
    }

    return false;
}

bool LoopQue::PopOne(uint8_t &val)
{
    if (m_buffLoop && Count()>0)
    {
        val = m_buffLoop[(*m_offset)++];
        if (*m_offset == m_sizeMax)
            *m_offset = 0;

        return true;
    }

    return false;
}

bool LoopQue::Push(const void *buff, uint16_t sz)
{
    uint16_t count = Count();
    if (buff && sz>0 && m_buffLoop && count+sz<m_sizeMax)
    {
        uint16_t len = sz;
        if (*m_end + len >= m_sizeMax)
        {
            len = m_sizeMax - *m_end;
            if (len>0)
            {
                memcpy(m_buffLoop + *m_end, buff, len);
                *m_end = (*m_end+len)%m_sizeMax;
            }
            len = sz - len;
        }

        memcpy(m_buffLoop+ *m_end, (uint8_t*)buff+sz-len, len);
        *m_end += len;
        return true;
    }

    return false;
}

uint16_t LoopQue::Pop(void *buff, uint16_t sz)
{
    uint16_t count = Count();
    if (m_buffLoop && count > 0 && buff && sz>0)
    {
        if (sz > count)
            sz = count;

        count = sz;
        uint16_t cpy = 0;
        if (*m_offset+count >=m_sizeMax)
        {
            cpy = m_sizeMax - *m_offset;
            memcpy(buff, m_buffLoop + *m_offset, cpy);
            *m_offset = 0;
            count = sz - cpy;
        }
        if (count>0)
        {
            memcpy((char*)buff+cpy, m_buffLoop+*m_offset, count);
            *m_offset += count;
        }

        return sz;
    }
    return 0;
}

uint16_t LoopQue::Count() const
{
    if (m_buffLoop)
    {
        if (*m_offset > *m_end)
            return m_sizeMax+*m_end-*m_offset;

        return *m_end - *m_offset;
    }
    return 0;
}

bool LoopQue::IsValid() const
{
    return m_buffLoop != NULL;
}

void LoopQue::Clear()
{
    if (IsValid() && m_end && m_offset)
    {
        *m_end = 0;
        *m_offset = 0;
    }
}
