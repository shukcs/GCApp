﻿#ifndef __PARSE_4G_H__
#define __PARSE_4G_H__

#include <stdbool.h>
#include <stdint.h>

class ShareMemory;
class LoopQue;
class Socket4G {
public:
	enum StatSock{
		None,
		Created,
		Connected,
		Sended,
		SendFail,
		Disconnected,
		Bussy,
	};
public:
	Socket4G(uint32_t id=0);
	virtual ~Socket4G();

	StatSock Poll(unsigned us);
	void Create4GSock();
	bool IsCreated()const;
	bool Close4GSock();
	void Connect(const char *host, unsigned short port);
	int SendBuff(const void *buff, unsigned len);
	int RecvBuff(void *buff, unsigned len);
	int RecvLength()const;
public:	
	static unsigned char* ToBigendian(unsigned char *buf, unsigned data);
	static const unsigned char *FromBigendian(const unsigned char *buf, unsigned &data);
    static char *GetSimId();
private:
    ShareMemory     *m_sockBuff;
    LoopQue         *m_bufRcv;
    LoopQue         *m_bufSnd;
    static  char    s_SimIdBuf[21];
};

#endif
