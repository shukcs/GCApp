﻿#ifndef __LOOP_QUE_H__
#define __LOOP_QUE_H__

#include <stdbool.h>
#include <stdint.h>

class LoopQue{
public:
    LoopQue(void *buff=NULL, uint16_t sz=0);

    bool InitLoopQue(void *buff, uint16_t sz);
    bool PushOne(uint8_t val);
    bool PopOne(uint8_t &val);
    bool Push(const void *buff, uint16_t sz);
    uint16_t Pop(void *buff, uint16_t sz);
    uint16_t Count()const;
    bool IsValid()const;
    void Clear();
private:
    uint16_t    m_sizeMax;
    uint16_t    *m_offset;
    uint16_t    *m_end;
    uint8_t     *m_buffLoop;
};

#endif
