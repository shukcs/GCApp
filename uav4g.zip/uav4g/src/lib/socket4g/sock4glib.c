﻿#include "sock4glib.h"
#include "string.h"

static const char *sBstr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static const uint8_t sRstr[] = {
    -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
    -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
    -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   62,   -1,   -1,   -1,   63,
    52,   53,   54,   55,   56,   57,   58,   59,   60,   61,   -1,   -1,   -1,   64,   -1,   -1,
    -1,   0,    1,    2,    3,    4,    5,    6,    7,    8,    9,    10,   11,   12,   13,   14,
    15,   16,   17,   18,   19,   20,   21,   22,   23,   24,   25,   -1,   -1,   -1,   -1,   -1,
    -1,   26,   27,   28,   29,   30,   31,   32,   33,   34,   35,   36,   37,   38,   39,   40,
    41,   42,   43,   44,   45,   46,   47,   48,   49,   50,   51,   -1,   -1,   -1,   -1,   -1
};

typedef union {
    int     nFlag;
    char    cData;
}FlagEnddian;

int str2int(const char *str, unsigned len, bool *suc)
{
    unsigned i = 0;
    int ret = 0;
    bool bBeg = false;
    bool bR = true;
    bool bHas = false;

    if (suc)
        *suc = false;

    for (; i < len; i++)
    {
        char c = str[i];
        if (bBeg)
        {
            if (c >= '0' && c <= '9')
            {
                ret = ret * 10 + c - '0';
                bHas = true;
                continue;
            }
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r')
                break;

            return 0;
        }

        if (c == '+')
        {
            bBeg = true;
        }
        else if (c == '-')
        {
            bBeg = true;
            bR = false;
        }
        else if (c >= '0' && c <= '9')
        {
            bBeg = true;
            bHas = true;
            ret = c - '0';
        }
    }
    if (bHas && suc)
        *suc = true;

    return bR ? ret : -ret;
}

int findString(const char *dst, int len, const char *cnt, int pos)
{
    const char *pBeg = dst;
    int count = strlen(cnt);
    if (pos < 0)
        pos = 0;
    
    pBeg += pos;
    for (; pos <= len - count; ++pos)
    {
        if (0 == strncmp(pBeg, cnt, (size_t)count))
            return pos;
        
        pBeg++;
    }
    return -1;
}

unsigned str2Ip(const char *host, int len)
{
    unsigned ret = 0;
    int i = 0;
    int pos = 0;
    len = len<0 ? (int)strlen(host) : len;
    if (len > 15)
        len = 15;

    for (;i<4;++i)
    {
        unsigned ip;
        bool suc = false;
        int tmp = i==3 ? len : findString(host, len, ".", pos);
        if (tmp < 0 || tmp == pos)
            return -1;

        ip = str2int(host + pos, tmp - pos, &suc);
        if (!suc || ip>255 || (i==0 && ip==0))
            return -1;
        ((unsigned char *)&ret)[i] = ip;
        pos = tmp + 1;
    }

    return ret;
}

int encodeBase64(const char *cnt, size_t len, char *base64, size_t bufLen)
{
    if (!cnt || len < 1 || !base64)
        return 0;

    size_t ret = ((len + 2) / 3) * 4;
    if (bufLen < ret)
        return 0;

    size_t pos = 0;
    for (size_t i = 0; i < len; i += 3)
    {
        size_t remain = len - i;
        base64[pos++] = sBstr[((cnt[i] >> 2) & 0x3f)];
        switch (remain)
        {
        case 1:
            base64[pos++] = sBstr[((cnt[i] << 4) & 0x30)];
            base64[pos++] = '=';
            base64[pos++] = '=';
            break;
        case 2:
            base64[pos++] = sBstr[((cnt[i] << 4) & 0x30) + ((cnt[i + 1] >> 4) & 0x0f)];
            base64[pos++] = sBstr[((cnt[i + 1] << 2) & 0x3c)];
            base64[pos++] = '=';
            break;
        default:
            base64[pos++] = sBstr[((cnt[i] << 4) & 0x30) + ((cnt[i + 1] >> 4) & 0x0f)];
            base64[pos++] = sBstr[((cnt[i + 1] << 2) & 0x3c) + ((cnt[i + 2] >> 6) & 0x03)];
            base64[pos++] = sBstr[(cnt[i + 2] & 0x3f)];
        }
    }
    if (pos < bufLen)
        base64[pos] = 0;

    return ret;
}

int decodeBase64(const uint8_t *input, char *cnt, size_t bufLen)
{
    size_t l = strlen((const char *)input);
    if (l==0 || l % 4)
        return 0;

    size_t ret = (l * 3) / 4;
    if ('=' == input[l - 1])
    {
        --ret;
        if ('=' == input[l - 2])
            --ret;
    }

    uint8_t c[4];
    for (size_t i = 0, pos = 0; i < l; i += 4)
    {
        for (int j = 0; j < 4; ++j)
        {
            c[j] = input[i + j] < 128 ? sRstr[input[i + j]] : 255;
            if (c[j] > 128)
                return 0;
        }

        cnt[pos++] = (uint8_t)(c[0] << 2 & 0xfc) + (c[1] >> 4 & 0x03);
        if (c[2] != 64)
            cnt[pos++] = (uint8_t)((c[1] << 4 & 0xf0) + (c[2] >> 2 & 0x0f));

        if (c[3] != 64)
            cnt[pos++] = (uint8_t)((c[2] << 6 & 0xf0) + c[3]);
    }

    return ret;
}

bool isBigEndian(void)
{
    static const FlagEnddian sFlag = { 1 };
    return sFlag.cData == sFlag.nFlag;
}

uint16_t bytesToUShort(const char *src)
{
    uint16_t value;
    if (isBigEndian())
    {
        for (size_t i = 0; i < sizeof(value); ++i)
        {
            ((char *)&value)[i] = src[sizeof(value) - i - 1];
        }
    }
    else
    {
        memcpy(&value, src, sizeof(value));
    }
    return value;
}

uint32_t bytesToUint32(const char *src)
{
    uint32_t value;
    if (isBigEndian())
    {
        for (size_t i = 0; i < sizeof(value); ++i)
        {
            ((char *)&value)[i] = src[sizeof(value) - i - 1];
        }
    }
    else
    {
        memcpy(&value, src, sizeof(value));
    }
    return value;
}

void hex2str(char *dest, const uint8_t *src, int nLen)
{
	char ddh,ddl;

	for (int i=0; i<nLen; i++)
	{
		ddh = 48 + src[i] / 16;
		ddl = 48 + src[i] % 16;
		if (ddh > 57) ddh = ddh + 39;
		if (ddl > 57) ddl = ddl + 39;
		dest[i*2] = ddh;
		dest[i*2+1] = ddl;
	}
	dest[nLen*2] = '\0';
}

void str2hex(uint8_t *dest, const char *src, int nLen)
{
	char h1,h2;
	uint8_t s1,s2;

	for (int i=0; i<nLen; i++)
	{
		h1 = src[2*i];
		h2 = src[2*i+1];

		s1 = h1 - 0x30;
		if (s1 > 9) 
		s1 -= 39;

		s2 = h2 - 0x30;
		if (s2 > 9) 
		s2 -= 39;

		dest[i] = s1*16 + s2;
	}
}
