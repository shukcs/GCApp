/*************************************************************************
	> File Name: src/modules/mavlink/mavlink_obstacle.h
	> Author:
	> Mail:
	> Created Time: 2020年09月15日 星期二 14时20分35秒
 ************************************************************************/

#pragma once

#include <uORB/uORB.h>
#include <uORB/topics/obstacle_uorb.h>

#include "mavlink_bridge_header.h"
#include <drivers/drv_hrt.h>

class Mavlink;

class MavlinkObstacleInfo
{
public:
    MavlinkObstacleInfo(Mavlink *mavlink);

    void handle_message(const mavlink_message_t *msg);

    void obs_data_update();

    void send();

    Mavlink *_mavlink;

private:
    int _sub_obstacle_info{-1};
    obstacle_uorb_s _obs;
};

