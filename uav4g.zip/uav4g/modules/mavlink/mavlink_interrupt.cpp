/*************************************************************************
	> File Name: src/modules/mavlink/mavlink_interrupt.cpp
	> Author: 
	> Mail: 
	> Created Time: 2020年07月15日 星期三 15时33分50秒
 ************************************************************************/

#include "mavlink_interrupt.h"
#include "mavlink_main.h"

#include <uORB/topics/interrupt_point.h>
#include "cloudlink.h"

MavlinkInterruptPoint::MavlinkInterruptPoint(Mavlink *mavlink) :
    _mavlink(mavlink)
{
    _sub_interrupt_position = orb_subscribe(ORB_ID(interrupt_point));

}

void MavlinkInterruptPoint::handle_message(const mavlink_message_t *msg)
{
    switch(msg->msgid)
    {
        case MAVLINK_MSG_ID_INTERRUPT_POINT_ACK:
            handle_interrupt_point_ack(msg);
            break;
        default:
            break;
    }
}

void MavlinkInterruptPoint::handle_interrupt_point_ack(const mavlink_message_t *msg)
{
    _ack_accept = true;
}

void MavlinkInterruptPoint::send(const hrt_abstime t)
{
    bool update = false;
    orb_check(_sub_interrupt_position, &update);
    interrupt_point_s ip;
    
    if(update) {
        orb_copy(ORB_ID(interrupt_point), _sub_interrupt_position, &ip);
        _int_point_data.int_latitude = ip.int_latitude;
        _int_point_data.int_longitude = ip.int_longitude;
        _int_point_data.int_altitude = ip.int_altitude;
        _int_point_data.int_type = 1;
        _ack_accept = false;
        _resend_time = 0;
        PX4_INFO("update interrupt_point data: %d %d %d", _int_point_data.int_latitude, _int_point_data.int_longitude, _int_point_data.int_altitude);
    }

    if( !_ack_accept && (t-_resend_time)>1e6) {
        mavlink_msg_interrupt_point_encode(0, 0, &Mavlink::s_msgEn, &_int_point_data);
        CloudLink::SendMavLink(Mavlink::s_msgEn);
        mavlink_msg_interrupt_point_send_struct(_mavlink->get_channel(), &_int_point_data);
        PX4_INFO("resend interrupt_point data: %d %d %d", _int_point_data.int_latitude, _int_point_data.int_longitude, _int_point_data.int_altitude);
        _resend_time = t;
    }

}
