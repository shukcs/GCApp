﻿#ifndef __CLOUD_LINK_H__
#define __CLOUD_LINK_H__

#include <stdbool.h>
#include <v2.0/standard/mavlink.h>

enum ModeType
{
    Mode_Unknow = 0,
    Mode_Mission,
    Mode_Hold,
    Mode_Manual,
    Mode_Return,
    Mode_MagMsm,
    Mode_Landing,
    Mode_ABPoint,
    Mode_End,
};

namespace CloudLink {
	void InitialCloudLink(void);   //初始化
	bool IsCanSend(void);           //是否可以发送数据
	bool SendMavLink(const mavlink_message_t &msg);
	bool RecvMavLink(mavlink_message_t &msg);
	void UninitialCloudLink(void);      //退出
}

#endif /* __CLOUD_LINK_H__ */
