﻿#if !defined _WIN32 && !defined WIN64
#include "mavlink_bridge_header.h"
#endif
#include "mav4gbuff.h"

#if !defined _WIN32 && !defined WIN64
#include <px4_time.h>
#else
#include "sysfunc.h"
mavlink_system_t mavlink_system = { 1, 1 };
#endif
#include <src/lib/protobuf-c/proto/das.pb-c.h>

#define MaxMissionItem 100
#define MaxMavItem 20
#define MaxSendCount 5
#define TmBuffSndSpace 800
#define RC_CHNS 8
#define RC_SENDCOUNT 15
#define Check_Length(sz, len) if(sz < len)sz = len;
enum MavStat
{
    Unknow = 0,
    MissonRcving,
    MissonRcved,
    MissonReading,
    MissonReaded,
};

MAVPACKED (typedef struct {
    bool        lock : 1;
    bool        bSnd : 1;
    bool        bSndItem : 1;
    bool        bNewMission : 1;
    uint8_t     stat : 4;
    uint8_t     msType;
    uint8_t     szMavLink;
    uint8_t     szMissions;
    uint8_t     szBoundarys;
    uint8_t     szRcvOrRead;
    uint8_t     szCount;
    uint32_t    tmLastSendBuff;
}) MavBuffStat;

MAVPACKED(typedef struct _RcChannelsData{
    uint16_t msgId;
    uint32_t msBoot;
    uint16_t valRC[RC_CHNS];
    uint8_t  bUpdate;
    uint8_t  sendCnt;
}) RcChannelsData;

MAVPACKED(typedef struct tag_BuffBDt {
    bool bRcv : 1;
    uint8_t msgLen : 7;
    uint16_t msgid : 16;
    uint8_t payload[MAVLINK_MSG_ID_MISSION_ITEM_INT_LEN - 1];
}) MavPayload;

typedef struct {
    uint16_t tmp;
    uint8_t missionItem[MAVLINK_MSG_ID_MISSION_ITEM_INT_LEN];
} MissionBuff;

static MissionBuff s_MissonItems[MaxMissionItem];
static MavPayload s_mavItems[MaxMavItem] = {0};
static mavlink_message_t s_mavEnMsg = { 0 };
static MavBuffStat s_statMav = { 0 };
static RcChannelsData s_rcChannelsData = { MAVLINK_MSG_ID_RC_CHANNELS, 0 };

static uint16_t curMissionSize(void);
static uint16_t switchStat(uint16_t st);
static int getFirstMavItem(bool bRcv, uint16_t beg);
static void processMissionItem(const uint8_t *buff, unsigned len);
static int prcsMavCommand(const uint8_t *buff, unsigned len);
static int prcsMissionAck(const mavlink_message_t &msg);
static int packMavLinkBuff(ProtobufCBinaryData *buf, int &sz);
static int packMissionItem(ProtobufCBinaryData *buf, int sz);
static uint16_t getMavlinkPackSize(uint16_t len);
static int prcsSpecialMavlink(uint16_t msgId, const uint8_t *buff, unsigned len);
static uint16_t curMissionCount(void);
static bool loadMission(mavlink_message_t &msg);
static bool requsetMission(mavlink_message_t &msg);

static void lock();
static void unlock();

static uint16_t curMissionSize(void)
{
    if (s_statMav.bSnd)
        return s_statMav.szMissions;

    return s_statMav.msType == MAV_MISSION_TYPE_MISSION ? s_statMav.szMissions : s_statMav.szBoundarys;
}

static uint16_t switchStat(uint16_t st)
{
    switch (s_statMav.stat)
    {
    case Unknow:
        if (st == MissonRcving)
            s_statMav.stat = st;
        break;
    case MissonRcving:
        if ( (st==MissonRcved && curMissionSize()==s_statMav.szRcvOrRead)
          || (st==MissonReading && curMissionSize()==0) )
            s_statMav.stat = st;
        break;
    case MissonRcved:
        if (st == MissonReading)
            s_statMav.stat = st;
        break;
    case MissonReading:
        if (st == MissonReaded)
            s_statMav.stat = st;
        break;
    case MissonReaded:
        if (st == Unknow || st == MissonRcving)
            s_statMav.stat = st;
        break;
    default:
        break;
    }
    return s_statMav.stat;
}

static int getFirstMavItem(bool bRcv, uint16_t beg)
{
    for (uint16_t i = 0; i < s_statMav.szMavLink;)
    {
        if (i >= beg && s_mavItems[i].bRcv == bRcv)
            return i;

        i += getMavlinkPackSize(s_mavItems[i].msgLen);
    }
    return -1;
}

static void processMissionItem(const uint8_t *buff, unsigned len)
{
    if (len > MAVLINK_MSG_ID_MISSION_ITEM_INT_LEN || s_statMav.stat != MissonRcving)
        return;

    s_mavEnMsg.msgid = MAVLINK_MSG_ID_MISSION_ITEM_INT;
    s_mavEnMsg.len = len;
    memcpy(s_mavEnMsg.payload64, buff, len);
    mavlink_mission_item_int_t msItem;
    mavlink_msg_mission_item_int_decode(&s_mavEnMsg, &msItem);
    if (msItem.seq + 1 == s_statMav.szMissions)
        s_statMav.bSndItem = false;

    Mav4GBuff::saveMissionItem(buff, len, msItem.seq);
}

static int prcsMavCommand(const uint8_t *buff, unsigned len)
{
    if (!buff || len > 64)
        return -1;

    s_mavEnMsg.msgid = MAVLINK_MSG_ID_COMMAND_LONG;
    s_mavEnMsg.len = len;
    memcpy(s_mavEnMsg.payload64, buff, len);
    mavlink_command_int_t cmd;
    mavlink_msg_command_int_decode(&s_mavEnMsg, &cmd);
    len = (unsigned)(cmd.param1+0.1f);
    if (cmd.command == MAV_CMD_COMPONENT_ARM_DISARM)
        return len != 0 ? MAV_CMD_COMPONENT_ARM_DISARM : -1;

    return -1;
}

static int prcsMissionAck(const mavlink_message_t &msg)
{
    mavlink_mission_ack_t ack;
    mavlink_msg_mission_ack_decode(&msg, &ack);
    if (s_statMav.bSnd && MissonReaded==switchStat(MissonReaded))
    {
        s_statMav.bSnd = false;
        s_statMav.bSndItem = false;
        s_statMav.szMissions = 0;
        s_statMav.szRcvOrRead = 0;
    }
    return msg.msgid;
}

static int packMavLinkBuff(ProtobufCBinaryData *buf, int &sz)
{
    size_t szMav = 0;
    int nPack = 0;
    uint16_t i = 0;
    if (s_rcChannelsData.bUpdate)
    {
        if (--s_rcChannelsData.sendCnt == 0)
            s_rcChannelsData.bUpdate = false;
        nPack = RC_CHNS*2+6;
        buf[i].len = nPack;
        buf[i].data = (uint8_t *)&s_rcChannelsData;
        ++i;
    }
    MavPayload *buff = NULL;
    for (; i < sz; ++i)
    {
        int idx = getFirstMavItem(false, szMav);
        if (idx < 0)
            break;

        buff = &s_mavItems[idx];
        nPack += buff->msgLen + 6;
        if (nPack > 200)
            break;

        buf[i].len = buff->msgLen + sizeof(uint16_t);
        buf[i].data = buff->payload - sizeof(uint16_t);
        szMav++;
    }
    sz = i < sz ? i : sz;
    return szMav;
}

static int packMissionItem(ProtobufCBinaryData *buf, int sz)
{
    size_t szMav = 0;
    if (s_statMav.szCount > MaxSendCount)
    {
        s_statMav.stat = Unknow;
        s_statMav.bSnd = false;
        s_statMav.szMissions = 0;
        s_statMav.szCount = 0;
        return -1;
    }
    int nPack = 0;
    if (0 == s_statMav.szRcvOrRead && !s_statMav.bSndItem)
    {
        mavlink_msg_mission_count_pack_chan(0, 0, 0, &s_mavEnMsg, 0, 0, s_statMav.szMissions, s_statMav.msType);
        memcpy(s_MissonItems[MaxMissionItem - 1].missionItem, s_mavEnMsg.payload64, s_mavEnMsg.len);
        s_MissonItems[MaxMissionItem - 1].tmp = s_mavEnMsg.msgid;
        buf->len = s_mavEnMsg.len + sizeof(uint16_t);
        buf->data = (uint8_t*)&s_MissonItems[MaxMissionItem - 1].tmp;
        nPack = buf->len+4;
        ++s_statMav.szCount;
        return 1;
    }
    if (!s_statMav.bSndItem)
        return 0;

    for (int i = 0; i < sz; ++i)
    {
        if (s_statMav.szRcvOrRead + i >= s_statMav.szMissions)
            break;

        nPack += MAVLINK_MSG_ID_MISSION_ITEM_INT_LEN + 6;
        if (nPack > 200)
            break;
        buf[i].len = MAVLINK_MSG_ID_MISSION_ITEM_INT_LEN + sizeof(uint16_t);
        buf[i].data = (uint8_t*)&s_MissonItems[s_statMav.szRcvOrRead+i].tmp;
        ++szMav;
    }
    ++s_statMav.szCount;
    return szMav;
}

static uint16_t getMavlinkPackSize(uint16_t len)
{
    return (len+3+sizeof(MavPayload)-1) / sizeof(MavPayload);
}

static int prcsSpecialMavlink(uint16_t msgId, const uint8_t *buff, unsigned len)
{
    if (msgId==MAVLINK_MSG_ID_COMMAND_LONG || msgId==MAVLINK_MSG_ID_COMMAND_INT)
    {
        if (MAV_CMD_COMPONENT_ARM_DISARM == prcsMavCommand(buff, len))
            return MAV_CMD_COMPONENT_ARM_DISARM;
    }
    else if (msgId == MAVLINK_MSG_ID_MISSION_REQUEST_INT || msgId == MAVLINK_MSG_ID_MISSION_REQUEST)
    {
        s_mavEnMsg.len = len;
        memcpy(s_mavEnMsg.payload64, buff, len);
        s_mavEnMsg.msgid = MAVLINK_MSG_ID_MISSION_REQUEST_INT;
        Mav4GBuff::prcsMissionReq(s_mavEnMsg);
        s_statMav.bSndItem = true;
        return msgId;
    }
    else if (msgId == MAVLINK_MSG_ID_MISSION_ACK)
    {
        s_mavEnMsg.len = len;
        memcpy(s_mavEnMsg.payload64, buff + sizeof(uint16_t), len);
        s_mavEnMsg.msgid = MAVLINK_MSG_ID_MISSION_ACK;
        s_statMav.szCount = 0;
        return prcsMissionAck(s_mavEnMsg);
    }

    return -1;
}

uint16_t curMissionCount()
{
    if (s_statMav.bSnd)
        return s_statMav.szMissions;

    return s_statMav.msType == MAV_MISSION_TYPE_MISSION ? s_statMav.szMissions : s_statMav.szBoundarys;
}

static bool loadMission(mavlink_message_t &msg)
{
    uint16_t count = curMissionSize();
    if (s_statMav.szRcvOrRead > count || switchStat(MissonReading) != MissonReading)
        return false;

    memset(&msg, 0, sizeof(msg));
    if (count == s_statMav.szRcvOrRead)
    {
        mavlink_mission_count_t missionCount = { 0 };
        msg.magic = MAVLINK_STX;
        missionCount.target_system = mavlink_system.sysid;
        missionCount.target_component = MAV_COMP_ID_MISSIONPLANNER;
        missionCount.count = count;
        missionCount.mission_type = s_statMav.msType;
        mavlink_msg_mission_count_encode(mavlink_system.sysid, MAV_COMP_ID_ALL, &msg, &missionCount);
    }
    else
    {
        memcpy(msg.payload64, s_MissonItems[s_statMav.szRcvOrRead].missionItem, MAVLINK_MSG_ID_MISSION_ITEM_INT_LEN);
        msg.magic = MAVLINK_STX;
        msg.msgid = MAVLINK_MSG_ID_MISSION_ITEM_INT;
        msg.compid = MAV_COMP_ID_ALL;
        msg.sysid = mavlink_system.sysid;
        msg.len = MAVLINK_MSG_ID_MISSION_ITEM_INT_LEN;
    }
    s_statMav.szRcvOrRead = count + 1;
    return true;
}

static bool requsetMission(mavlink_message_t &msg)
{
    if (s_statMav.szRcvOrRead > s_statMav.szMissions || s_statMav.szMissions == 0)
        return false;

    if (s_statMav.szRcvOrRead<s_statMav.szMissions && s_statMav.stat == MissonRcving)
    {
        mavlink_mission_request_int_t req = { 0 };
        req.seq = s_statMav.szRcvOrRead;
        req.mission_type = s_statMav.msType;
        req.target_system = mavlink_system.sysid;
        req.target_component = MAV_COMP_ID_MISSIONPLANNER;
        mavlink_msg_mission_request_int_encode(mavlink_system.sysid, MAV_COMP_ID_ALL, &msg, &req);
        return true;
    }
    else if (s_statMav.szRcvOrRead == s_statMav.szMissions && s_statMav.stat == MissonRcved)
    {
        mavlink_mission_ack_t ack = { 0 };
        ack.type = MAV_MISSION_ACCEPTED;
        ack.mission_type = s_statMav.msType;
        ack.target_system = mavlink_system.sysid;
        ack.target_component = mavlink_system.compid;
        mavlink_msg_mission_ack_encode(mavlink_system.sysid, MAV_COMP_ID_ALL, &msg, &ack);
        switchStat(MissonReading);
        s_statMav.szRcvOrRead = 0;
        return true;
    }
    return false;
}

static void lock()
{
    while (s_statMav.lock)
    {
        usleep(1e3);
    }
    s_statMav.lock = true;
}

static void unlock()
{
    s_statMav.lock = false;
}
//*************************************************************************
//**namespace Mav4GBuff
//*************************************************************************
int Mav4GBuff::hasMavInBuff(uint32_t tmCurMs)
{
    if (tmCurMs - s_statMav.tmLastSendBuff < TmBuffSndSpace)
        return false;

    if (s_statMav.bSnd
      && MissonReading == s_statMav.stat
      && s_statMav.szMissions > 0
      && s_statMav.szRcvOrRead < s_statMav.szMissions)
        return true;

    if (s_rcChannelsData.bUpdate)
        return true;

    for (uint16_t i = 0; i < s_statMav.szMavLink;)
    {
        if (!s_mavItems[i].bRcv)
            return true;

        i += getMavlinkPackSize(s_mavItems[i].msgLen);
    }
    return false;
}

bool Mav4GBuff::loadMavMessage(mavlink_message_t &msg)
{
    if (s_statMav.bNewMission)
    {
        s_statMav.bNewMission = false;
        mavlink_msg_mission_request_list_pack_chan(mavlink_system.sysid, MAV_COMP_ID_ALL,
            0, &msg, mavlink_system.sysid, mavlink_system.compid, MAV_MISSION_TYPE_AOBPATH);

        return true;
    }

    int idx = getFirstMavItem(true, 0);
    if (idx < 0)
        return false;

    lock();
    MavPayload &buff = s_mavItems[idx];
    msg.magic = MAVLINK_STX;
    msg.msgid = buff.msgid;
    msg.len = buff.msgLen;
    msg.compid = MAV_COMP_ID_ALL;
    msg.sysid = mavlink_system.sysid;
    memcpy(msg.payload64, buff.payload, msg.len);
    unlock();
    notifyPackFinish(1, true);
    return true;
}

bool Mav4GBuff::prcsUplaodMission(int msns, int bdrs)
{
    if (bdrs<=MaxMissionItem && msns<=MaxMissionItem && MissonRcving == switchStat(MissonRcving))
    {
        s_statMav.szMissions = msns;
        s_statMav.szBoundarys = bdrs;
        s_statMav.szRcvOrRead = 0;
        s_statMav.msType = MAV_MISSION_TYPE_MISSION;
        if (msns == 0)
            switchStat(MissonRcved);

        return true;
    }
    return false;
}

bool Mav4GBuff::saveMissionItem(const uint8_t *buff, uint16_t len, uint16_t seq)
{
    if (len > MAVLINK_MSG_ID_MISSION_ITEM_INT_LEN || s_statMav.stat != MissonRcving)
        return false;

    if (seq<MaxMissionItem && len<=MAVLINK_MSG_ID_MISSION_ITEM_INT_LEN && seq==s_statMav.szRcvOrRead)
    {
        uint8_t *bufItem = s_MissonItems[seq].missionItem;
        s_MissonItems[seq].tmp = MAVLINK_MSG_ID_MISSION_ITEM_INT;
        memcpy(bufItem, buff, len);
        _mav_put_uint8_t(bufItem, 32, mavlink_system.sysid);
        _mav_put_uint8_t(bufItem, 33, MAV_COMP_ID_ALL);

        if (s_statMav.msType == MAV_MISSION_TYPE_MISSION)
            _mav_put_uint8_t(bufItem, 35, seq==0 ? 1 : 0);
        _mav_put_uint8_t(bufItem, 37, s_statMav.msType);

        if (curMissionCount() == ++s_statMav.szRcvOrRead)
            switchStat(MissonRcved);

        return true;
    }

    return false;
}

bool Mav4GBuff::loadMissionItem(mavlink_message_t &msg)
{
    if(!s_statMav.bSnd)
        return loadMission(msg);

    return requsetMission(msg);
}

int Mav4GBuff::missionRemaim(uint32_t &offset)
{
    if (s_statMav.stat != MissonRcving || s_statMav.bSnd)
        return 0;

    offset = s_statMav.szRcvOrRead;
    if (!s_statMav.bSnd && s_statMav.msType == MAV_MISSION_TYPE_OBSTACLE && s_statMav.szBoundarys > 0)
        return s_statMav.szBoundarys-s_statMav.szRcvOrRead;
    else if (s_statMav.szMissions > 0)
        return s_statMav.szMissions-s_statMav.szRcvOrRead;

    return 0;
}

uint8_t Mav4GBuff::missionType()
{
    return s_statMav.msType;
}

bool Mav4GBuff::notifyMissionRcved(uint32_t res)
{
    if (MissonReaded != switchStat(MissonReaded))
        return false;

    if (res != MAV_MISSION_ACCEPTED)
    {
        s_statMav.szMissions = 0;
        return true;
    }

    if(s_statMav.msType == MAV_MISSION_TYPE_OBSTACLE)
        s_statMav.szBoundarys = 0;
    else
        s_statMav.szMissions = 0;

    if (s_statMav.msType == MAV_MISSION_TYPE_MISSION)
    {
        s_statMav.szRcvOrRead = 0;
        s_statMav.msType = MAV_MISSION_TYPE_OBSTACLE;
        switchStat(MissonRcving);
    }

    return true;
}

void Mav4GBuff::prcsMissionReq(const mavlink_message_t &msg)
{
    mavlink_mission_request_t req;
    mavlink_msg_mission_request_decode(&msg, &req);
    if (req.seq < curMissionCount())
    {
        s_statMav.szRcvOrRead = req.seq;
        s_statMav.szCount = 0;
    }
}

void Mav4GBuff::prcsMissionSend(const mavlink_message_t &msg)
{
    if (msg.msgid == MAVLINK_MSG_ID_MISSION_COUNT)
    {
        if (MissonRcving != switchStat(MissonRcving))
            return;

        mavlink_mission_count_t msCount;
        mavlink_msg_mission_count_decode(&msg, &msCount);
        if (msCount.count > 0 && msCount.count < MaxMissionItem)
        {
            s_statMav.szMissions = msCount.count;
            s_statMav.szRcvOrRead = 0;
            s_statMav.msType = msCount.mission_type;
            s_statMav.bSnd = true;
        }
        else if (msCount.count==0 && s_statMav.bSnd)
        {
            s_statMav.bSnd = false;
            s_statMav.stat = Unknow;
        }
    }
    else if (msg.msgid == MAVLINK_MSG_ID_MISSION_ITEM_INT)
    {
        processMissionItem((uint8_t*)msg.payload64, msg.len);
    }
}

bool Mav4GBuff::saveParameter(const char *id, float value, uint8_t type)
{
    if (!id || s_statMav.szMavLink > 20)
        return false;

    char paramId[16] = {0};
    strncpy(paramId, id, sizeof(paramId));

    lock();
    MavPayload *buff = &s_mavItems[s_statMav.szMavLink++];
    buff->bRcv = true;
    mavlink_msg_param_set_pack(mavlink_system.sysid, MAV_COMP_ID_ALL, &s_mavEnMsg, mavlink_system.sysid, mavlink_system.compid, paramId, value, type);
    memcpy(buff->payload, s_mavEnMsg.payload64, s_mavEnMsg.len);
    buff->msgid = s_mavEnMsg.msgid;
    buff->msgLen = s_mavEnMsg.len;
    unlock();
    return true;
}

void Mav4GBuff::loadParameter(const char*id)
{
    if (!id || s_statMav.szMavLink > MaxMavItem)
        return;

    char paramId[16];
    strncpy(paramId, id, sizeof(paramId));

    lock();
    MavPayload *buff = &s_mavItems[s_statMav.szMavLink++];
    buff->bRcv = true;
    mavlink_msg_param_request_read_pack(mavlink_system.sysid, MAV_COMP_ID_ALL, &s_mavEnMsg, mavlink_system.sysid, mavlink_system.compid, paramId, -1);
    memcpy(buff->payload, s_mavEnMsg.payload64, s_mavEnMsg.len);
    buff->msgid = s_mavEnMsg.msgid;
    buff->msgLen = s_mavEnMsg.len;
    unlock();
}

bool Mav4GBuff::notifyAckPositionAuthentication(int res)
{
    if (s_statMav.szMavLink + 2 > MaxMavItem)
        return false;

    mavlink_command_long_t  cmdMav = {0};
    cmdMav.command = MAV_CMD_COMPONENT_ARM_DISARM;
    cmdMav.confirmation = 0;
    cmdMav.param1 = 1;
    cmdMav.target_system = mavlink_system.sysid;
    cmdMav.target_component = mavlink_system.compid;
    mavlink_msg_command_long_encode_chan(0,0,0, &s_mavEnMsg, &cmdMav);

    lock();
    MavPayload *buff = &s_mavItems[s_statMav.szMavLink];
    buff->bRcv = true;
    memcpy(buff->payload, s_mavEnMsg.payload64, s_mavEnMsg.len);
    buff->msgid = s_mavEnMsg.msgid;
    buff->msgLen = s_mavEnMsg.len;
    s_statMav.szMavLink += getMavlinkPackSize(buff->msgLen);
    unlock();
    return true;
}

void Mav4GBuff::notifyNewMission(void)
{
    s_statMav.bNewMission = true;
}

void Mav4GBuff::notifyPackFinish(int packs, bool bRcv)
{
    if (packs < 1)
        return;

    int idx = 0;
    MavPayload *buff = NULL;
    lock();
    for (int i = 0; i < packs; ++i)
    {
        idx = getFirstMavItem(bRcv, 0);
        if (idx < 0)
            break;

        buff = &s_mavItems[idx];
        uint16_t szLoad = getMavlinkPackSize(buff->msgLen);
        if (idx + szLoad < s_statMav.szMavLink)
            memcpy(buff, buff + szLoad, (s_statMav.szMavLink - idx - szLoad) * sizeof(MavPayload));
        s_statMav.szMavLink -= szLoad;
    }
    unlock();
}

int Mav4GBuff::prcsMavLink(const ProtobufCBinaryData &buf, uint32_t tmCurMs)
{
    uint32_t len = buf.len;
    if (len <= sizeof(uint16_t))
        return -1;
    len -= sizeof(uint16_t);
    uint16_t idMsg = *(uint16_t*)buf.data;
    int id = prcsSpecialMavlink(idMsg, buf.data + sizeof(uint16_t), len);
    if (id > 0)
    {
        if(id == MAVLINK_MSG_ID_MISSION_REQUEST_INT || id == MAVLINK_MSG_ID_MISSION_REQUEST)
            s_statMav.tmLastSendBuff = tmCurMs - TmBuffSndSpace;
        return id;
    }

    saveMavLink(idMsg, (char*)buf.data + sizeof(uint16_t), len);
    return -1;
}

void Mav4GBuff::saveMavLink(uint32_t id, const void *payLoad, uint16_t len)
{
    uint16_t szSave = getMavlinkPackSize(len);
    if ( s_statMav.szMavLink+szSave > MaxMavItem
      || id == MAVLINK_MSG_ID_HEARTBEAT
      || len > 127 )
        return;

    lock();
    MavPayload *mav = &s_mavItems[s_statMav.szMavLink];
    mav->msgid = id;
    mav->msgLen = len;
    memcpy(mav->payload, payLoad, len);
    uint8_t *bufPl = mav->payload;
    mav->bRcv = true;
    switch (mav->msgid)
    {
    case MAVLINK_MSG_ID_SET_MODE:
        Check_Length(mav->msgLen, 5);
        _mav_put_uint8_t(bufPl, 4, mavlink_system.sysid);
        break;
    case MAVLINK_MSG_ID_MISSION_REQUEST_LIST:
        Check_Length(mav->msgLen, 2);
        _mav_put_uint8_t(bufPl, 0, mavlink_system.sysid);
        _mav_put_uint8_t(bufPl, 1, mavlink_system.compid);
        break;
    case MAVLINK_MSG_ID_COMMAND_INT:
    case MAVLINK_MSG_ID_COMMAND_LONG:
        Check_Length(mav->msgLen, 32);
        _mav_put_uint8_t(bufPl, 30, mavlink_system.sysid);
        _mav_put_uint8_t(bufPl, 31, mavlink_system.compid);
        break;
    case MAVLINK_MSG_ID_PARAM_SET:
        Check_Length(mav->msgLen, 6);
        _mav_put_uint8_t(bufPl, 4, mavlink_system.sysid);
        _mav_put_uint8_t(bufPl, 5, mavlink_system.compid);
        break;
    case MAVLINK_MSG_ID_PARAM_REQUEST_READ:
        Check_Length(mav->msgLen, 4);
        _mav_put_uint8_t(bufPl, 2, mavlink_system.sysid);
        _mav_put_uint8_t(bufPl, 3, mavlink_system.compid);
        break;
    case MAVLINK_MSG_ID_SET_HOME_POSITION:
        Check_Length(mav->msgLen, 52);
        _mav_put_uint8_t(bufPl, 52, mavlink_system.sysid);
        break;
    case MAVLINK_MSG_ID_QX_ACCOUNT:
        Check_Length(mav->msgLen, 33); break;
    case MAVLINK_MSG_ID_QX_ACC_CMD:
        Check_Length(mav->msgLen, 1); break;
    case MAVLINK_MSG_ID_INTERRUPT_POINT_ACK:
        Check_Length(mav->msgLen, 1); break;
    case MAVLINK_MSG_ID_QXSDK_ACCOUNT:
        Check_Length(mav->msgLen, 54); break;
    case MAVLINK_MSG_ID_QXSDK_ACC_CMD:
        Check_Length(mav->msgLen, 1); break;
    default:
        unlock(); return;
    }
    s_statMav.szMavLink += szSave;
    unlock();
}

bool Mav4GBuff::prcsNormalMav(const mavlink_message_t &msg)
{
    int szSend = getMavlinkPackSize(msg.len);
    if (s_statMav.szMavLink +szSend > MaxMavItem || msg.len>127)
        return false;

    lock();
    MavPayload *buff = s_mavItems+s_statMav.szMavLink;
    buff->bRcv = false;
    memcpy(buff->payload, msg.payload64, msg.len);
    buff->msgid = msg.msgid;
    buff->msgLen = msg.len;
    s_statMav.szMavLink += szSend;
    unlock();
    return true;
}

void Mav4GBuff::prcsRCChannels(const mavlink_message_t &msg)
{
    if (msg.msgid != MAVLINK_MSG_ID_RC_CHANNELS)
        return;

    mavlink_rc_channels_t rc;
    mavlink_msg_rc_channels_decode(&msg, &rc);
    s_rcChannelsData.msBoot = rc.time_boot_ms;
    for (int i = 0; i<RC_CHNS; ++i)
    {
        uint16_t raw = *(&rc.chan1_raw + i);
        int dif = int(s_rcChannelsData.valRC[i]) - raw;
        if (dif < -5 || dif > 5)
        {
            s_rcChannelsData.valRC[i] = raw;
            s_rcChannelsData.sendCnt = RC_SENDCOUNT;
            s_rcChannelsData.bUpdate = true;
        }
    }
}

int Mav4GBuff::packMavLink(ProtobufCBinaryData *buf, int &sz, uint32_t ms)
{
    if (!buf || sz < 1)
        return sz = 0;

    s_statMav.tmLastSendBuff = ms;
    if (!s_statMav.bSnd)
        return packMavLinkBuff(buf, sz);

    if ( s_statMav.szMissions > 0
      && s_statMav.szRcvOrRead < s_statMav.szMissions
      && MissonReading == s_statMav.stat )
        sz = packMissionItem(buf, sz);
    else
        sz = 0;

    return 0;
}

size_t Mav4GBuff::packRequestMission(ProtobufCBinaryData *buf, uint16_t seq)
{
    if (!buf)
        return 0;

    mavlink_msg_mission_request_pack(0, 0, &s_mavEnMsg, 0, 0, seq, 3);
    MissionBuff *buff = s_MissonItems+MaxMissionItem - 1;
    buff->tmp = MAVLINK_MSG_ID_MISSION_REQUEST_INT;
    memcpy(buff->missionItem, s_mavEnMsg.payload64, s_mavEnMsg.len);

    buf->len = s_mavEnMsg.len + sizeof(uint16_t);
    buf->data = buff->missionItem - sizeof(uint16_t);
    return 1;
}

void Mav4GBuff::initialBuf(uint32_t ms)
{
    memset(&s_statMav, 0, sizeof(s_statMav));
    s_statMav.tmLastSendBuff = ms;
}
