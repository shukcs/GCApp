#ifndef _MAV_LIGHT_DEFINES_H_
#define _MAV_LIGHT_DEFINES_H_

#include <dataman/dataman.h>
#include "mavlink_bridge_header.h"

typedef struct _mav_mission_dm_read_request_s{
	dm_item_t item;
	unsigned index;
	size_t readlen;
}mav_mission_dm_read_request_s;

typedef struct _mav_mission_dm_read_result_s{
	dm_item_t item;
	unsigned index;
	ssize_t ret_len;
	uint8_t buff[80];	//sizeof() must be less than 103(mav_mission_fromfmu.msg_buff)
}mav_mission_dm_read_result_s;

typedef struct _mav_mission_dm_write_request_s{
	dm_item_t item;
	unsigned index;
	dm_persitence_t persistence;
	size_t writelen;
	uint8_t buff[80];
}mav_mission_dm_write_request_s;

typedef struct _mav_mission_dm_write_result_s{
	dm_item_t item;
	unsigned index;
	dm_persitence_t persistence;
	ssize_t result;
}mav_mission_dm_write_result_s;

typedef struct _mav_param_get_request_s{
	char param_name[MAVLINK_MSG_PARAM_VALUE_FIELD_PARAM_ID_LEN];
}mav_param_get_request_s;

typedef struct _mav_param_set_request_s{
	mavlink_param_set_t set_value;
}mav_param_set_request_s;

//both MAVLINK_MSG_ID_PARAM_REQUEST_READ and MAVLINK_MSG_ID_PARAM_SET use the same frame(#22 MAVLINK_MSG_ID_PARAM_VALUE) to answer QGC
typedef struct _mav_param_result_s{
	uint8_t result;	//0 means successful;
	mavlink_param_value_t param_value;
}mav_param_result_s;

#endif

