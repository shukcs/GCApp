/*************************************************************************
	> File Name: src/modules/mavlink/mavlink_obstacle.cpp
	> Author: 
	> Mail:
	> Created Time: 2020年09月15日 星期二 14时18分00秒
 ************************************************************************/

#include "mavlink_main.h"
#include "mavlink_obstacle.h"

#include <uORB/topics/obstacle_uorb.h>
#include "cloudlink.h"

MavlinkObstacleInfo::MavlinkObstacleInfo(Mavlink *mavlink) :
    _mavlink(mavlink)
{
    _sub_obstacle_info = orb_subscribe(ORB_ID(obstacle_uorb));

}

void MavlinkObstacleInfo::handle_message(const mavlink_message_t *msg)
{
    switch(msg->msgid)
    {
        case MAVLINK_MSG_ID_OBSTACLE_INFO:
            send();
            break;
        default:
            break;
    }
}

void MavlinkObstacleInfo::obs_data_update()
{
    bool update = false;
    
    orb_check(_sub_obstacle_info, &update);
    if(update) {
        orb_copy(ORB_ID(obstacle_uorb), _sub_obstacle_info, &_obs);
PX4_INFO("obstacle info update, num = %d", _obs.obs_count);
        if(_obs.obs_count == 0) {
            _mavlink->set_obstacle_info_state(false);
        } else {
            _mavlink->set_obstacle_info_state(true);
        }
    }
}

void MavlinkObstacleInfo::send()
{
    mavlink_obstacle_info_t msg_obs;

    memcpy( &msg_obs, &_obs, sizeof(mavlink_obstacle_info_t));
    mavlink_msg_obstacle_info_encode(0, 0, &Mavlink::s_msgEn, &msg_obs);
    CloudLink::SendMavLink(Mavlink::s_msgEn);
    mavlink_msg_obstacle_info_send_struct(_mavlink->get_channel(), &msg_obs);
}



