﻿#include "cloudlink.h"
#if !defined _WIN32 && !defined WIN64
#include <drivers/drv_hrt.h>
#include <px4_time.h>
#include <px4_log.h>
#include <px4_posix.h>
#else
#include "sysfunc.h"
#include <stdlib.h>
#endif

#include <src/lib/protobuf-c/proto/das.pb-c.h>
#include <string.h>
#include <crc32.h>
#include <commander/px4_custom_mode.h>
#include <socket4g/socket4g.h>
#include <socket4g/sock4glib.h>
#include "mav4gbuff.h"

#include "drivers/sim7600ce/drv4gdev.h"

#define PROTO_SIGNEG "das.proto."
#define PROTO_SIGNEGLEN 10
#define PROTO_RUIA "das.proto.RequestUavIdentityAuthentication"
#define PROTO_AUIA "AckUavIdentityAuthentication"
#define PROTO_POI  "das.proto.PostOperationInformation"
#define PROTO_AOI  "AckOperationInformation"
#define PROTO_PHB  "das.proto.PostHeartBeat"
#define PROTO_AHB  "AckHeartBeat"
#define PROTO_RPU  "das.proto.RequestProgramUpgrade"
#define PROTO_APU  "AckProgramUpgrade"
#define PROTO_RPD  "das.proto.RequestProgramDownload"
#define PROTO_APD  "AckProgramDownload"
#define PROTO_QPS  "QueryParameters"
#define PROTO_AQPS "das.proto.AckQueryParameters"
#define PROTO_CPS  "ConfigureParameters"
#define PROTO_ACPS "das.proto.AckConfigurParameters"
#define PROTO_UOR  "UploadOperationRoutes"
#define PROTO_AUOR "AckUploadOperationRoutes"
#define PROTO_RMSR  "das.proto.RequestRouteMissions"
#define PROTO_AMSR  "AckRequestRouteMissions"
#define PROTO_CTRLUAV "PostControl2Uav"
#define PROTO_CTRLGC "das.proto.PostStatus2GroundStation"
#define PROTO_RPAT "das.proto.RequestPositionAuthentication"
#define PROTO_APAT "AckPositionAuthentication"
#define PROTO_POSTRETURN "das.proto.PostOperationReturn"
#define PROTO_PBS "das.proto.PostBlocks"
#define RETURN_ACK "AckOperationReturn"
#define BLOCKS_ACK "AckBlocks"

#define NAMEPARAMUAVID "SYS_UAV_ID"
#define CLOUDHOSTID "HOST_IP"
#define CLOUDPORTID "HOST_PORT"
#define MaxMavSend 10
#define MissonResultRepeat 2

MAVPACKED(typedef struct {
    Socket4G *sock;
    bool bArm : 1;
    bool bInit : 1;
    bool bLinkCloud : 1;
    bool bhasReturn : 1;
    bool bHasUavId : 1;
    bool bHasHost : 1;
    bool bHasGlobal : 1;
    bool bDeniFly : 1;
    bool bSndBlocks : 1;
    int16_t stat4g : 5;
    uint16_t szRcv : 10;
    char uavType[7];
    char modeDesc[10];
    char idUav[20];
    char idMission[20];
    char host[17];
    uint8_t  msResRepeat;
    uint16_t port;
    uint8_t bufRcv[512];
    uint8_t bufSnd[256];
    uint32_t tmLastLink;
    uint32_t tmLastInfo;
    uint32_t tmLastBlock;
    uint32_t tmLastReqMission;
    uint32_t tmLastGlobal;
    uint32_t tmLastGps;
    uint32_t seqNumb;
    uint32_t customMode;
}) LinkInfo;

typedef union {
    float tmp[7];
    MAVPACKED(struct {
        float velocity[3];
        uint32_t precision : 16;    //航线精度
        uint32_t gndHeight : 16;    //地面高度
        uint32_t gpsVSpeed : 16;    //垂直速度
        uint32_t curMs : 16;        //当前任务点
        uint8_t fixType;            //定位模式及模块状态
        uint8_t baseMode;           //飞控模块状态
        uint8_t satellites;         //卫星数
        uint8_t sysStat;            //飞控状态
        uint8_t missionRes : 4;     //任务状态
        uint8_t voltageErr : 4;     //电压报警
        uint8_t sprayState : 4;     //喷洒报警
        uint8_t magneErr : 2;       //校磁报警
        uint8_t gpsJam : 1;         //GPS干扰
        uint8_t stDown : 1;         //下载状态 0:没有或者完成，1:正下载
        uint8_t sysType;            //飞控类型
    });
} GpsAdtionValue;

MAVPACKED(typedef struct {
    int32_t lat;            //维度
    int32_t lon;            //经度 
    int32_t angle : 16;     //角度
    uint32_t distance : 16; //距离
}) BlockInfo;

static const char *sModeDescs[Mode_End] = { "Unknow", "Mission", "Hold", "Manual", "Return", "MagMsm", "Landing", "ABPoint" };
static LinkInfo s_linkInfo = {0};
static GpsAdtionValue s_gpsVel = {0};
static BlockInfo s_blocks[3];

static _Das__Proto__RequestUavIdentityAuthentication s_uavCloudLogin;
static Das__Proto__PostOperationInformation s_postInfo;
static Das__Proto__OperationInformation *s_pProtoOp = NULL;
static Das__Proto__GpsInformation s_protoGps;
static Das__Proto__OperationStatus s_protoStatus;
static Das__Proto__UavAttitude s_protoAttitude;
static Das__Proto__PostStatus2GroundStation s_status2Gs;
static Das__Proto__RequestPositionAuthentication s_reqPosAuth;
static Das__Proto__RequestRouteMissions s_missionRequest;
static Das__Proto__PostOperationReturn s_missionReturn;
static Das__Proto__Coordinate  s_coorSuspend;
static Das__Proto__PostBlocks  s_pbBlocks;

static ProtobufCBinaryData s_dataSnd[MaxMavSend] = {0};

static void sendProtoBuff(uint32_t, uint32_t, const char *n);
static void loginCloud(void);
static unsigned processRcvBuff(uint32_t);
static void processRcv4GMav(uint32_t, const char *, const uint8_t *, uint32_t);
static void processUploadOperationRoutes(const Das__Proto__UploadOperationRoutes &p);
static void processMissionItem(const Das__Proto__AckRequestRouteMissions &p);
static void sendRequestMissionItem(uint32_t seq, int count, uint8_t);
static void sendUavInfo(void);
static void sendMavlink(uint32_t);
static void CheckSend(uint32_t ms);
static void LinkCheck(void);
static void prcsHeatbeat(const mavlink_message_t &msg);
static void prcsSysStatus(const mavlink_message_t &msg);
static void prcsPosition(const mavlink_message_t &msg);
static void prcsGps(const mavlink_message_t &msg);
static void prcsAttitude(const mavlink_message_t &msg);
static void prcsAltitude(const mavlink_message_t &msg);
static void prcsMissiondAck(const mavlink_message_t &msg);
static void prcsMissionCur(const mavlink_message_t &msg);
static bool prcsParamValue(const mavlink_message_t &msg);
static void prcsSpray(const mavlink_message_t &msg);
static void prcsInterrupt(const mavlink_message_t &msg);
static void prcsBlocks(const mavlink_message_t &msg);
static ModeType fromCustMode(uint32_t);

static void sendProtoBuff(uint32_t lenName, uint32_t lenMsg, const char *name)
{
    uint32_t len = lenName + sizeof(lenName) + lenMsg + sizeof(lenMsg);
    if (len > sizeof(s_linkInfo.bufSnd))
        return;

    uint8_t *ptr = Socket4G::ToBigendian(s_linkInfo.bufSnd, len);
    ptr = Socket4G::ToBigendian(ptr, lenName);
    memcpy(ptr, name, lenName);

    int crc_len = len - sizeof(lenMsg);
    uint32_t crc_sum = crc32part(s_linkInfo.bufSnd+sizeof(len), crc_len, 0xffffffffu) ^ 0xffffffffu;
    Socket4G::ToBigendian(s_linkInfo.bufSnd+len, crc_sum);
    s_linkInfo.sock->SendBuff(s_linkInfo.bufSnd, len + sizeof(crc_sum));
}

static void loginCloud(void)
{
    if (s_linkInfo.bHasUavId)
    {
        s_uavCloudLogin.seqno = ++s_linkInfo.seqNumb;
        s_uavCloudLogin.uavid = s_linkInfo.idUav;
        s_uavCloudLogin.extradata = Socket4G::GetSimId();

        uint32_t name_len = strlen(PROTO_RUIA)+1;
        uint8_t *ptr = s_linkInfo.bufSnd + name_len + 2*sizeof(unsigned);
        uint32_t msg_len = das__proto__request_uav_identity_authentication__pack(&s_uavCloudLogin, ptr);
        sendProtoBuff(name_len, msg_len, PROTO_RUIA);
    }
}

static unsigned processRcvBuff(unsigned ms)
{
    if(s_linkInfo.szRcv<18)
        return 0;

    int pos = findString((char *)s_linkInfo.bufRcv, s_linkInfo.szRcv, PROTO_SIGNEG, 8);
    pos -= 8;
    if (pos<0)
        return s_linkInfo.szRcv>17 ? 17 : s_linkInfo.szRcv;

    uint32_t len = 0;
    Socket4G::FromBigendian(s_linkInfo.bufRcv+pos, len);
    uint32_t name_len = 0;
    const char *strName = (const char *)Socket4G::FromBigendian(s_linkInfo.bufRcv+pos+sizeof(len), name_len);
    strName += PROTO_SIGNEGLEN;
    if (len+sizeof(uint32_t) > 512 || len < (sizeof(name_len) + sizeof(uint32_t)))
        return pos+18;
    else if(s_linkInfo.szRcv-pos < len+sizeof(uint32_t))
        return pos;

    uint32_t crc_sum = 0;
    Socket4G::FromBigendian(s_linkInfo.bufRcv+len+pos, crc_sum);
    if (crc_sum != (crc32part(s_linkInfo.bufRcv+pos+sizeof(len), len-sizeof(len), 0xffffffffu)^0xffffffffu))
    {
        PX4_WARN("CRC error");
        return pos+18;
    }
    uint8_t *ptrProto = s_linkInfo.bufRcv + pos + 2*sizeof(uint32_t) + name_len;
    processRcv4GMav(ms, strName, ptrProto, len-2*sizeof(uint32_t)-name_len);

    return pos+len+sizeof(uint32_t);
}

static void processRcv4GMav(uint32_t ms, const char *name, const uint8_t *buf, uint32_t len)
{
    if (0 == strncmp(name, PROTO_AUIA, strlen(PROTO_AUIA))/* AckOperationInformation */)
    {
        Das__Proto__AckUavIdentityAuthentication *ack
            = das__proto__ack_uav_identity_authentication__unpack(NULL, len, buf);
        if (ack && ack->result == 1)
        {
            s_linkInfo.bLinkCloud = true;
            s_linkInfo.tmLastInfo = ms - 2e3;
        }
        PX4_WARN("Login result:%d", ack->result);
        das__proto__ack_uav_identity_authentication__free_unpacked(ack, NULL);  
    }
    else if (0 == strncmp(name, PROTO_AOI, strlen(PROTO_AOI)))
    {
        Das__Proto__AckOperationInformation *ackOpt
            = das__proto__ack_operation_information__unpack(NULL, len, buf);
        if (ackOpt && ackOpt->result == 1)
        {
            if (s_linkInfo.msResRepeat > 0)
            {
                --s_linkInfo.msResRepeat;
                if (0 == s_linkInfo.msResRepeat)
                    s_gpsVel.missionRes = MAV_MISSION_RESULT_ENUM_END;
            }
            PX4_WARN("AckOperationInformation:%d", ackOpt->seqno);
        }
        das__proto__ack_operation_information__free_unpacked(ackOpt, NULL);
    }
    else if (0 == strncmp(name, PROTO_AMSR, strlen(PROTO_AMSR)))
    {
        Das__Proto__AckRequestRouteMissions *arrm
            = das__proto__ack_request_route_missions__unpack(NULL, len, buf);
        if (arrm && arrm->result == 1)
            processMissionItem(*arrm);

        das__proto__ack_request_route_missions__free_unpacked(arrm, NULL);
    }
    else if (0 == strncmp(name, PROTO_UOR, strlen(PROTO_UOR)))
    {
        Das__Proto__UploadOperationRoutes *uor
            = das__proto__upload_operation_routes__unpack(NULL, len, buf);
        if (uor && !strcmp(uor->uavid, s_linkInfo.idUav))
            processUploadOperationRoutes(*uor);

        das__proto__upload_operation_routes__free_unpacked(uor, NULL);
    }
    else if (0 == strncmp(name, PROTO_CTRLUAV, strlen(PROTO_CTRLUAV)))
    {
        _Das__Proto__PostControl2Uav *control2Uav
            = das__proto__post_control2_uav__unpack(NULL, len, buf);
        if (control2Uav && control2Uav->userid[0])
        {
            for (int i = 0; i < control2Uav->n_data; ++i)
            {
                int id = Mav4GBuff::prcsMavLink(control2Uav->data[i], ms);
                if (MAV_CMD_COMPONENT_ARM_DISARM == id)
                    s_linkInfo.bArm = true;
                else if (MAVLINK_MSG_ID_MISSION_ACK == id)
                    s_gpsVel.stDown = 0;
            }
        }
        if (control2Uav)
            das__proto__post_control2_uav__free_unpacked(control2Uav, NULL);
    }
    else if (0 == strncmp(name, PROTO_APAT, strlen(PROTO_APAT)))
    {
        Das__Proto__AckPositionAuthentication *apat = das__proto__ack_position_authentication__unpack(NULL, len, buf);
        if (apat && Mav4GBuff::notifyAckPositionAuthentication(apat->result))
            s_linkInfo.bArm = false;

        das__proto__ack_position_authentication__free_unpacked(apat, NULL);
    }
    else if (0 == strncmp(name, RETURN_ACK, strlen(RETURN_ACK)))
    {
        s_linkInfo.bhasReturn = false;
        s_missionReturn.suspend = NULL;
        s_missionReturn.mission = true;
    }
    else if (0 == strncmp(name, BLOCKS_ACK, strlen(BLOCKS_ACK)))
    {
        s_pbBlocks.n_blocks = 0;
        s_linkInfo.bSndBlocks = false;
    }
}

static void processUploadOperationRoutes(const Das__Proto__UploadOperationRoutes &route)
{
    strcpy(s_linkInfo.idMission, route.msid);
    if (Mav4GBuff::prcsUplaodMission(route.countmission, route.countboundary))
    {
        PX4_WARN("recv mission upload(missions:%d, boundary:%d)", route.countmission, route.countboundary);
        s_linkInfo.tmLastReqMission = hrt_absolute_time()/1e3-600;
        s_gpsVel.missionRes = MAV_MISSION_RESULT_ENUM_END;
        s_linkInfo.msResRepeat = 0;
    }
}

static void processMissionItem(const Das__Proto__AckRequestRouteMissions &item)
{
    unsigned seq = item.offset;

    for (int i=0; i<item.n_missions; ++i, ++seq)
    {
        MAV_MISSION_TYPE tp = item.boundary ? MAV_MISSION_TYPE_OBSTACLE : MAV_MISSION_TYPE_MISSION;
        if (Mav4GBuff::missionType() !=tp || !Mav4GBuff::saveMissionItem(item.missions[i].data, item.missions[i].len, seq))
            break;
    }
}

static void sendUavInfo(void)
{
    s_postInfo.seqno = ++s_linkInfo.seqNumb;
    if (s_protoStatus.surplusenergy>0)
        s_protoStatus.has_surplusenergy = true;
    if (s_protoStatus.voltage > 0)
        s_protoStatus.has_voltage = true;

    s_protoStatus.has_jetvelocity = true;
    if (s_protoStatus.sprayeddose>0)
        s_protoStatus.has_sprayeddose = true;

    uint32_t name_len = strlen(PROTO_POI) + sizeof(char);
    uint8_t *ptr = s_linkInfo.bufSnd + 2*sizeof(uint32_t) + name_len;
    size_t msg_len = das__proto__post_operation_information__pack(&s_postInfo, ptr);

    sendProtoBuff(name_len, msg_len, PROTO_POI);
}

static void sendRequestMissionItem(uint32_t seq, int count, uint8_t tp)
{
    s_missionRequest.seqno = ++s_linkInfo.seqNumb;
    s_missionRequest.count = count <= 0 ? -1 : count;
    s_missionRequest.offset = seq;
    s_missionRequest.uavid = s_linkInfo.idUav;
    s_missionRequest.boundary = tp != MAV_MISSION_TYPE_MISSION;

    uint32_t name_len = strlen(PROTO_RMSR) + sizeof(char);
    uint8_t *ptr = s_linkInfo.bufSnd + 2 * sizeof(uint32_t) + name_len;
    size_t msg_len = das__proto__request_route_missions__pack(&s_missionRequest, ptr);

    sendProtoBuff(name_len, msg_len, PROTO_RMSR);
}

static void sendMavlink(uint32_t ms)
{
    int packed = MaxMavSend;
    int szPack = Mav4GBuff::packMavLink(s_dataSnd, packed, ms);
    if (packed > 0)
    {
        s_status2Gs.seqno = ++s_linkInfo.seqNumb;
        s_status2Gs.n_data = packed;
        uint32_t name_len = strlen(PROTO_CTRLGC) + sizeof(char);
        uint8_t *ptr = s_linkInfo.bufSnd + 2 * sizeof(uint32_t) + name_len;
        uint32_t msg_len = das__proto__post_status2_ground_station__pack(&s_status2Gs, ptr);

        sendProtoBuff(name_len, msg_len, PROTO_CTRLGC);
        Mav4GBuff::notifyPackFinish(szPack, false);
    }
    else if (-1 == szPack)
    {
        s_gpsVel.stDown = 0;
    }
}

static void CheckSend(uint32_t ms)
{
    if (!s_linkInfo.bLinkCloud) //login
    {
        if (ms - s_linkInfo.tmLastLink >= 1e4)
        {
            loginCloud();
            s_linkInfo.tmLastLink = ms;
        }
    }
    else if (ms - s_linkInfo.tmLastInfo > 1200)
    {
        sendUavInfo();
        s_linkInfo.tmLastInfo = ms;
    }
    else if (s_linkInfo.bSndBlocks && ms - s_linkInfo.tmLastBlock > 500)
    {
        uint32_t name_len = strlen(PROTO_PBS) + sizeof(char);
        uint8_t *ptr = s_linkInfo.bufSnd + 2 * sizeof(uint32_t) + name_len;
        s_pbBlocks.seqno++;
        size_t msg_len = das__proto__post_blocks__pack(&s_pbBlocks, ptr);

        sendProtoBuff(name_len, msg_len, PROTO_PBS);
        s_linkInfo.tmLastBlock = ms;
    }
    else if (Mav4GBuff::hasMavInBuff(ms))
    {
        sendMavlink(ms);
    }
    else if (s_linkInfo.bArm && ms-s_linkInfo.tmLastReqMission>500)
    {
        s_reqPosAuth.seqno = ++s_linkInfo.seqNumb;

        uint32_t name_len = strlen(PROTO_RPAT) + sizeof(char);
        uint8_t *ptr = s_linkInfo.bufSnd + 2 * sizeof(uint32_t) + name_len;
        size_t msg_len = das__proto__request_position_authentication__pack(&s_reqPosAuth, ptr);

        sendProtoBuff(name_len, msg_len, PROTO_RPAT);
        s_linkInfo.tmLastReqMission = ms;
    }
    else if (ms-s_linkInfo.tmLastReqMission>500)
    {
        uint32_t offset;
        int nCount = Mav4GBuff::missionRemaim(offset);
        if (nCount > 10)
            nCount = 10;

        if(nCount > 0)
        {
            sendRequestMissionItem(offset, nCount, Mav4GBuff::missionType());
            s_linkInfo.tmLastReqMission = ms;
        }
        else if (s_linkInfo.bhasReturn)
        {
            s_linkInfo.tmLastReqMission = ms;
            s_missionReturn.seqno = ++s_linkInfo.seqNumb;
            uint32_t name_len = strlen(PROTO_POSTRETURN) + sizeof(char);
            uint8_t *ptr = s_linkInfo.bufSnd + 2 * sizeof(uint32_t) + name_len;
            size_t msg_len = das__proto__post_operation_return__pack(&s_missionReturn, ptr);

            sendProtoBuff(name_len, msg_len, PROTO_POSTRETURN);
            s_linkInfo.tmLastReqMission = ms;
        }
    }
}

static void LinkCheck(void)
{
    if (!s_linkInfo.sock || !s_linkInfo.bHasHost || s_linkInfo.port==0)
        return;

    s_linkInfo.stat4g = s_linkInfo.sock->Poll(0);
    if (!s_linkInfo.sock->IsCreated())
    {
        s_linkInfo.sock->Create4GSock();
        return;
    }
    unsigned tmTmp = hrt_absolute_time()/1e3;
    do {
        if (s_linkInfo.sock->RecvLength()>0)
            s_linkInfo.szRcv +=
            s_linkInfo.sock->RecvBuff(s_linkInfo.bufRcv+s_linkInfo.szRcv, sizeof(s_linkInfo.bufRcv)-s_linkInfo.szRcv);

        unsigned nTmp = processRcvBuff(tmTmp);
        if (nTmp>0 && s_linkInfo.szRcv>nTmp)
            memcpy(s_linkInfo.bufRcv, s_linkInfo.bufRcv+nTmp, s_linkInfo.szRcv-nTmp);

        s_linkInfo.szRcv -= nTmp;
        if (0==nTmp)
            break;

    } while (s_linkInfo.szRcv>18);


    if (s_linkInfo.stat4g == Socket4G::None || s_linkInfo.stat4g == Socket4G::Bussy)
        return;

    if (s_linkInfo.bHasGlobal || tmTmp-s_linkInfo.tmLastGlobal>2000)
        s_linkInfo.bHasGlobal = false;

    if (tmTmp - s_linkInfo.tmLastGps > 5000)
        s_protoGps.latitude = 0x7fffffff;

    if ( (s_linkInfo.stat4g == Socket4G::Created && s_linkInfo.tmLastLink-tmTmp>5000)
      || (s_linkInfo.stat4g == Socket4G::Disconnected && tmTmp-s_linkInfo.tmLastLink>2000) )
    {
        s_linkInfo.tmLastLink = tmTmp;
        s_linkInfo.sock->Connect(s_linkInfo.host, s_linkInfo.port);
        s_linkInfo.bLinkCloud = false;
        return;
    }

    if ( s_linkInfo.stat4g!=Socket4G::Sended
      && s_linkInfo.stat4g!=Socket4G::Connected
      && s_linkInfo.stat4g!=Socket4G::SendFail )
        return;

    if (s_linkInfo.stat4g==Socket4G::Connected)
        s_linkInfo.tmLastLink = tmTmp-1e4;

    CheckSend(tmTmp);
}

static void prcsHeatbeat(const mavlink_message_t &msg)
{
    mavlink_heartbeat_t heartbeat;
    mavlink_msg_heartbeat_decode(&msg, &heartbeat);
    if (heartbeat.system_status & 0x20)
        Mav4GBuff::notifyNewMission();
    if ((heartbeat.system_status & 0x80) && !s_linkInfo.bSndBlocks)
        Mav4GBuff::saveMavLink(MAVLINK_MSG_ID_GET_OBSTACLE_INFO, &heartbeat.type, 1);

    s_gpsVel.sysStat = heartbeat.system_status;
    s_gpsVel.sysType = heartbeat.type;
    s_gpsVel.baseMode = heartbeat.base_mode;
    if (s_linkInfo.bDeniFly)
        return;

    if (s_linkInfo.customMode != heartbeat.custom_mode)
    {
        auto t = fromCustMode(heartbeat.custom_mode);
        if (Mode_Return == t)
        {
            auto tOld = fromCustMode(s_linkInfo.customMode); 
            if (Mode_Mission == tOld || Mode_ABPoint == tOld)
                s_linkInfo.bhasReturn = true;
        }
        else if (Mode_Mission == t)
        {
            s_missionReturn.mission = true;
        }
        else if (Mode_ABPoint == t)
        {
            s_missionReturn.mission = false;
        }
        strcpy(s_linkInfo.modeDesc, sModeDescs[t]);
        s_linkInfo.customMode = heartbeat.custom_mode;
    }
}

static void prcsSysStatus(const mavlink_message_t &msg)
{
    mavlink_sys_status_t sysStatus;
    mavlink_msg_sys_status_decode(&msg, &sysStatus);

    s_protoStatus.surplusenergy = sysStatus.battery_remaining;
    s_protoStatus.voltage = sysStatus.voltage_battery;
    s_gpsVel.voltageErr = sysStatus.errors_count1 > 3 ? 0 : sysStatus.errors_count1;
}

static void prcsPosition(const mavlink_message_t &msg)
{
    mavlink_global_position_int_t pos;
    mavlink_msg_global_position_int_decode(&msg, &pos);

    s_protoGps.latitude = pos.lat;
    s_protoGps.longitude = pos.lon;
    s_protoGps.altitude = pos.alt;

    if (MAV_STATE_ACTIVE == (s_gpsVel.sysStat & MAV_STATE_ACTIVE))
        s_protoAttitude.relative_alt = pos.relative_alt;

    double speedX = pos.vx / 100.0;
    double speedY = pos.vy / 100.0;
    s_protoAttitude.groundspeed = (float)sqrt(speedX*speedX + speedY*speedY);
    s_gpsVel.gpsVSpeed = pos.vz;    //clamb speed;
    s_linkInfo.bHasGlobal = true;
    s_linkInfo.tmLastGlobal = hrt_absolute_time() / 1e3;
}

static void prcsGps(const mavlink_message_t &msg)
{
    mavlink_gps_raw_int_t gpsRawInt;
    mavlink_msg_gps_raw_int_decode(&msg, &gpsRawInt);
    s_gpsVel.fixType = gpsRawInt.fix_type;
    s_gpsVel.satellites = gpsRawInt.satellites_visible;
    if(!s_linkInfo.bHasGlobal)
    {
        s_protoGps.latitude = gpsRawInt.lat;
        s_protoGps.longitude = gpsRawInt.lon;
        s_protoGps.altitude = gpsRawInt.alt;
    }

    s_gpsVel.magneErr = gpsRawInt.cog&7;
    s_gpsVel.gpsJam = (gpsRawInt.cog & 8) ? 1 : 0;
    s_gpsVel.precision = gpsRawInt.h_acc > 2e5 ? 2e4 : gpsRawInt.h_acc / 10;
    s_linkInfo.tmLastGps = hrt_absolute_time() / 1e3;
}

static void prcsAttitude(const mavlink_message_t &msg)
{
    mavlink_attitude_t attitude;
    mavlink_msg_attitude_decode(&msg, &attitude);
    s_protoAttitude.pitch = attitude.pitch;
    s_protoAttitude.roll = attitude.roll;
    s_protoAttitude.yaw = attitude.yaw;
}

static void prcsAltitude(const mavlink_message_t &msg)
{
    mavlink_altitude_t altitude;
    mavlink_msg_altitude_decode(&msg, &altitude);
    s_gpsVel.gndHeight = (altitude.bottom_clearance > 600 ? 600 : altitude.bottom_clearance) * 100;

    if (MAV_STATE_ACTIVE != (s_gpsVel.sysStat & MAV_STATE_ACTIVE))
        s_protoAttitude.relative_alt = altitude.altitude_local*1000.0f;
}

static void prcsMissiondAck(const mavlink_message_t &msg)
{
    mavlink_mission_ack_t missionAck;
    mavlink_msg_mission_ack_decode(&msg, &missionAck);
    if (Mav4GBuff::notifyMissionRcved(missionAck.type))
    {
        s_gpsVel.missionRes = missionAck.type;
        s_linkInfo.msResRepeat = MissonResultRepeat;
    }
}

static void prcsMissionCur(const mavlink_message_t &msg)
{
    mavlink_mission_current_t cur;
    mavlink_msg_mission_current_decode(&msg, &cur);

    s_gpsVel.curMs = cur.seq;
    if (!s_linkInfo.bhasReturn)
        s_missionReturn.msitem = cur.seq;
}

static bool prcsParamValue(const mavlink_message_t &msg)
{
    mavlink_param_value_t param;
    mavlink_msg_param_value_decode(&msg, &param);
    bool ret = false;
    if (0==strncmp(param.param_id, NAMEPARAMUAVID, 16))
    {
        uint32_t uavId = *(uint32_t*)&param.param_value;
        ret = uavId > 0;
        if (ret && !s_linkInfo.bHasUavId)
        {
            sprintf(s_linkInfo.idUav, "VIGAU:%08X", uavId);
            s_linkInfo.bHasUavId = true;
        }
    }
    else if (0 == strncmp(param.param_id, CLOUDHOSTID, 16))
    {
        uint8_t *ip = (uint8_t *)&param.param_value;
        sprintf(s_linkInfo.host, "%d.%d.%d.%d", ip[3], ip[2], ip[1], ip[0]);
        s_linkInfo.bHasHost = true;
    }
    else if (0 == strncmp(param.param_id, CLOUDPORTID, 16))
    {
        s_linkInfo.port = *(uint32_t *)&param.param_value;
    }
    Mav4GBuff::prcsNormalMav(msg);
    return ret;
}

static void prcsSpray(const mavlink_message_t &msg)
{
    mavlink_spray_value_t spray;
    mavlink_msg_spray_value_decode(&msg, &spray);
    s_protoStatus.jetvelocity = spray.spray_speed;
    s_protoStatus.sprayeddose = spray.volume_sprayed;
    s_gpsVel.sprayState = spray.spray_state;
}

void prcsBlocks(const mavlink_message_t &msg)
{
    mavlink_obstacle_info_t blocks;
    mavlink_msg_obstacle_info_decode(&msg, &blocks);
    s_pbBlocks.n_blocks = blocks.obs_count * 3;
    for (size_t i = 0; i < s_pbBlocks.n_blocks && i<3; i++)
    {
        s_blocks[i].lat = blocks.obs_lat[i];
        s_blocks[i].lon = blocks.obs_lon[i];
        s_blocks[i].angle = blocks.obs_azi[i];
        s_blocks[i].distance = blocks.obs_distance[i];
    }
    s_linkInfo.bSndBlocks = true;
}

static void prcsInterrupt(const mavlink_message_t &msg)
{
    mavlink_interrupt_point_t itrp;
    mavlink_msg_interrupt_point_decode(&msg, &itrp);
    if (!s_linkInfo.bhasReturn)
    {
        s_missionReturn.mission = itrp.int_type == 1;
        s_missionReturn.suspend = &s_coorSuspend;
        s_coorSuspend.altitude = itrp.int_altitude;
        s_coorSuspend.latitude = itrp.int_latitude;
        s_coorSuspend.longitude = itrp.int_longitude;
    }
    Mav4GBuff::saveMavLink(MAVLINK_MSG_ID_INTERRUPT_POINT_ACK, &itrp.int_type, 1);
}

static ModeType fromCustMode(uint32_t custom_mode)
{
    px4_custom_mode &mode = *(px4_custom_mode*)&custom_mode;
    if (PX4_CUSTOM_MAIN_MODE_AUTO == mode.main_mode && PX4_CUSTOM_SUB_MODE_AUTO_MISSION == mode.sub_mode)
        return Mode_Mission;
    else if (PX4_CUSTOM_MAIN_MODE_AUTO == mode.main_mode && PX4_CUSTOM_SUB_MODE_AUTO_LOITER == mode.sub_mode)
        return Mode_Hold;
    else if ((PX4_CUSTOM_MAIN_MODE_MANUAL == mode.main_mode || PX4_CUSTOM_MAIN_MODE_ALTCTL == mode.main_mode || PX4_CUSTOM_MAIN_MODE_POSCTL == mode.main_mode)
        && 0 == mode.sub_mode)
        return Mode_Manual;
    else if (PX4_CUSTOM_MAIN_MODE_AUTO == mode.main_mode && PX4_CUSTOM_SUB_MODE_AUTO_RTL == mode.sub_mode)
        return Mode_Return;
    else if (PX4_CUSTOM_MAIN_MODE_AUTO == mode.main_mode && PX4_CUSTOM_SUB_MODE_AUTO_MAG_MISSION == mode.sub_mode)
        return Mode_MagMsm;
    else if (PX4_CUSTOM_MAIN_MODE_AUTO == mode.main_mode && PX4_CUSTOM_SUB_MODE_AUTO_LAND == mode.sub_mode)
        return Mode_Landing;
    else if (PX4_CUSTOM_MAIN_MODE_AUTO == mode.main_mode && PX4_CUSTOM_SUB_MODE_AUTO_AB_POINT == mode.sub_mode)
        return Mode_ABPoint;
    else
        return Mode_Unknow;
}
/*****************************************************************
***CloudLink
******************************************************************/
void CloudLink::InitialCloudLink(void)
{
    if (s_linkInfo.bInit)
        return;

    s_pProtoOp = new Das__Proto__OperationInformation;
    if (!s_pProtoOp)
        return;

    s_linkInfo.sock = new Socket4G(1);
    s_linkInfo.tmLastReqMission = hrt_absolute_time()/1e3 - 500;
    s_linkInfo.tmLastLink = s_linkInfo.tmLastReqMission - 1e4;
    s_linkInfo.bLinkCloud = false;
    s_linkInfo.bhasReturn = false;
    s_linkInfo.szRcv = 0;
    s_linkInfo.bHasGlobal = false;
    s_linkInfo.bArm = false;
    Mav4GBuff::initialBuf(s_linkInfo.tmLastReqMission);

    memset(&s_gpsVel, 0, sizeof(s_gpsVel));
    s_linkInfo.seqNumb = 0;

    if (!s_linkInfo.bHasUavId)
        Mav4GBuff::loadParameter(NAMEPARAMUAVID);
    if (s_linkInfo.bHasHost ==0)
        Mav4GBuff::loadParameter(CLOUDHOSTID);
    if (s_linkInfo.port == 0)
        Mav4GBuff::loadParameter(CLOUDPORTID);

    das__proto__request_uav_identity_authentication__init(&s_uavCloudLogin);
    das__proto__gps_information__init(&s_protoGps);
    s_protoGps.n_velocity = (sizeof(s_gpsVel)+sizeof(float)-1)/sizeof(float);
    s_protoGps.velocity = s_gpsVel.tmp;
    s_protoGps.latitude = 0x7fffffff;

    das__proto__operation_status__init(&s_protoStatus);
    s_protoStatus.operationmode = s_linkInfo.modeDesc;

    das__proto__uav_attitude__init(&s_protoAttitude);
    das__proto__operation_information__init(s_pProtoOp);
    s_pProtoOp->gps = &(s_protoGps);
    s_pProtoOp->status = &(s_protoStatus);
    s_pProtoOp->attitude = &(s_protoAttitude);
    s_pProtoOp->uavid = s_linkInfo.idUav;

    das__proto__post_operation_information__init(&s_postInfo);
    s_postInfo.n_oi = 1;
    s_postInfo.oi = &(s_pProtoOp);

    das__proto__post_status2_ground_station__init(&s_status2Gs);
    s_status2Gs.uavid = s_linkInfo.idUav;
    s_status2Gs.data = s_dataSnd;
    s_status2Gs.n_data = 0;
    das__proto__request_position_authentication__init(&s_reqPosAuth);
    s_reqPosAuth.devid = s_linkInfo.idUav;
    s_reqPosAuth.pos = &s_protoGps;

    das__proto__request_route_missions__init(&s_missionRequest);

    s_gpsVel.missionRes = MAV_MISSION_RESULT_ENUM_END;
    s_linkInfo.bInit = true;

    das__proto__coordinate__init(&s_coorSuspend);
    das__proto__post_operation_return__init(&s_missionReturn);
    s_missionReturn.msid = s_linkInfo.idMission;
    s_missionReturn.mission = true;

    das__proto__post_blocks__init(&s_pbBlocks);
    memset(s_blocks, 0, sizeof(s_blocks));
    s_pbBlocks.n_blocks = 0;
    s_pbBlocks.uavid = s_linkInfo.idUav;
    s_pbBlocks.blocks = (int32_t*)&s_blocks;
}

bool CloudLink::IsCanSend()
{
    return s_linkInfo.bLinkCloud
        && s_linkInfo.stat4g!=Socket4G::None
        && s_linkInfo.stat4g!=Socket4G::Bussy;
}

bool CloudLink::SendMavLink(const mavlink_message_t &msg)
{
    switch(msg.msgid)
    {
    case MAVLINK_MSG_ID_HEARTBEAT:
        prcsHeatbeat(msg); break;
    case MAVLINK_MSG_ID_SYS_STATUS:
        prcsSysStatus(msg); break;
    case MAVLINK_MSG_ID_GLOBAL_POSITION_INT:
        prcsPosition(msg);  break;
    case MAVLINK_MSG_ID_GPS_RAW_INT:
        prcsGps(msg); break;
    case MAVLINK_MSG_ID_ATTITUDE:
        prcsAttitude(msg); break;
    case MAVLINK_MSG_ID_MISSION_COUNT:
    case MAVLINK_MSG_ID_MISSION_ITEM_INT:
        s_gpsVel.stDown = 1;
        if (s_linkInfo.bLinkCloud)
            Mav4GBuff::prcsMissionSend(msg);
        break;
    case MAVLINK_MSG_ID_ALTITUDE:
        prcsAltitude(msg); break;
    case MAVLINK_MSG_ID_MISSION_REQUEST_INT:
    case MAVLINK_MSG_ID_MISSION_REQUEST:
        Mav4GBuff::prcsMissionReq(msg); break;
    case MAVLINK_MSG_ID_MISSION_ACK:
        prcsMissiondAck(msg); break;
    case MAVLINK_MSG_ID_PARAM_VALUE:
        prcsParamValue(msg); break;
    case MAVLINK_MSG_ID_SPRAY_VALUE:
        prcsSpray(msg); break;
    case MAVLINK_MSG_ID_MISSION_CURRENT:
        prcsMissionCur(msg); break;
    case MAVLINK_MSG_ID_COMMAND_ACK:
    case MAVLINK_MSG_ID_ASSIST_POSITION:
    case MAVLINK_MSG_ID_HOME_POSITION:
    case MAVLINK_MSG_ID_VIGA_EVENT:
    case MAVLINK_MSG_ID_QX_ACCOUNT:
    case MAVLINK_MSG_ID_QX_ACC_CMD:
    case MAVLINK_MSG_ID_QXSDK_ACCOUNT:
    case MAVLINK_MSG_ID_QXSDK_ACC_CMD:
        Mav4GBuff::prcsNormalMav(msg); break;
    case MAVLINK_MSG_ID_RC_CHANNELS:
        Mav4GBuff::prcsRCChannels(msg); break;
    case MAVLINK_MSG_ID_INTERRUPT_POINT:
        prcsInterrupt(msg); break;
    case MAVLINK_MSG_ID_OBSTACLE_INFO:
        prcsBlocks(msg); break;
    }

    return s_linkInfo.bLinkCloud;
}

bool CloudLink::RecvMavLink(mavlink_message_t &mav)
{
    LinkCheck();
    if (Mav4GBuff::loadMissionItem(mav))
        return true;

    return Mav4GBuff::loadMavMessage(mav);
}

void CloudLink::UninitialCloudLink(void)
{
    //hrt_cancel(&s_linkInfo.hrtCall4G);
    s_linkInfo.bLinkCloud = false;
    usleep(1e4);
    delete s_linkInfo.sock;
    s_linkInfo.sock = NULL;
    delete s_pProtoOp;
    s_linkInfo.bInit = false;
}
