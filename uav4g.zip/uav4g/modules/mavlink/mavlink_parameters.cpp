/****************************************************************************
 *
 *   Copyright (c) 2015-2017 PX4 Development Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name PX4 nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

/**
 * @file mavlink_parameters.cpp
 * Mavlink parameters manager implementation.
 *
 * @author Anton Babushkin <anton.babushkin@me.com>
 * @author Lorenz Meier <lorenz@px4.io>
 */

#include <stdio.h>

#include <uORB/topics/uavcan_parameter_request.h>
#include <uORB/topics/uavcan_parameter_value.h>
#include <uORB/topics/mav_param_tofmu.h>
#include <uORB/topics/mav_param_fromfmu.h>

#include <uORB/topics/mav_param_toimu.h>
#include <uORB/topics/mav_param_fromimu.h>

#include "mavlink_parameters.h"
#include "mavlink_main.h"
#include "cloudlink.h"

#define HASH_PARAM "_HASH_CHECK"

MavlinkParametersManager::MavlinkParametersManager(Mavlink *mavlink) :
    _send_all_index(-1),
    _uavcan_open_request_list(nullptr),
    _uavcan_waiting_for_request_response(false),
    _uavcan_queued_request_items(0),
    _rc_param_map_pub(nullptr),
    _rc_param_map(),
    _uavcan_parameter_request_pub(nullptr),
    _uavcan_parameter_value_sub(-1),
    _mavlink(mavlink)
{
    _orb_sub_mav_param_fromfmu = orb_subscribe( ORB_ID(mav_param_fromfmu) );
    _orb_sub_mav_param_fromimu = orb_subscribe( ORB_ID(mav_param_fromimu) );
}
MavlinkParametersManager::~MavlinkParametersManager()
{
    if (_uavcan_parameter_value_sub >= 0) {
        orb_unsubscribe(_uavcan_parameter_value_sub);
    }

    if (_uavcan_parameter_request_pub) {
        orb_unadvertise(_uavcan_parameter_request_pub);
    }

    if( _orb_sub_mav_param_fromfmu >= 0 ){
        orb_unsubscribe( _orb_sub_mav_param_fromfmu );
    }

    if( _orb_sub_mav_param_fromimu >= 0 ){
        orb_unsubscribe( _orb_sub_mav_param_fromimu );
    }

}

unsigned
MavlinkParametersManager::get_size()
{
    return MAVLINK_MSG_ID_PARAM_VALUE_LEN + MAVLINK_NUM_NON_PAYLOAD_BYTES;
}

uint8_t
MavlinkParametersManager::mav_param_operation( uint8_t op_type, char *name, float value, mavlink_param_value_t *ret_param )
{

    mav_param_tofmu_s tofmu;
    mav_param_fromfmu_s fromfmu;
    mav_param_get_request_s get_request;
    mav_param_set_request_s set_request;

    tofmu.msg_type = op_type;

    switch( op_type )
    {
        case mav_param_tofmu_s::PARAM_GET_REQUEST:
            memcpy( &get_request.param_name[0], name, MAVLINK_MSG_PARAM_VALUE_FIELD_PARAM_ID_LEN  );
            memcpy( &tofmu.msg_buff[0], &get_request, sizeof(mav_param_get_request_s) );

            break;
        case mav_param_tofmu_s::PARAM_SET_REQUEST:
            memcpy( &set_request.set_value.param_id[0], name, MAVLINK_MSG_PARAM_VALUE_FIELD_PARAM_ID_LEN );
            set_request.set_value.param_value = value;
            memcpy( &tofmu.msg_buff[0], &set_request, sizeof(mav_param_set_request_s) );
            break;
        default:
            break;
    }

    //clear orb update state
    orb_copy( ORB_ID(mav_param_fromfmu), _orb_sub_mav_param_fromfmu, &fromfmu );

    if( _orb_pub_mav_param_tofmu == nullptr )
        _orb_pub_mav_param_tofmu = orb_advertise( ORB_ID(mav_param_tofmu), &tofmu );
    else
        orb_publish(ORB_ID(mav_param_tofmu), _orb_pub_mav_param_tofmu, &tofmu );


    px4_pollfd_struct_t fds[1];
        fds[0].fd = _orb_sub_mav_param_fromfmu;
        fds[0].events = POLLIN;
    int poll_ret = -1;
    bool orb_updated = false;
    mav_param_result_s *ptr_param_result;

    poll_ret = px4_poll( fds, 1, 3000 );
    if( poll_ret > 0 )
    {
        orb_check( _orb_sub_mav_param_fromfmu, &orb_updated );
        if( orb_updated )
        {
            orb_copy( ORB_ID(mav_param_fromfmu), _orb_sub_mav_param_fromfmu, &fromfmu );
            ptr_param_result = (mav_param_result_s *)fromfmu.msg_buff;
            memcpy( ret_param, &ptr_param_result->param_value, sizeof(mavlink_param_value_t) );
printf("[mavlink]param_operation: param_value:0x%08x, param_count:%d param_index:%d,param_id:%s param_type:%d result=%d\n", *(int32_t*)&ret_param->param_value,ret_param->param_count, ret_param->param_index, ret_param->param_id, ret_param->param_type, ptr_param_result->result);
            return ptr_param_result->result;
        }
    }
    printf("[mavlink]param_operation: FAILED!\n");
    return -1;
}



uint8_t
MavlinkParametersManager::mav_imuparam_operation( uint8_t op_type, char *name, float value, mavlink_param_value_t *ret_param )
{

    mav_param_toimu_s toimu;
    mav_param_fromimu_s fromimu;
    mav_param_get_request_s get_request;
    mav_param_set_request_s set_request;

    toimu.msg_type = op_type;

    switch( op_type )
    {
        case mav_param_toimu_s::PARAM_GET_REQUEST:
            memcpy( &get_request.param_name[0], name, MAVLINK_MSG_PARAM_VALUE_FIELD_PARAM_ID_LEN  );
            memcpy( &toimu.msg_buff[0], &get_request, sizeof(mav_param_get_request_s) );

            break;
        case mav_param_toimu_s::PARAM_SET_REQUEST:
            memcpy( &set_request.set_value.param_id[0], name, MAVLINK_MSG_PARAM_VALUE_FIELD_PARAM_ID_LEN );
            set_request.set_value.param_value = value;
            memcpy( &toimu.msg_buff[0], &set_request, sizeof(mav_param_set_request_s) );
            break;
        default:
            break;
    }

    //clear orb update state
    orb_copy( ORB_ID(mav_param_fromimu), _orb_sub_mav_param_fromimu, &fromimu );

    if( _orb_pub_mav_param_toimu == nullptr )
        _orb_pub_mav_param_toimu = orb_advertise( ORB_ID(mav_param_toimu), &toimu );
    else
        orb_publish(ORB_ID(mav_param_toimu), _orb_pub_mav_param_toimu, &toimu );


    px4_pollfd_struct_t fds[1];
        fds[0].fd = _orb_sub_mav_param_fromimu;
        fds[0].events = POLLIN;
    int poll_ret = -1;
    bool orb_updated = false;
    mav_param_result_s *ptr_param_result;

    poll_ret = px4_poll( fds, 1, 3000 );
    if( poll_ret > 0 )
    {
        orb_check( _orb_sub_mav_param_fromimu, &orb_updated );
        if( orb_updated )
        {
            orb_copy( ORB_ID(mav_param_fromimu), _orb_sub_mav_param_fromimu, &fromimu );
            ptr_param_result = (mav_param_result_s *)fromimu.msg_buff;
            memcpy( ret_param, &ptr_param_result->param_value, sizeof(mavlink_param_value_t) );
printf("[mavlink]imuparam_operation: param_value:0x%08x, param_count:%d param_index:%d,param_id:%s param_type:%d result=%d\n", *(int32_t*)&ret_param->param_value,ret_param->param_count, ret_param->param_index, ret_param->param_id, ret_param->param_type, ptr_param_result->result);
            return ptr_param_result->result;
        }
    }

    printf("[mavlink]imuparam_operation: FAILED!\n");
    return -1;
}




void
MavlinkParametersManager::handle_message(const mavlink_message_t *msg)
{
    switch (msg->msgid) {
    case MAVLINK_MSG_ID_PARAM_SET: {
            /* set parameter */
            mavlink_param_set_t set;
            mavlink_param_value_t ret_param;
            mavlink_msg_param_set_decode(msg, &set);

            if (set.target_system == mavlink_system.sysid &&
                (set.target_component == mavlink_system.compid || set.target_component == MAV_COMP_ID_ALL)) {

                /* local name buffer to enforce null-terminated string */
                char name[MAVLINK_MSG_PARAM_VALUE_FIELD_PARAM_ID_LEN + 1];
                strncpy(name, set.param_id, MAVLINK_MSG_PARAM_VALUE_FIELD_PARAM_ID_LEN);
                /* enforce null termination */
                name[MAVLINK_MSG_PARAM_VALUE_FIELD_PARAM_ID_LEN] = '\0';


printf("[mavlink],param_set:%s\n", name);
                /* Whatever the value is, we're being told to stop sending */
                if (strncmp(name, "_HASH_CHECK", sizeof(name)) == 0) {
                    _send_all_index = -1;
                    /* No other action taken, return */
                    return;
                }


                if( strncmp( name, "SYS_UAV_ID", 10 ) == 0
                 || strncmp( name, "HOST_IP", 7 ) == 0
                 || strncmp( name, "HOST_PORT", 9 ) == 0){
                    param_t param = param_find_no_notification( name );
                    if (param == PARAM_INVALID) {
                        char buf[MAVLINK_MSG_STATUSTEXT_FIELD_TEXT_LEN];
                        sprintf(buf, "[pm] unknown param: %s", name);
                        _mavlink->send_statustext_info(buf);

                    } else {
                        // Load current value before setting it
                        float curr_val;
                        param_get(param, &curr_val);
                        param_set(param, &(set.param_value));

                        // Check if the parameter changed. If it didn't change, send current value back
                        if (!(fabsf(curr_val - set.param_value) > 0.0f)) {
                            send_param(param);
                        }
                    }
                } else{ 
                    if( strncmp( name, "VGR_P900_DADDR", 14 ) == 0
                     ||strncmp( name, "VGR_P900_UADDR", 14 ) == 0
                     ||strncmp( name, "VGR_P900_STAT", 13 ) == 0
                     ||strncmp( name, "SWITCH_RTCM", 11 ) == 0) 
                    {
                        if( mav_imuparam_operation( mav_param_toimu_s::PARAM_SET_REQUEST, name, set.param_value, &ret_param ) == 0)
                        {
                            send_param( ret_param );
                        }
                        else
                        {
                                char buf[MAVLINK_MSG_STATUSTEXT_FIELD_TEXT_LEN];
                                sprintf(buf, "set param failed: %s", name);
                                _mavlink->send_statustext_info(buf);
                        }
                        
                    }
                    else
                    {
                        if( mav_param_operation( mav_param_tofmu_s::PARAM_SET_REQUEST, name, set.param_value, &ret_param ) == 0 )
                        {
                            send_param( ret_param );
                        }
                        else
                        {
                                char buf[MAVLINK_MSG_STATUSTEXT_FIELD_TEXT_LEN];
                                sprintf(buf, "set param failed: %s", name);
                                _mavlink->send_statustext_info(buf);
                        }
                    }

                }

            }

            break;
        }

    case MAVLINK_MSG_ID_PARAM_REQUEST_READ: {
            /* request one parameter */
            mavlink_param_request_read_t req_read;
            mavlink_param_value_t ret_param;
            mavlink_msg_param_request_read_decode(msg, &req_read);

//printf("[mavlink],param_get:%s\n",req_read.param_id );
            if (req_read.target_system == mavlink_system.sysid &&
                (req_read.target_component == mavlink_system.compid || req_read.target_component == MAV_COMP_ID_ALL)) {
printf("MAVLINK_MSG_ID_PARAM_REQUEST_READ,param_id:%s  \n", req_read.param_id );
                if( strncmp( req_read.param_id, "SYS_UAV_ID", 10 ) == 0
                 || strncmp( req_read.param_id, "HOST_IP", 7 ) == 0
                 || strncmp( req_read.param_id, "HOST_PORT", 9 ) == 0 ){
                    param_t param = param_find_no_notification( req_read.param_id );
                //int uav_id = 1;
                    ret_param.param_count = param_count_used();
                    ret_param.param_index = param_get_used_index( param );

                    /* query parameter type */
                    param_type_t type = param_type(param);
                    /*
                     * Map onboard parameter type to MAVLink type,
                     * endianess matches (both little endian)
                     */
                    if (type == PARAM_TYPE_INT32) {
                        ret_param.param_type = MAVLINK_TYPE_INT32_T;
                    } else if (type == PARAM_TYPE_FLOAT) {
                        ret_param.param_type = MAVLINK_TYPE_FLOAT;
                    } else {
                        ret_param.param_type = MAVLINK_TYPE_FLOAT;
                    }

                    if( OK == param_get( param, &ret_param.param_value ) )
                    {
                        //memcpy(&uav_id, &ret_param.param_value, sizeof(uav_id));
                        //printf("param in light, UAV_ID=%d, param=%d, count=%d\n", uav_id, param, ret_param.param_count);
                        memcpy( &ret_param.param_id[0], &req_read.param_id[0], MAVLINK_MSG_PARAM_VALUE_FIELD_PARAM_ID_LEN );
                        send_param( ret_param );
                    }

                } else{ 
                    if( strncmp( req_read.param_id, "VGR_P900_DADDR", 14 ) == 0
                     ||strncmp( req_read.param_id, "VGR_P900_UADDR", 14 ) == 0
                     ||strncmp( req_read.param_id, "SWITCH_RTCM", 11 ) == 0
                     ||strncmp( req_read.param_id, "VGR_P900_STAT", 13 ) == 0)      
                    {
                        if( mav_imuparam_operation( mav_param_toimu_s::PARAM_GET_REQUEST, req_read.param_id, 0.0f, &ret_param ) == 0 )
                        {
                            send_param( ret_param );
                        }
                        else
                        {
                                char buf[MAVLINK_MSG_STATUSTEXT_FIELD_TEXT_LEN];
                                sprintf(buf, "read param failed: %s", req_read.param_id);
                                _mavlink->send_statustext_info(buf);
                        }
                    }
                    else
                    {

                        if( mav_param_operation( mav_param_tofmu_s::PARAM_GET_REQUEST, req_read.param_id, 0.0f, &ret_param ) == 0 )
                        {
                            send_param( ret_param );
                        }
                        else
                        {
                            char buf[MAVLINK_MSG_STATUSTEXT_FIELD_TEXT_LEN];
                            sprintf(buf, "read param failed: %s", req_read.param_id);
                            _mavlink->send_statustext_info(buf);
                        }
                    }
                }
            }

            break;
        }


    default:
        break;
    }
}

void
MavlinkParametersManager::send(const hrt_abstime t)
{
    int max_num_to_send;

    if (_mavlink->get_protocol() == SERIAL && !_mavlink->is_usb_uart()) {
        max_num_to_send = 3;

    } else {
        // speed up parameter loading via UDP, TCP or USB: try to send 15 at once
        max_num_to_send = 5 * 3;
    }

    int i = 0;

    while (i++ < max_num_to_send && send_one());
}


bool
MavlinkParametersManager::send_one()
{
    bool space_available = _mavlink->get_free_tx_buf() >= get_size();

    /* Send parameter values received from the UAVCAN topic */
    if (_uavcan_parameter_value_sub < 0) {
        _uavcan_parameter_value_sub = orb_subscribe(ORB_ID(uavcan_parameter_value));
    }

    bool param_value_ready;
    orb_check(_uavcan_parameter_value_sub, &param_value_ready);

    if (space_available && param_value_ready) {
        struct uavcan_parameter_value_s value;
        orb_copy(ORB_ID(uavcan_parameter_value), _uavcan_parameter_value_sub, &value);

        // Check if we received a matching parameter, drop it from the list and request the next
        if (value.param_index == _uavcan_open_request_list->req.param_index
            && value.node_id == _uavcan_open_request_list->req.node_id) {
            dequeue_uavcan_request();
            request_next_uavcan_parameter();
        }

        mavlink_param_value_t msg;
        msg.param_count = value.param_count;
        msg.param_index = value.param_index;
        /*
         * coverity[buffer_size_warning : FALSE]
         *
         * The MAVLink spec does not require the string to be NUL-terminated if it
         * has length 16. In this case the receiving end needs to terminate it
         * when copying it.
         */
        strncpy(msg.param_id, value.param_id, MAVLINK_MSG_PARAM_VALUE_FIELD_PARAM_ID_LEN);

        if (value.param_type == MAV_PARAM_TYPE_REAL32) {
            msg.param_type = MAVLINK_TYPE_FLOAT;
            msg.param_value = value.real_value;

        } else {
            int32_t val;
            val = (int32_t)value.int_value;
            memcpy(&msg.param_value, &val, sizeof(int32_t));
            msg.param_type = MAVLINK_TYPE_INT32_T;
        }

        send_param(msg, value.node_id);

    } else if (_send_all_index >= 0 && _mavlink->boot_complete()) {
        /* send all parameters if requested, but only after the system has booted */

        /* skip if no space is available */
        if (!space_available) {
            return false;
        }

        /* The first thing we send is a hash of all values for the ground
         * station to try and quickly load a cached copy of our params
         */
        if (_send_all_index == PARAM_HASH) {
            /* return hash check for cached params */
            uint32_t hash = param_hash_check();

            /* build the one-off response message */
            mavlink_param_value_t msg;
            msg.param_count = param_count_used();
            msg.param_index = -1;
            strncpy(msg.param_id, HASH_PARAM, MAVLINK_MSG_PARAM_VALUE_FIELD_PARAM_ID_LEN);
            msg.param_type = MAV_PARAM_TYPE_UINT32;
            memcpy(&msg.param_value, &hash, sizeof(hash));
            send_param(msg);

            /* after this we should start sending all params */
            _send_all_index = 0;

            /* No further action, return now */
            return true;
        }

        /* look for the first parameter which is used */
        param_t p;

        do {
            /* walk through all parameters, including unused ones */
            p = param_for_index(_send_all_index);
            _send_all_index++;
        } while (p != PARAM_INVALID && !param_used(p));

        if (p != PARAM_INVALID) {
            send_param(p);
        }

        if ((p == PARAM_INVALID) || (_send_all_index >= (int) param_count())) {
            _send_all_index = -1;
            return false;

        } else {
            return true;
        }

    } else if (_send_all_index == PARAM_HASH && hrt_absolute_time() > 20 * 1000 * 1000) {
        /* the boot did not seem to ever complete, warn user and set boot complete */
        _mavlink->send_statustext_critical("WARNING: SYSTEM BOOT INCOMPLETE. CHECK CONFIG.");
        _mavlink->set_boot_complete();
    }

    return false;
}

int
MavlinkParametersManager::send_param( mavlink_param_value_t &param, int component_id)
{
    mavlink_msg_param_value_encode_chan(mavlink_system.sysid, component_id>=0?component_id:0, _mavlink->get_channel(), &Mavlink::s_msgEn, &param);
    CloudLink::SendMavLink(Mavlink::s_msgEn);
    if (component_id < 0)
        mavlink_msg_param_value_send_struct(_mavlink->get_channel(), &param);
    else
        _mavlink_resend_uart(_mavlink->get_channel(), &Mavlink::s_msgEn);

    return 0;
}

int
MavlinkParametersManager::send_param(param_t param, int component_id)
{
    if (param == PARAM_INVALID) {
        return 1;
    }
    /*
     * get param value, since MAVLink encodes float and int params in the same
     * space during transmission, copy param onto float val_buf
     */
    mavlink_param_value_t msg;
    if (param_get(param, &msg.param_value) != OK) {
        return 2;
    }

    msg.param_count = param_count_used();
    msg.param_index = param_get_used_index(param);

    /*
     * coverity[buffer_size_warning : FALSE]
     *
     * The MAVLink spec does not require the string to be NUL-terminated if it
     * has length 16. In this case the receiving end needs to terminate it
     * when copying it.
     */
    strncpy(msg.param_id, param_name(param), MAVLINK_MSG_PARAM_VALUE_FIELD_PARAM_ID_LEN);

    /* query parameter type */
    param_type_t type = param_type(param);

    /*
     * Map onboard parameter type to MAVLink type,
     * endianess matches (both little endian)
     */
    if (type == PARAM_TYPE_INT32) {
        msg.param_type = MAVLINK_TYPE_INT32_T;

    } else if (type == PARAM_TYPE_FLOAT) {
        msg.param_type = MAVLINK_TYPE_FLOAT;

    } else {
        msg.param_type = MAVLINK_TYPE_FLOAT;
    }

    return send_param(msg, component_id);
}

void MavlinkParametersManager::request_next_uavcan_parameter()
{
    // Request a parameter if we are not already waiting on a response and if the list is not empty
    if (!_uavcan_waiting_for_request_response && _uavcan_open_request_list != nullptr) {
        uavcan_parameter_request_s req = _uavcan_open_request_list->req;

        if (_uavcan_parameter_request_pub == nullptr) {
            _uavcan_parameter_request_pub = orb_advertise_queue(ORB_ID(uavcan_parameter_request), &req, 5);

        } else {
            orb_publish(ORB_ID(uavcan_parameter_request), _uavcan_parameter_request_pub, &req);
        }

        _uavcan_waiting_for_request_response = true;
    }
}

void MavlinkParametersManager::enque_uavcan_request(uavcan_parameter_request_s *req)
{
    // We store at max 10 requests to keep memory consumption low.
    // Dropped requests will be repeated by the ground station
    if (_uavcan_queued_request_items >= 10) {
        return;
    }

    _uavcan_open_request_list_item *new_reqest = new _uavcan_open_request_list_item;
    new_reqest->req = *req;
    new_reqest->next = nullptr;

    _uavcan_open_request_list_item *item = _uavcan_open_request_list;
    ++_uavcan_queued_request_items;

    if (item == nullptr) {
        // Add the first item to the list
        _uavcan_open_request_list = new_reqest;

    } else {
        // Find the last item and add the new request at the end
        while (item->next != nullptr) {
            item = item->next;
        }

        item->next = new_reqest;
    }
}

void MavlinkParametersManager::dequeue_uavcan_request()
{
    if (_uavcan_open_request_list != nullptr) {
        // Drop the first item in the list and free the used memory
        _uavcan_open_request_list_item *first = _uavcan_open_request_list;
        _uavcan_open_request_list = first->next;
        --_uavcan_queued_request_items;
        delete first;
        _uavcan_waiting_for_request_response = false;
    }
}
