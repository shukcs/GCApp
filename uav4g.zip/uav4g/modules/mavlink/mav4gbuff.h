﻿#ifndef __MAV4G_BUFF_H__
#define __MAV4G_BUFF_H__

#include <v2.0/standard/mavlink.h>

typedef struct ProtobufCBinaryData ProtobufCBinaryData;
namespace Mav4GBuff {
    int hasMavInBuff(uint32_t tmCurMs);
    bool loadMavMessage(mavlink_message_t &msg);
    bool loadMissionItem(mavlink_message_t &msg);
    bool prcsNormalMav(const mavlink_message_t &msg);
    void prcsRCChannels(const mavlink_message_t &msg);
    void prcsMissionReq(const mavlink_message_t &msg);
    void prcsMissionSend(const mavlink_message_t &msg);
    bool prcsUplaodMission(int count, int bdrs);
    bool saveMissionItem(const uint8_t *buff, uint16_t len, uint16_t seq);
    int missionRemaim(uint32_t &offset);
    uint8_t missionType(void);
    bool saveParameter(const char *id, float value, uint8_t type);
    void loadParameter(const char *id);
    bool notifyMissionRcved(uint32_t res);
    bool notifyAckPositionAuthentication(int res);
    void notifyNewMission(void);
    void notifyPackFinish(int packs, bool bRcv);
    int prcsMavLink(const ProtobufCBinaryData &buf, uint32_t tmCurMs);
    void saveMavLink(uint32_t id, const void *payLoad, uint16_t len);
    int packMavLink(ProtobufCBinaryData *buf, int &sz, uint32_t ms);
    size_t packRequestMission(ProtobufCBinaryData *buf, uint16_t seq);
    void initialBuf(uint32_t ms);
}

#endif /* __CLOUD_LINK_H__ */
