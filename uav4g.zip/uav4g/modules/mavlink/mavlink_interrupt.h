/*************************************************************************
	> File Name: /home/qiuyunsong/Firmware_light/src/modules/mavlink/mavlink_interrupt.h
	> Author:
	> Mail:
	> Created Time: 2020年07月15日 星期三 15时36分42秒
 ************************************************************************/

#pragma once

#include <uORB/uORB.h>

#include "mavlink_bridge_header.h"
#include <drivers/drv_hrt.h>

class Mavlink;

class MavlinkInterruptPoint
{
public:
    MavlinkInterruptPoint(Mavlink *mavlink);

    void handle_message(const mavlink_message_t *msg);
    void handle_interrupt_point_ack(const mavlink_message_t *msg);

    void send(const hrt_abstime t);

    Mavlink *_mavlink;

private:
    bool _ack_accept{true};
    int _sub_interrupt_position{-1};
    hrt_abstime _resend_time{0};

    mavlink_interrupt_point_t _int_point_data;
};


