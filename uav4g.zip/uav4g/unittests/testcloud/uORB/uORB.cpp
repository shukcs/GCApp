#include "uORB.h"
#include <map>

using namespace std;

static int s_fdOrb = 1;
static map<string, orb_metadata*> &uOrbs()
{
    static map<string, orb_metadata*> sRegisterOrb;
    return sRegisterOrb;
}

static bool hasOrbOfHandle(const orb_advert_t handle)
{
    map<string, orb_metadata*>::iterator itr = uOrbs().begin();
    for (; itr != uOrbs().end(); ++itr)
    {
        orb_metadata *meta = itr->second;
        for (int i = 0; i < ORB_MULTI_MAX_INSTANCES; ++i)
        {
            if (meta->orbs[i].stat != Orb_Uncreate && meta->orbs + i == handle)
                return true;
        }
    }
    return false;
}

static bool hasMetaData(const orb_metadata *meta)
{
    map<string, orb_metadata*>::iterator itr = uOrbs().begin();
    for (; itr != uOrbs().end(); ++itr)
    {
        if (meta == itr->second)
            return true;
    }
    return false;
}

static OrbStruct *findOrbByFd(int fd)
{
    map<string, orb_metadata*>::iterator itr = uOrbs().begin();
    for (; itr != uOrbs().end(); ++itr)
    {
        orb_metadata *meta = itr->second;
        for (int i = 0; i < ORB_MULTI_MAX_INSTANCES; ++i)
        {
            if (meta->orbs[i].stat != Orb_Uncreate && meta->orbs[i].handle == fd)
                return &meta->orbs[i];
        }
    }
    return NULL;
}

void initialOrb()
{
}

orb_advert_t orb_advertise(const struct orb_metadata *meta, const void *data)
{
    map<string, orb_metadata*>::iterator itr = uOrbs().begin();
    for (; itr!=uOrbs().end(); ++itr)
    {
        if (itr->second == meta && meta->orbs[0].stat==Orb_Uncreate)
        {
            if(itr->second->orbs[0].pBuff = new char[meta->bufLen])
            {
                itr->second->orbs[0].stat = Orb_New;
                memcpy(itr->second->orbs[0].pBuff, data, meta->bufLen);
                if (itr->second->orbs[0].handle == 0)
                    itr->second->orbs[0].handle = s_fdOrb++;

                return itr->second->orbs;
            }
        }
    }
    return NULL;
}

orb_advert_t orb_advertise_multi(const struct orb_metadata *meta, const void *data, int *instance, int)
{
    map<string, orb_metadata*>::iterator itr = uOrbs().begin();
    for (; itr != uOrbs().end(); ++itr)
    {
        if (itr->second == meta)
        {
            for (int i = 0; i < ORB_MULTI_MAX_INSTANCES; ++i)
            {
                if (meta->orbs[i].stat == Orb_Uncreate)
                {
                    if (itr->second->orbs[i].pBuff = new char[meta->bufLen])
                    {
                        itr->second->orbs[i].stat = Orb_New;
                        memcpy(itr->second->orbs[i].pBuff, data, meta->bufLen);
                        if(itr->second->orbs[i].handle==0)
                            itr->second->orbs[i].handle = s_fdOrb++;
                        if (instance)
                            *instance = i;
                        return itr->second->orbs+i;
                    }
                }
            }
        }
    }
    return NULL;
}

int orb_unadvertise(orb_advert_t handle)
{
    if (hasOrbOfHandle(handle))
    {
        OrbStruct *orb = (OrbStruct*)handle;
        orb->stat = Orb_Uncreate;
        delete orb->pBuff;
        orb->pBuff = NULL;
    }
    return -1;
}

int orb_publish(const struct orb_metadata *meta, orb_advert_t handle, const void *data)
{
    OrbStruct *orb = (OrbStruct *)handle;
    if (hasMetaData(meta) && orb)
    {
        for (int i = 0; i < ORB_MULTI_MAX_INSTANCES; ++i)
        {
            if (meta->orbs+i==handle && orb->stat != Orb_Uncreate && orb->pBuff)
            {
                memcpy(meta->orbs[i].pBuff, data, meta->bufLen);
                orb->stat = Orb_New;
                return 0;
            }
        }
    }
    return -1;
}

int orb_subscribe(const struct orb_metadata *meta)
{
    map<string, orb_metadata*>::iterator itr = uOrbs().begin();
    for (; itr != uOrbs().end(); ++itr)
    {
        orb_metadata *metaTmp = itr->second;
        if (metaTmp == meta)
        {
            if (metaTmp->orbs->handle<=0)
                metaTmp->orbs->handle = s_fdOrb++;

            return metaTmp->orbs->handle;
        }
    }
    return -1;
}

int orb_subscribe_multi(const struct orb_metadata *meta, unsigned instance)
{
    if (instance < ORB_MULTI_MAX_INSTANCES)
    {
        map<string, orb_metadata*>::iterator itr = uOrbs().begin();
        for (; itr != uOrbs().end(); ++itr)
        {
            orb_metadata *metaTmp = itr->second;
            if (metaTmp == meta)
            {
                if (metaTmp->orbs[instance].handle <= 0)
                    metaTmp->orbs[instance].handle = s_fdOrb++;

                return metaTmp->orbs[instance].handle;
            }
        }
    }

    return -1;
}

int orb_unsubscribe(int handle)
{
    return 0;
}

int orb_copy(const struct orb_metadata *meta, int handle, void *buffer)
{
    map<string, orb_metadata*>::iterator itr = uOrbs().begin();
    for (; itr != uOrbs().end(); ++itr)
    {
        orb_metadata *metaTmp = itr->second;
        if(meta != metaTmp)
            continue;

        for (int i = 0; i < ORB_MULTI_MAX_INSTANCES; ++i)
        {
            if (metaTmp->orbs[i].handle == handle && metaTmp->orbs[i].pBuff)
            {
                memcpy(buffer, meta->orbs[i].pBuff, meta->bufLen);
                metaTmp->orbs[i].stat = Orb_Old;
                return 0;
            }
        }
    }
    return -1;
}

int orb_check(int handle, bool *updated)
{
    if (updated)
        *updated = false;

    if(OrbStruct *orb = findOrbByFd(handle))
    {
        if (orb->pBuff && orb->stat == Orb_New && updated)
            *updated = true;
        return 0;
    }
    return -1;
}

void registerOrb(const std::string &name, size_t len)
{
    if (uOrbs().find(name) == uOrbs().end() && len > 0 && len < 1024)
    {
        if (orb_metadata *tmp = new orb_metadata)
        {
            memset(tmp, 0, sizeof(orb_metadata));
            uOrbs()[name] = tmp;
            tmp->bufLen = len;
        }
    }
}

orb_id_t getOrb(const std::string &name)
{
    map<string, orb_metadata*>::iterator itr = uOrbs().find(name);
    if (itr != uOrbs().end())
        return itr->second;

    return NULL;
}
/////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////
UOrbObject::UOrbObject(const std::string &name, size_t len)
{
    registerOrb(name, len);
}
