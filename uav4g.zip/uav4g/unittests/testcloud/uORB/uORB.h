/****************************************************************************
 *
 *   Copyright (c) 2012-2015 PX4 Development Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name PX4 nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

#ifndef _UORB_UORB_H
#define _UORB_UORB_H

#define  __EXPORT
/**
 * @file uORB.h
 * API for the uORB lightweight object broker.
 */

#include <sys/types.h>
#include <stdint.h>
#include <stdbool.h>
#include <string>


#define ORB_MULTI_MAX_INSTANCES	4 // This must be < 10 (because it's the last char of the node path)

enum
{
    Orb_Uncreate = 0,
    Orb_New,
    Orb_Old,
};

struct OrbStruct{
    volatile int stat;
    volatile int handle;
    char *pBuff;
};

struct orb_metadata {
    OrbStruct orbs[ORB_MULTI_MAX_INSTANCES];
    size_t   bufLen;
};

typedef const struct orb_metadata *orb_id_t;

enum ORB_PRIO {
	ORB_PRIO_MIN = 1, // leave 0 free for other purposes, eg. marking an uninitialized value
	ORB_PRIO_VERY_LOW = 25,
	ORB_PRIO_LOW = 50,
	ORB_PRIO_DEFAULT = 75,
	ORB_PRIO_HIGH = 100,
	ORB_PRIO_VERY_HIGH = 125,
	ORB_PRIO_MAX = 255
};

typedef void *orb_advert_t;

#if defined(__cplusplus)
extern "C" {
#endif

void initialOrb();
orb_advert_t orb_advertise(const struct orb_metadata *meta, const void *data) __EXPORT;
orb_advert_t orb_advertise_multi(const struct orb_metadata *meta, const void *data, int *instance, int priority) __EXPORT;
int orb_unadvertise(orb_advert_t handle) __EXPORT;
int	orb_publish(const struct orb_metadata *meta, orb_advert_t handle, const void *data) __EXPORT;
int	orb_subscribe(const struct orb_metadata *meta) __EXPORT;
int	orb_subscribe_multi(const struct orb_metadata *meta, unsigned instance) __EXPORT;
int	orb_unsubscribe(int handle) __EXPORT;
int	orb_copy(const struct orb_metadata *meta, int handle, void *buffer) __EXPORT;
int	orb_check(int handle, bool *updated) __EXPORT;

void registerOrb(const std::string &name, size_t len)__EXPORT;
orb_id_t getOrb(const std::string &name)__EXPORT;

class UOrbObject
{
public:
    UOrbObject(const std::string &name, size_t len);
};

#define ORB_ID(_name)  getOrb(#_name)
#ifndef ORB_DECLARED
#define ORB_DECLARE(_name)	UOrbObject sUOrb_##_name(#_name, sizeof(_name##_s));
#else
#define ORB_DECLARE(_name)
#endif

#if defined(__cplusplus)
}
#endif

#endif /* _UORB_UORB_H */
