/********************************************************************************
** Form generated from reading UI file 'testcloud.ui'
**
** Created by: Qt User Interface Compiler version 5.11.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TESTCLOUD_H
#define UI_TESTCLOUD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_testcloudClass
{
public:
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_2;
    QListWidget *listWidget;
    QVBoxLayout *verticalLayout;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *edit_lat;
    QLabel *label_2;
    QLineEdit *edit_lon;
    QLabel *label_3;
    QLineEdit *edit_alt;
    QLabel *label_4;
    QLineEdit *edit_sat;
    QLabel *label_5;
    QLineEdit *edit_type;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *btn_ok;
    QGroupBox *groupBox;
    QHBoxLayout *horizontalLayout_3;
    QFormLayout *formLayout_2;
    QLabel *label_6;
    QLineEdit *edit_mtype;
    QLabel *label_7;
    QLineEdit *edit_frame;
    QLabel *label_8;
    QLineEdit *edit_auto;
    QLabel *label_12;
    QLineEdit *edit_param1;
    QLabel *label_14;
    QLineEdit *edit_param3;
    QFormLayout *formLayout_3;
    QLabel *label_9;
    QLineEdit *edit_mlat;
    QLabel *label_10;
    QLineEdit *edit_mlon;
    QLabel *label_11;
    QLineEdit *edit_malt;
    QLabel *label_13;
    QLineEdit *edit_param2;
    QLabel *label_15;
    QLineEdit *edit_param4;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *btn_view;

    void setupUi(QDialog *testcloudClass)
    {
        if (testcloudClass->objectName().isEmpty())
            testcloudClass->setObjectName(QStringLiteral("testcloudClass"));
        testcloudClass->resize(397, 374);
        verticalLayout_2 = new QVBoxLayout(testcloudClass);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setSizeConstraint(QLayout::SetFixedSize);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        listWidget = new QListWidget(testcloudClass);
        listWidget->setObjectName(QStringLiteral("listWidget"));

        horizontalLayout_2->addWidget(listWidget);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        formLayout = new QFormLayout();
        formLayout->setSpacing(6);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        label = new QLabel(testcloudClass);
        label->setObjectName(QStringLiteral("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        edit_lat = new QLineEdit(testcloudClass);
        edit_lat->setObjectName(QStringLiteral("edit_lat"));

        formLayout->setWidget(0, QFormLayout::FieldRole, edit_lat);

        label_2 = new QLabel(testcloudClass);
        label_2->setObjectName(QStringLiteral("label_2"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_2);

        edit_lon = new QLineEdit(testcloudClass);
        edit_lon->setObjectName(QStringLiteral("edit_lon"));

        formLayout->setWidget(1, QFormLayout::FieldRole, edit_lon);

        label_3 = new QLabel(testcloudClass);
        label_3->setObjectName(QStringLiteral("label_3"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_3);

        edit_alt = new QLineEdit(testcloudClass);
        edit_alt->setObjectName(QStringLiteral("edit_alt"));

        formLayout->setWidget(2, QFormLayout::FieldRole, edit_alt);

        label_4 = new QLabel(testcloudClass);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout->setWidget(3, QFormLayout::LabelRole, label_4);

        edit_sat = new QLineEdit(testcloudClass);
        edit_sat->setObjectName(QStringLiteral("edit_sat"));

        formLayout->setWidget(3, QFormLayout::FieldRole, edit_sat);

        label_5 = new QLabel(testcloudClass);
        label_5->setObjectName(QStringLiteral("label_5"));

        formLayout->setWidget(4, QFormLayout::LabelRole, label_5);

        edit_type = new QLineEdit(testcloudClass);
        edit_type->setObjectName(QStringLiteral("edit_type"));

        formLayout->setWidget(4, QFormLayout::FieldRole, edit_type);


        verticalLayout->addLayout(formLayout);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        btn_ok = new QPushButton(testcloudClass);
        btn_ok->setObjectName(QStringLiteral("btn_ok"));

        horizontalLayout->addWidget(btn_ok);


        verticalLayout->addLayout(horizontalLayout);


        horizontalLayout_2->addLayout(verticalLayout);


        verticalLayout_2->addLayout(horizontalLayout_2);

        groupBox = new QGroupBox(testcloudClass);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setFlat(true);
        horizontalLayout_3 = new QHBoxLayout(groupBox);
        horizontalLayout_3->setSpacing(20);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        formLayout_2 = new QFormLayout();
        formLayout_2->setSpacing(6);
        formLayout_2->setObjectName(QStringLiteral("formLayout_2"));
        label_6 = new QLabel(groupBox);
        label_6->setObjectName(QStringLiteral("label_6"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_6);

        edit_mtype = new QLineEdit(groupBox);
        edit_mtype->setObjectName(QStringLiteral("edit_mtype"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, edit_mtype);

        label_7 = new QLabel(groupBox);
        label_7->setObjectName(QStringLiteral("label_7"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, label_7);

        edit_frame = new QLineEdit(groupBox);
        edit_frame->setObjectName(QStringLiteral("edit_frame"));

        formLayout_2->setWidget(1, QFormLayout::FieldRole, edit_frame);

        label_8 = new QLabel(groupBox);
        label_8->setObjectName(QStringLiteral("label_8"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, label_8);

        edit_auto = new QLineEdit(groupBox);
        edit_auto->setObjectName(QStringLiteral("edit_auto"));

        formLayout_2->setWidget(2, QFormLayout::FieldRole, edit_auto);

        label_12 = new QLabel(groupBox);
        label_12->setObjectName(QStringLiteral("label_12"));

        formLayout_2->setWidget(3, QFormLayout::LabelRole, label_12);

        edit_param1 = new QLineEdit(groupBox);
        edit_param1->setObjectName(QStringLiteral("edit_param1"));

        formLayout_2->setWidget(3, QFormLayout::FieldRole, edit_param1);

        label_14 = new QLabel(groupBox);
        label_14->setObjectName(QStringLiteral("label_14"));

        formLayout_2->setWidget(4, QFormLayout::LabelRole, label_14);

        edit_param3 = new QLineEdit(groupBox);
        edit_param3->setObjectName(QStringLiteral("edit_param3"));

        formLayout_2->setWidget(4, QFormLayout::FieldRole, edit_param3);


        horizontalLayout_3->addLayout(formLayout_2);

        formLayout_3 = new QFormLayout();
        formLayout_3->setSpacing(6);
        formLayout_3->setObjectName(QStringLiteral("formLayout_3"));
        label_9 = new QLabel(groupBox);
        label_9->setObjectName(QStringLiteral("label_9"));

        formLayout_3->setWidget(0, QFormLayout::LabelRole, label_9);

        edit_mlat = new QLineEdit(groupBox);
        edit_mlat->setObjectName(QStringLiteral("edit_mlat"));

        formLayout_3->setWidget(0, QFormLayout::FieldRole, edit_mlat);

        label_10 = new QLabel(groupBox);
        label_10->setObjectName(QStringLiteral("label_10"));

        formLayout_3->setWidget(1, QFormLayout::LabelRole, label_10);

        edit_mlon = new QLineEdit(groupBox);
        edit_mlon->setObjectName(QStringLiteral("edit_mlon"));

        formLayout_3->setWidget(1, QFormLayout::FieldRole, edit_mlon);

        label_11 = new QLabel(groupBox);
        label_11->setObjectName(QStringLiteral("label_11"));

        formLayout_3->setWidget(2, QFormLayout::LabelRole, label_11);

        edit_malt = new QLineEdit(groupBox);
        edit_malt->setObjectName(QStringLiteral("edit_malt"));

        formLayout_3->setWidget(2, QFormLayout::FieldRole, edit_malt);

        label_13 = new QLabel(groupBox);
        label_13->setObjectName(QStringLiteral("label_13"));

        formLayout_3->setWidget(3, QFormLayout::LabelRole, label_13);

        edit_param2 = new QLineEdit(groupBox);
        edit_param2->setObjectName(QStringLiteral("edit_param2"));

        formLayout_3->setWidget(3, QFormLayout::FieldRole, edit_param2);

        label_15 = new QLabel(groupBox);
        label_15->setObjectName(QStringLiteral("label_15"));

        formLayout_3->setWidget(4, QFormLayout::LabelRole, label_15);

        edit_param4 = new QLineEdit(groupBox);
        edit_param4->setObjectName(QStringLiteral("edit_param4"));

        formLayout_3->setWidget(4, QFormLayout::FieldRole, edit_param4);


        horizontalLayout_3->addLayout(formLayout_3);


        verticalLayout_2->addWidget(groupBox);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_2);

        btn_view = new QPushButton(testcloudClass);
        btn_view->setObjectName(QStringLiteral("btn_view"));

        horizontalLayout_4->addWidget(btn_view);


        verticalLayout_2->addLayout(horizontalLayout_4);


        retranslateUi(testcloudClass);

        QMetaObject::connectSlotsByName(testcloudClass);
    } // setupUi

    void retranslateUi(QDialog *testcloudClass)
    {
        testcloudClass->setWindowTitle(QApplication::translate("testcloudClass", "testcloud", nullptr));
        label->setText(QApplication::translate("testcloudClass", "lat:", nullptr));
        edit_lat->setText(QApplication::translate("testcloudClass", "28.243140", nullptr));
        label_2->setText(QApplication::translate("testcloudClass", "lon:", nullptr));
        edit_lon->setText(QApplication::translate("testcloudClass", "112.992856", nullptr));
        label_3->setText(QApplication::translate("testcloudClass", "alt:", nullptr));
        edit_alt->setText(QApplication::translate("testcloudClass", "3", nullptr));
        label_4->setText(QApplication::translate("testcloudClass", "satellite:", nullptr));
        edit_sat->setText(QApplication::translate("testcloudClass", "11", nullptr));
        label_5->setText(QApplication::translate("testcloudClass", "fixType:", nullptr));
        edit_type->setText(QApplication::translate("testcloudClass", "238", nullptr));
        btn_ok->setText(QApplication::translate("testcloudClass", "OK", nullptr));
        groupBox->setTitle(QApplication::translate("testcloudClass", "missionItem:", nullptr));
        label_6->setText(QApplication::translate("testcloudClass", "type:", nullptr));
        label_7->setText(QApplication::translate("testcloudClass", "frame:", nullptr));
        label_8->setText(QApplication::translate("testcloudClass", "auto:", nullptr));
        label_12->setText(QApplication::translate("testcloudClass", "param1:", nullptr));
        label_14->setText(QApplication::translate("testcloudClass", "param3:", nullptr));
        label_9->setText(QApplication::translate("testcloudClass", "lat:", nullptr));
        label_10->setText(QApplication::translate("testcloudClass", "lon:", nullptr));
        label_11->setText(QApplication::translate("testcloudClass", "relative:", nullptr));
        label_13->setText(QApplication::translate("testcloudClass", "param2:", nullptr));
        label_15->setText(QApplication::translate("testcloudClass", "param4:", nullptr));
        btn_view->setText(QApplication::translate("testcloudClass", "View", nullptr));
    } // retranslateUi

};

namespace Ui {
    class testcloudClass: public Ui_testcloudClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TESTCLOUD_H
