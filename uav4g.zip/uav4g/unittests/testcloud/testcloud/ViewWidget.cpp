#include "ViewWidget.h"
#include <QPainter>
#include <QShortcut>
#include <QMouseEvent>
#include "ViewRule.h"
#include "ViewUnit.h"

ViewWidget::ViewWidget(QWidget *parent/*=NULL*/):QWidget(parent)
, m_rule(new ViewRule(this)), m_sc(new QShortcut(QKeySequence("M"), this))
, m_stat(Nomal),m_posX(0), m_posY(0), m_polyline(NULL)
{
    setContentsMargins(10, 10, 10, 10);
    if (m_sc)
        connect(m_sc, &QShortcut::activated, this, &ViewWidget::onScActive);
}

void ViewWidget::AddPolygon(const VGPolygon &plg, int tp)
{
    for (const VGPoint &itr : plg.Points())
    {
        m_rule->CalculateRule(itr);
    }
    if (ViewPolygon *tmp = new ViewPolygon(plg, tp))
        m_uints << tmp;

    update();
}

void ViewWidget::AddPolyline(const VGPolyLine &pll, int tp)
{
    for (const VGPoint &itr : pll.RoutePoints())
    {
        m_rule->CalculateRule(itr);
    }
    if (!m_polyline)
        m_polyline = new ViewPolyline(pll, tp);

    if (m_polyline && ((ViewPolyline *)m_polyline)->GetData() != &pll)
        ((ViewPolyline *)m_polyline)->SetData(pll);

    update();
}

void ViewWidget::AddPoint(const VGPoint &pnt, int tp)
{
    m_rule->CalculateRule(pnt);
    update();
}

void ViewWidget::Clear()
{
    qDeleteAll(m_uints);
    m_uints.clear();
    m_rule->Clear();
}

void ViewWidget::mousePressEvent(QMouseEvent *evt)
{
    if (evt->button() != Qt::LeftButton || m_stat == Nomal || !m_rule)
        return QWidget::mousePressEvent(evt);

    if (SetBeg == m_stat)
    {
        m_stat = SetEnd;
        VGPoint pnt;
        if (!m_rule->tranceFromView(evt->pos(), pnt))
        {
            setCursor(Qt::ArrowCursor);
            m_stat = Nomal;
            return;
        }
        m_posX = pnt.X();
        m_posY = pnt.Y();
    }
    else if (SetEnd == m_stat)
    {
        setCursor(Qt::ArrowCursor);
        m_stat = Nomal;
        VGPoint pnt;
        m_rule->tranceFromView(evt->pos(), pnt);
        emit rtlCal(VGPoint(m_posX, m_posY), pnt);
    }
}

void ViewWidget::paintEvent(QPaintEvent *)
{
    m_rule->CalculateOrigin();
    QPainter p(this);
    for (ViewUnit *itr : m_uints)
    {
        itr->Draw(&p, *m_rule);
    }
    if(m_polyline)
        m_polyline->Draw(&p, *m_rule);
}

void ViewWidget::onScActive()
{
    if (m_stat == Nomal)
    {
        m_stat = SetBeg;
        setCursor(Qt::CrossCursor);
    }
}
