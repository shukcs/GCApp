#include "sysfunc.h"
#include <QDateTime>
#include <windows.h>
#include <stdarg.h>

uint64_t hrt_absolute_time()
{
    return QDateTime::currentMSecsSinceEpoch() * 1000;
}

hrt_abstime hrt_elapsed_time(hrt_abstime *t)
{
    hrt_abstime ret = hrt_absolute_time() - (t ? *t : 0);
    return ret;
}

void usleep(uint32_t us)
{
    ::Sleep(us / 1e3);
}

void cmdMsg(const char *file, int line, const char *fmt, ...)
{
    char buff[256];
    va_list argptr;
    int len;
    va_start(argptr, fmt);
    len = vsprintf(buff, fmt, argptr);
    strcpy(buff + len, "\r\n");
    va_end(argptr);
    printf("[%d: %s]", GetCurrentThreadId(), QDateTime::currentDateTime().toString("yyyy/MM/dd hh:mm:ss").toUtf8().data());

    if (file)
        printf("(%s:line%d)", file, line);
    printf(buff);
}

void unexpectLog(FILE *f, char *fmt, ...)
{
    if (f)
    {
        char buff[256];
        fprintf(f, "unexpect[%s]:", QDateTime::currentDateTime().toString("yyyy/MM/dd hh:mm:ss").toUtf8().data());
        va_list argptr;
        int len;
        va_start(argptr, fmt);
        len = vsprintf(buff, fmt, argptr);
        strcpy(buff + len, "\r\n");
        va_end(argptr);

        fwrite(buff, 1, len + 2, f);
    }
}

