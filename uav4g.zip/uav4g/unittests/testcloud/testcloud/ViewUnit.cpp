#include "ViewUnit.h"
#include "ViewRule.h"
#include <QPainter>
#include <saferoute/RouteStruct.h>

ViewPoint::ViewPoint(const VGPoint &pnt, int tp):ViewUnit()
, m_data(&pnt), m_type(tp)
{
}

void ViewPoint::Draw(QPainter *pt, const ViewRule &rule)
{
    if (pt && m_data)
    {
        QPoint pnt;
        if (rule.tranceToView(*m_data, pnt))
        {
            pt->setPen(QPen(m_type == 0 ? Qt::blue : Qt::red, 2));
            pt->drawPoint(pnt);
        }
    }
}
////////////////////////////////////////////////////////////////////
//ViewPolygon
////////////////////////////////////////////////////////////////////
ViewPolygon::ViewPolygon(const VGPolygon &plg, int tp) :ViewUnit()
, m_data(&plg), m_type(tp)
{
}

void ViewPolygon::Draw(QPainter *pt, const ViewRule &rule)
{
    if (pt && m_data)
    {
        QPolygonF plg;
        for (const VGPoint &itr : m_data->Points())
        {
            QPoint pnt;
            if (rule.tranceToView(itr, pnt))
                plg.append(pnt);
        }
        pt->setPen(QPen(m_type == 0 ? Qt::blue : Qt::red, 1));
        pt->setBrush(Qt::NoBrush);
        pt->drawPolygon(plg);
    }
}
//////////////////////////////////////////////////////////////////////
//ViewPolygon
//////////////////////////////////////////////////////////////////////
ViewPolyline::ViewPolyline(const VGPolyLine &pll, int tp) : ViewUnit()
, m_data(&pll), m_type(tp)
{
}

void ViewPolyline::Draw(QPainter *pt, const ViewRule &rule)
{
    if (pt && m_data)
    {
        QPolygonF plg;
        pt->setPen(QPen(Qt::darkGreen, 5));
        for (const VGPoint &itr : m_data->RoutePoints())
        {
            QPoint pnt;
            if (rule.tranceToView(itr, pnt))
            {
                plg.append(pnt);
                pt->drawPoint(pnt);
            }
        }
        pt->setPen(QPen(Qt::green, 1));
        pt->drawPolyline(plg);
    }
}

void ViewPolyline::SetData(const VGPolyLine &pll)
{
    m_data = &pll;
}

const VGPolyLine * ViewPolyline::GetData() const
{
    return m_data;
}
