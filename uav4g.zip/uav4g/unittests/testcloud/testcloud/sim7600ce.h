#ifndef __SIM7600EC_H__
#define __SIM7600EC_H__

#if defined(__cplusplus)
extern "C" {
#endif
    void beginThread();

#if defined(__cplusplus)
}
#endif
#endif //__SIM7600EC_H__