#include "testcloud.h"
#include <QtWidgets/QApplication>
#include <sim7600ce.h>
#include "mavlink/mavlinkthread.h"
#include "qxwz_ntrip/qxwz_ntrip.h"
#include <QByteArray>
#include <socket4g/sock4glib.h>

int main(int argc, char *argv[])
{
    beginThread();
    //qxwz_ntrip_main(0, NULL);
    QApplication a(argc, argv);
    TestCloud w;
    w.show();
    MavlinkThread *mav = new MavlinkThread;
    QObject::connect(mav, &MavlinkThread::mavReceived, &w, &TestCloud::onRecvMavlink);
    return a.exec();
}
