#ifndef __VIEWWIDGET_H__
#define __VIEWWIDGET_H__

#include <QtWidgets/QWidget>
#include <QList>

class ViewUnit;
class ViewRule;
class VGPolygon;
class VGPolyLine;
class VGPoint;
class QShortcut;
class ViewWidget : public QWidget
{
    Q_OBJECT

    enum OpStat {
        Nomal,
        SetBeg,
        SetEnd
    };
public:
    ViewWidget(QWidget *parent=NULL);
    void AddPolygon(const VGPolygon &plg, int tp);
    void AddPolyline(const VGPolyLine &pll, int tp);
    void AddPoint(const VGPoint &pnt, int tp);
    void Clear();
protected:
    void mousePressEvent(QMouseEvent *evt);
    void paintEvent(QPaintEvent *evt);
protected slots:
    void onScActive();
signals:
    void rtlCal(const VGPoint &beg, const VGPoint &end);
private:
    QList<ViewUnit*>    m_uints;
    ViewRule            *m_rule;
    QShortcut           *m_sc;
    OpStat              m_stat;
    ViewUnit            *m_polyline;
    double              m_posX;
    double              m_posY;
};

#endif //__VIEWWIDGET_H__