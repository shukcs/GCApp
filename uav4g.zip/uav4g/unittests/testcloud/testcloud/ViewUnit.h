#ifndef __VIEWUNIT_H__
#define __VIEWUNIT_H__

class QPainter;
class ViewRule;
class VGPoint;
class VGPolygon;
class VGPolyLine;

class ViewUnit
{
public:
    virtual~ViewUnit() {};
    virtual void Draw(QPainter *pt, const ViewRule &rule) {}
};

class ViewPoint : public ViewUnit
{
public:
    ViewPoint(const VGPoint &pnt, int tp);
    void Draw(QPainter *pt, const ViewRule &rule);
protected:
private:
    int     m_type;
    const   VGPoint *m_data;
};

class ViewPolygon : public ViewUnit
{
public:
    ViewPolygon(const VGPolygon &plg, int tp);
    void Draw(QPainter *pt, const ViewRule &rule);
protected:
private:
    int              m_type;
    const VGPolygon  *m_data;
};

class ViewPolyline : public ViewUnit
{
public:
    ViewPolyline(const VGPolyLine &pll, int tp=0);
    void Draw(QPainter *pt, const ViewRule &rule);
    void SetData(const VGPolyLine &pll);
    const VGPolyLine *GetData()const;
protected:
private:
    int                 m_type;
    const VGPolyLine    *m_data;
};

#endif //__VIEWUNIT_H__