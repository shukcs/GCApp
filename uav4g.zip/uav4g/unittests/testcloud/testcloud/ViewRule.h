#ifndef __VIEWRULE_H__
#define __VIEWRULE_H__

#include <QPoint>
#include <saferoute/RouteStruct.h>

class QWidget;
class ViewRule
{
public:
    ViewRule(QWidget *p);

    void Clear();
    void CalculateRule(const VGPoint &pnt);
    void CalculateOrigin();
    bool tranceToView(const VGPoint &pnt, QPoint &rst)const;
    bool tranceFromView(const QPoint &pnt, VGPoint &rst)const;
private:
    double  m_left;
    double  m_top;
    double  m_width;
    double  m_height;
    double  m_lpp;//һ�����س�
    QWidget *m_view;
    bool    m_bInit;
    QPoint  m_orgiginView;
};

#endif //__VIEWRULE_H__