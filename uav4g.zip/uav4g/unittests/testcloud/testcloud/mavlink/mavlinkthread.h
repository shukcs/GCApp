#ifndef __MAVLINKTHREAD_H__
#define __MAVLINKTHREAD_H__

#include <QObject>
#include <v2.0/standard/mavlink.h>

class QThread;
class QTimer;

class MavlinkThread : public QObject
{
    Q_OBJECT
public:
    MavlinkThread(QObject *parent=NULL);
    void recv(const mavlink_message_t &msg);
protected slots:
    void onTimer();
private:
    void initialMavlink(void);
signals:
    void mavReceived(const mavlink_message_t &msg);
private:
    QThread     *m_thread;
    QTimer      *m_timer;
};



#endif //__MAVLINKTHREAD_H__