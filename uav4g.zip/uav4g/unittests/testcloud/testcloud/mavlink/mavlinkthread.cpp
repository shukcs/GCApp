#include "mavlinkthread.h"
#include <QThread>
#include <QTimer>
#include <mavlink/cloudlink.h>
#include "sysfunc.h"

MavlinkThread::MavlinkThread(QObject *parent/*=NULL*/):QObject(parent)
, m_thread(new QThread(this)), m_timer(NULL)
{
    qRegisterMetaType<mavlink_message_t>("mavlink_message_t");
    if (m_thread)
    {
        m_timer = new QTimer(this);
        m_timer->start(10);
        moveToThread(m_thread);
        m_thread->start();
        connect(m_timer, &QTimer::timeout, this, &MavlinkThread::onTimer);
    }

    initialMavlink();
}

void MavlinkThread::recv(const mavlink_message_t &msg)
{
    emit mavReceived(msg);
}

void MavlinkThread::onTimer()
{
    mavlink_message_t msg;
    while (CloudLink::RecvMavLink(msg))
    {
        recv(msg);
    }
}

void MavlinkThread::initialMavlink(void)
{
    CloudLink::InitialCloudLink();
}
