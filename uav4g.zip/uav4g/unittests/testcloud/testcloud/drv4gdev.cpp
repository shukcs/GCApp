#include "drv4gdev.h"
#include <windows.h>
#include <string.h>
#include <stdio.h>

#define INVALIDIP 0xffffffff
#define MaxSockCom 8
typedef struct _tagSock {
    bool            used : 1;
    short           stat : 15;
    SOCKET          sock;
}Sock4GInfo;

static char s_buffCmd[64];
typedef struct _socks {
    Sock4GInfo  socks[MaxSockCom];
    uint8_t     bCsq : 4;
    uint8_t     sockCur : 4;
    short       sockCurRcv : 4;
    uint32_t    remaind : 20;
}SockInfos;

static SockInfos s_sockInfos;

static Sock4GInfo *getSockinfoBySock(int sock)
{
    Sock4GInfo *info = NULL;
    if (sock < 0 || sock>MaxSockCom)
        return NULL;

    info = s_sockInfos.socks + sock;
    if (info->used)
        return info;

    return NULL;
}

static int getUnusedSock(void)
{
    Sock4GInfo *info = s_sockInfos.socks;
    int i = 0;
    for (; i < MaxSockCom; ++i)
    {
        if (!info->used)
            return i;
        ++info;
    }

    return -1;
}

static bool isConnect(short st)
{
    return  st == Sock_Connected
        || st == Sock_Sending
        || st == Sock_Sended;
}

const char *StrError(int x)
{
    static	char tmp[100];
    switch (x)
    {
    case 10004: return "Interrupted function call.";
    case 10013: return "Permission denied.";
    case 10014: return "Bad address.";
    case 10022: return "Invalid argument.";
    case 10024: return "Too many open files.";
    case 10035: return "Resource temporarily unavailable.";
    case 10036: return "Operation now in progress.";
    case 10037: return "Operation already in progress.";
    case 10038: return "Socket operation on nonsocket.";
    case 10039: return "Destination address required.";
    case 10040: return "Message too long.";
    case 10041: return "Protocol wrong type for socket.";
    case 10042: return "Bad protocol option.";
    case 10043: return "Protocol not supported.";
    case 10044: return "Socket type not supported.";
    case 10045: return "Operation not supported.";
    case 10046: return "Protocol family not supported.";
    case 10047: return "Address family not supported by protocol family.";
    case 10048: return "Address already in use.";
    case 10049: return "Cannot assign requested address.";
    case 10050: return "Network is down.";
    case 10051: return "Network is unreachable.";
    case 10052: return "Network dropped connection on reset.";
    case 10053: return "Software caused connection abort.";
    case 10054: return "Connection reset by peer.";
    case 10055: return "No buffer space available.";
    case 10056: return "Socket is already connected.";
    case 10057: return "Socket is not connected.";
    case 10058: return "Cannot send after socket shutdown.";
    case 10060: return "Connection timed out.";
    case 10061: return "Connection refused.";
    case 10064: return "Host is down.";
    case 10065: return "No route to host.";
    case 10067: return "Too many processes.";
    case 10091: return "Network subsystem is unavailable.";
    case 10092: return "Winsock.dll version out of range.";
    case 10093: return "Successful WSAStartup not yet performed.";
    case 10101: return "Graceful shutdown in progress.";
    case 10109: return "Class type not found.";
    case 11001: return "Host not found.";
    case 11002: return "Nonauthoritative host not found.";
    case 11003: return "This is a nonrecoverable error.";
    case 11004: return "Valid name, no data record of requested type.";

    default:
        break;
    }
    snprintf(tmp, sizeof(tmp), "Winsock error code: %d", x);
    return tmp;
}

class WSAInitializer // Winsock Initializer
{
public:
    WSAInitializer()
    {
#if defined _WIN32 || defined _WIN64
        WSADATA wsadata;
        if (WSAStartup(MAKEWORD(2, 2), &wsadata))
        {
            exit(-1);
        }
#endif //defined _WIN32 || defined _WIN64
    }
    ~WSAInitializer()
    {
#if defined _WIN32 || defined _WIN64
        WSACleanup();
#endif //defined _WIN32 || defined _WIN64
    }
private:
};

bool Initial4GDev(const char *path, char *)
{
    static WSAInitializer s;
    return true;
}

void BeginParse(void)
{
}

void ParseRcvBuff()
{
}

void ResetRcvBuff(void)
{
}

short Create4GSock(short sock)
{
    Sock4GInfo *info = NULL;
    if (sock >= 0 && sock < MaxSockCom)
        info = s_sockInfos.socks + sock;
    else if ((sock = getUnusedSock()) >= 0)
        info = s_sockInfos.socks + sock;

    if (info)
    {
        info->used = true;
        info->stat = Sock_OK;
        return sock;
    }
    return -1;
}

bool Connect4G(int id, const char *host, unsigned short port)
{
    if (Sock4GInfo *sock = getSockinfoBySock(id))
    {
        int st = sock ? sock->stat : Sock_UnCreate;
        if (Sock_OK == st
            || Sock_ConnectErr == st
            || Sock_Disconnected == st
            || Sock_Closed == st)
        {
            sock->sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
            unsigned long ul = 1;
            if (sock->sock == -1)
            {
                sock->stat = Sock_ConnectErr;
                return false;
            }
            struct sockaddr_in addr = { 0 };
            addr.sin_family = AF_INET;
            addr.sin_addr.s_addr = inet_addr(host);//htons(portnumber);
            addr.sin_port = htons(port);
            bool bConnect = (connect(sock->sock, (sockaddr *)&addr, sizeof(addr))!=SOCKET_ERROR);
            s_sockInfos.sockCur = id;
            sock->stat = bConnect ? Sock_Connected : Sock_ConnectErr;
            if (!bConnect)
            {
                closesocket(sock->sock);
                sock->sock = -1;
                printf(StrError(errno));
            }
            ioctlsocket(sock->sock, FIONBIO, &ul);
            return bConnect;
        }
    }
    return false;
}

bool Close4GSock(int id)
{
    if (Sock4GInfo *sock = getSockinfoBySock(id))
    {
        if (sock && sock->stat != Sock_UnCreate && sock->sock != -1)
        {
            closesocket(sock->sock);
            sock->sock = -1;
            sock->stat = Sock_Closed;
            return true;
        }
    }
    return false;
}

int Send4G(int sock, char *buff, int len)
{
    Sock4GInfo *sockInfo = getSockinfoBySock(sock);
    if (!sockInfo || sockInfo->sock==-1)
        return 0;

    if (sockInfo->stat == Sock_Connected || sockInfo->stat == Sock_Sended || sockInfo->stat == Sock_SendFail)
    {
        int nSend = send(sockInfo->sock, buff, len, 0);
        s_sockInfos.sockCur = sock;
        if (nSend < 0)
            Close4GSock(sock);
        else
            sockInfo->stat = nSend == len ? Sock_Sended : Sock_SendFail;

        return nSend;
    }
    return 0;
}

int Recv4G(int sock, char *buf, unsigned len)
{
    Sock4GInfo *info = getSockinfoBySock(sock);
    if (!info || !isConnect(info->stat))
        return 0;

    int n = recv(info->sock, buf, len, 0);

    return n;
}

Status4G Get4gStat(int sock)
{
    Sock4GInfo *info = getSockinfoBySock(sock);
    if (!info)
        return Sock_UnCreate;

    return (Status4G)info->stat;
}

void Close4G(void)
{
    for (int i = 0; i < MaxSockCom; ++i)
    {
        if (s_sockInfos.socks[i].used)
            Close4GSock(i);
    }
}