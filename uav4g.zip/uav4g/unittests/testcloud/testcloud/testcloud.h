#ifndef __TESTCLOUD_H__
#define __TESTCLOUD_H__

#include <QtWidgets/QDialog>
#include <v2.0/standard/mavlink.h>
#include <QGeoCoordinate>

namespace Ui {
    class testcloudClass;
}
class ViewWidget;
class VGPoint;

class TestCloud : public QDialog
{
    Q_OBJECT
public:
    TestCloud(QWidget *parent = Q_NULLPTR);
public slots:
    void onRecvMavlink(const mavlink_message_t &msg);
    void onBtnOk();
    void onBtnView();
    void onSelectedItem(int index);
protected:
    void timerEvent(QTimerEvent *e);
protected slots:
    void onTtlCal(const VGPoint &beg, const VGPoint &end);
private:
    void reqMission(int req, uint8_t tp);
    void sendParam(const char *id);
    void sendCmdAck(uint32_t cmd, bool res);
    void returnToL();
    void testRTL(double lat, double lon, double latEnd, double lonEnd);
    QGeoCoordinate checkPos();

    void sentGpsOrb(const mavlink_gps_raw_int_t &gps);
    void _sendGps();
    void _arm(bool b);
    void sendHome();
    void sendHeartbeat();
    void _sendAssist();
    void prcsMissionCount(const mavlink_message_t &msg);
    void prcsMissionItem(const mavlink_message_t &msg);
    void prcsParamRead(const mavlink_message_t &msg);
    void prcsParamSet(const mavlink_message_t &msg);
    void prcsSetMode(const mavlink_message_t &msg);
    void prcsMavCommand(const mavlink_message_t &msg);
    void prcsMissionRequest(const mavlink_message_t &msg);
    void setAssist(const mavlink_command_int_t &cmd);
private:
    Ui::testcloudClass *m_ui;
    int         m_countMissions;
    int         m_idTimer;
    int         m_curFly;
    int         m_nLoad;
    void        *m_handGps;
    double      m_routCur;
    bool        m_bArm;
    uint8_t     m_baseMode;    //����ģʽ
    uint32_t    m_customMode;  //����ģʽ
    QGeoCoordinate m_home;
    QGeoCoordinate m_enter;
    QGeoCoordinate m_return;
    QGeoCoordinate m_suspend;
    QList<mavlink_mission_item_int_t> m_missionItems;
    ViewWidget *m_view;
};

#endif //__TESTCLOUD_H__