#include "ViewRule.h"
#include <QWidget>

ViewRule::ViewRule(QWidget *p) :m_left(0)
, m_top(0), m_width(0), m_height(0), m_bInit(false)
, m_view(p)
{
}

void ViewRule::Clear()
{
    m_bInit = false;
}

void ViewRule::CalculateRule(const VGPoint &pnt)
{
    if (!m_bInit)
    {
        m_bInit = true;
        m_left = pnt.GetX();
        m_top = pnt.GetY();
        m_height = 0;
        m_width = 0;
        return;
    }

    double tmp = pnt.GetX() - m_left;
    if (tmp < 0)
    {
        m_width -= tmp;
        m_left = pnt.GetX();
    }
    else if (tmp > m_width)
    {
        m_width = tmp;
    }

    tmp = pnt.GetY() - m_top;
    if (tmp < 0)
    {
        m_height -= tmp;
        m_top = pnt.GetY();
    }
    else if (tmp > m_height)
    {
        m_height = tmp;
    }
}

void ViewRule::CalculateOrigin()
{
    if (m_view && m_bInit)
    {
        QRect rect = m_view->contentsRect();
        if (rect.width() == 0 || rect.height() == 0 || (m_width==0 && m_height == 0))
        {
            m_lpp = 0;
            return;
        }

        if (rect.width()*m_height > rect.height()*m_width)
            m_lpp = m_height / rect.height();
        else
            m_lpp = m_width / rect.width();

        int nW = m_width / m_lpp;
        int nH = m_height / m_lpp;
        m_orgiginView.setX(nW < rect.width() ? (rect.width() - nW) / 2 : rect.left());
        m_orgiginView.setY(nH < rect.height() ? rect.top()+(rect.height() - nH) / 2 : rect.top());
    }
}

bool ViewRule::tranceToView(const VGPoint &pnt, QPoint &rst)const
{
    if (m_lpp > 1e-6 && m_view && m_bInit)
    {
        int tmp = (pnt.GetX() - m_left) / m_lpp;
        rst.setX(m_orgiginView.x()+tmp);
        tmp = (m_top + m_height-pnt.GetY()) / m_lpp;
        rst.setY(m_orgiginView.y()+tmp);
        return true;
    }
    return false;
}

bool ViewRule::tranceFromView(const QPoint &pnt, VGPoint &rst)const
{
    if (m_lpp > 1e-6 && m_view && m_bInit)
    {
        rst.X() = m_left + (pnt.x() - m_orgiginView.x()) * m_lpp;
        rst.Y() = m_top+ m_height + (m_orgiginView.y() - pnt.y()) * m_lpp;
        return true;
    }
    return false;
}
