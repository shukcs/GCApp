#include "testcloud.h"
#include <mavlink/cloudlink.h>
#include "saferoute/SafeRoute.h"
#include "saferoute/RouteStruct.h"
#include <qmath.h>
#include <QMap>
#include <commander/px4_custom_mode.h>
#include "ViewWidget.h"
#include "ui_testcloud.h"
#include <QDateTime>
#define ORB_DECLARED
#include <uORB/topics/vehicle_gps_position.h>
#include <uORB.h>

#define NAMEPARAMUAVID "SYS_UAV_ID"
#define CLOUDHOSTID "HOST_IP"
#define CLOUDPORTID "HOST_PORT"
#define MPC_ALT_MODE "MPC_ALT_MODE"

static SafeRoute sSafeRoute;
static QMap<ModeType, px4_custom_mode> &GetModeMap()
{
    static QMap<ModeType, px4_custom_mode> s_Map;
    if (s_Map.size() == 0)
    {
        px4_custom_mode mode;
        mode.data = 0;
        mode.main_mode = PX4_CUSTOM_MAIN_MODE_AUTO;
        mode.sub_mode = PX4_CUSTOM_SUB_MODE_AUTO_MISSION;
        s_Map[Mode_Mission] = mode;

        mode.data = 0;
        mode.main_mode = PX4_CUSTOM_MAIN_MODE_AUTO;
        mode.sub_mode = PX4_CUSTOM_SUB_MODE_AUTO_LOITER;
        s_Map[Mode_Hold] = mode;

        mode.data = 0;
        mode.main_mode = PX4_CUSTOM_MAIN_MODE_MANUAL;
        mode.sub_mode = 0;
        s_Map[Mode_Manual] = mode;

        mode.data = 0;
        mode.main_mode = PX4_CUSTOM_MAIN_MODE_AUTO;
        mode.sub_mode = PX4_CUSTOM_SUB_MODE_AUTO_RTL;
        s_Map[Mode_Return] = mode;

        mode.data = 0;
        mode.main_mode = PX4_CUSTOM_MAIN_MODE_AUTO;
        mode.sub_mode = PX4_CUSTOM_SUB_MODE_AUTO_MAG_MISSION;
        s_Map[Mode_MagMsm] = mode;

        mode.data = 0;
        mode.main_mode = PX4_CUSTOM_MAIN_MODE_AUTO;
        mode.sub_mode = PX4_CUSTOM_SUB_MODE_AUTO_LAND;
        s_Map[Mode_Landing] = mode;
    }
    return s_Map;
}

static QGeoCoordinate getViaPos(const QGeoCoordinate &beg, const QGeoCoordinate &end, double per)
{
    if (per > 1)
        per = 1;

    QGeoCoordinate ret;
    double tmp = beg.latitude()*(1 - per) + end.latitude()*per;
    ret.setLatitude(tmp);
    tmp = beg.longitude()*(1 - per) + end.longitude()*per;
    ret.setLongitude(tmp);
    tmp = beg.altitude()*(1 - per) + end.altitude()*per;
    ret.setAltitude(tmp);

    return ret;
}

static QGeoCoordinate transToCoor(const mavlink_mission_item_int_t &item)
{
    QGeoCoordinate ret;
    ret.setLatitude(item.x / 1e7);
    ret.setLongitude(item.y / 1e7);
    ret.setAltitude(item.z / 1e3);

    return ret;
}

static QMap<QString, QVariant> &getParams()
{
    static QMap<QString, QVariant> sParams;
    if (sParams.size() == 0)
    {
        sParams[NAMEPARAMUAVID] = QVariant::fromValue<unsigned>(0x20);
        sParams[CLOUDHOSTID] = QVariant::fromValue<unsigned>(0x7f000001/*0x7f000001;0x792947B8;0x65C837AF*/);
        sParams[CLOUDPORTID] = QVariant::fromValue<unsigned>(8198);
        sParams[MPC_ALT_MODE] = QVariant::fromValue<int>(0);
    }
    return sParams;
}

static bool EncodeParameter(mavlink_message_t &msg, const QString &key, const QVariant &v)
{
    if (key.isEmpty() || v.isNull())
        return false;

    MAV_PARAM_TYPE type;
    float pTmp;
    switch (v.type())
    {
    case QVariant::Bool:
        type = MAV_PARAM_TYPE_UINT8;
        pTmp = v.toBool();
        break;
    case QVariant::Char:
        type = MAV_PARAM_TYPE_INT8;
        *(QChar*)&pTmp = v.toChar();
        break;
    case QVariant::UInt:
        type = MAV_PARAM_TYPE_UINT32;
        *(unsigned*)&pTmp = v.toUInt();
        break;
    case QVariant::Int:
        type = MAV_PARAM_TYPE_INT32;
        *(int*)&pTmp = v.toInt();
        break;
    case QVariant::Double:
    case QMetaType::Float:
        type = MAV_PARAM_TYPE_REAL32;
        pTmp = v.toDouble();
        break;
    default:
        return false;
    }
    mavlink_msg_param_value_pack_chan(0, 0, 0, &msg, key.toUtf8().data(), pTmp, type, 0, 0);
    return true;
}

static QString DecodeParameter(const mavlink_message_t &msg, QVariant &v)
{
    if (msg.msgid != MAVLINK_MSG_ID_PARAM_SET)
        return QString();

    mavlink_param_set_t rawValue;
    mavlink_msg_param_set_decode(&msg, &rawValue);
    mavlink_param_union_t paramVal;
    paramVal.param_float = rawValue.param_value;
    paramVal.type = rawValue.param_type;

    switch (rawValue.param_type)
    {
    case MAV_PARAM_TYPE_REAL32:
        v.setValue<float>(paramVal.param_float);
        break;
    case MAV_PARAM_TYPE_UINT8:
        v.setValue<uint8_t>(paramVal.param_uint8);
        break;
    case MAV_PARAM_TYPE_INT8:
        v.setValue<int8_t>(paramVal.param_int8);
        break;
    case MAV_PARAM_TYPE_UINT16:
        v.setValue<uint16_t>(paramVal.param_uint16);
        break;
    case MAV_PARAM_TYPE_INT16:
        v.setValue<int16_t>(paramVal.param_int16);
        break;
    case MAV_PARAM_TYPE_UINT32:
        v.setValue<unsigned>(paramVal.param_uint32);
        break;
    case MAV_PARAM_TYPE_INT32:
        v.setValue<int>(paramVal.param_int32);
        break;
    default:
        v = QVariant();
    }

    QByteArray bytes(rawValue.param_id, MAVLINK_MSG_PARAM_VALUE_FIELD_PARAM_ID_LEN);
    return QString::fromUtf8(bytes);
}
/*-----------------------------------------------------------------------
TestCloud
-----------------------------------------------------------------------*/
TestCloud::TestCloud(QWidget *parent): QDialog(parent), m_ui(new Ui::testcloudClass)
, m_countMissions(0), m_idTimer(-1),m_curFly(0), m_routCur(0), m_nLoad(0)
, m_handGps(NULL), m_view(new ViewWidget), m_bArm(false), m_baseMode(1)
, m_customMode(GetModeMap()[Mode_Manual].data)
{
    if(m_ui)
    {
        m_ui->setupUi(this);
        connect(m_ui->btn_ok, &QPushButton::clicked, this, &TestCloud::onBtnOk);
        connect(m_ui->btn_view, &QPushButton::clicked, this, &TestCloud::onBtnView);
        connect(m_ui->listWidget, &QListWidget::currentRowChanged, this, &TestCloud::onSelectedItem);
    }
    if (m_view)
        connect(m_view, &ViewWidget::rtlCal, this, &TestCloud::onTtlCal);
    m_home.setLatitude(m_ui->edit_lat->text().toDouble());
    m_home.setLongitude(m_ui->edit_lon->text().toDouble());
    m_home.setAltitude(m_ui->edit_alt->text().toDouble());
    m_idTimer = startTimer(500);
}

void TestCloud::onRecvMavlink(const mavlink_message_t &msg)
{
    switch (msg.msgid)
    {
    case MAVLINK_MSG_ID_MISSION_COUNT:
        prcsMissionCount(msg); break;
    case MAVLINK_MSG_ID_MISSION_ITEM_INT:
        prcsMissionItem(msg); break;
    case MAVLINK_MSG_ID_PARAM_REQUEST_READ:
        prcsParamRead(msg); break;
    case MAVLINK_MSG_ID_PARAM_SET:
        prcsParamSet(msg); break;
    case MAVLINK_MSG_ID_SET_MODE:
        prcsSetMode(msg); break;
    case MAVLINK_MSG_ID_COMMAND_LONG:
    case MAVLINK_MSG_ID_COMMAND_INT:
        prcsMavCommand(msg); break;
    case MAVLINK_MSG_ID_MISSION_REQUEST_INT:
    case MAVLINK_MSG_ID_MISSION_REQUEST:
        prcsMissionRequest(msg); break;
    default:
        break;
    }
}

void TestCloud::onBtnOk()
{
    m_home.setLatitude(m_ui->edit_lat->text().toDouble());
    m_home.setLongitude(m_ui->edit_lon->text().toDouble());
    m_home.setAltitude(m_ui->edit_alt->text().toDouble());
    
    _sendGps();
    sendHome();
}

void TestCloud::onBtnView()
{
    if (m_view)
    {
        if (m_view->isVisible())
        {
            m_ui->btn_view->setText("&View");
            m_view->hide();
        }
        else
        {
            m_ui->btn_view->setText("&Hide");
            m_view->setGeometry(pos().x(), pos().y(), 800, 600);
            m_view->show();
        }
    }
}

void TestCloud::onSelectedItem(int index)
{
    if (index >= 0 && index < m_missionItems.count())
    {
        const mavlink_mission_item_int_t &item = m_missionItems.at(index);
        m_ui->edit_auto->setText(item.autocontinue ? "true" : "false");
        m_ui->edit_frame->setText(QString::number(item.frame));
        m_ui->edit_mtype->setText(QString::number(item.command));

        m_ui->edit_mlat->setText(QString::number(double(item.x) / 1e7, 'f', 7));
        m_ui->edit_mlon->setText(QString::number(double(item.y) / 1e7, 'f', 7));
        m_ui->edit_malt->setText(QString::number(double(item.z), 'f', 2));
        m_ui->edit_param1->setText(QString::number(item.param1, 'g', 4));
        m_ui->edit_param2->setText(QString::number(item.param2, 'g', 4));
        m_ui->edit_param3->setText(QString::number(item.param3, 'g', 4));
        m_ui->edit_param4->setText(QString::number(item.param4, 'g', 4));
    }
}

void TestCloud::timerEvent(QTimerEvent *e)
{
    if (e->timerId() != m_idTimer)
        return QDialog::timerEvent(e);

    QGeoCoordinate coor = checkPos();
    mavlink_gps_raw_int_t gpsRawInt = { 0 };
    gpsRawInt.lat = coor.latitude()*1e7;
    gpsRawInt.lon = coor.longitude()*1e7;
    gpsRawInt.alt = coor.altitude()*1e3;
    gpsRawInt.satellites_visible = m_ui->edit_sat->text().toInt();
    gpsRawInt.fix_type = m_ui->edit_type->text().toInt();
    mavlink_message_t msg;
    mavlink_msg_gps_raw_int_encode(0, 0, &msg, &gpsRawInt);
    CloudLink::SendMavLink(msg);
    mavlink_msg_mission_current_pack(0, 0, &msg, m_curFly);
    CloudLink::SendMavLink(msg);
    mavlink_msg_sys_status_pack(0, 0, &msg, 0, 1, 1, 1, 48000, 100, 100, 0, 0, 0, 0, 0, 0);
    CloudLink::SendMavLink(msg);
    sendHeartbeat();
}

void TestCloud::onTtlCal(const VGPoint &beg, const VGPoint &end)
{
    mission_rtl_path_point_s it1 = { 0 };
    mission_rtl_path_point_s it2 = { 0 };
    sSafeRoute.TansferGeoFromXY(beg, it1.lat, it1.lon);
    sSafeRoute.TansferGeoFromXY(end, it2.lat, it2.lon);
    sSafeRoute.GenPropBreakPos(it1.lat, it1.lon);
    sSafeRoute.GenPropBreakPos(it2.lat, it2.lon);
    if (sSafeRoute.GenerateSafeRoute(it1, it2))
    {
        m_view->AddPolyline(sSafeRoute.GetRoute(), 0);
        int nCount = sSafeRoute.GetRouteCount();
        if (nCount > 0)
        {
            mavlink_mission_count_t msCount = {0};
            msCount.mission_type = 4;
            msCount.count = nCount;
            mavlink_message_t msg;
            mavlink_msg_mission_count_encode(0, 0, &msg, &msCount);
            CloudLink::SendMavLink(msg);
        }
    }
}

QGeoCoordinate TestCloud::checkPos()
{
    if (!m_bArm)
        return m_home;

    if (m_curFly < 0)
        m_curFly = 0;

    QGeoCoordinate beg = m_curFly < 1 ? m_home : transToCoor(m_missionItems.at(m_curFly - 1));
    if (m_suspend.isValid())
        beg = m_suspend;

    QGeoCoordinate end = m_return.isValid() ? m_return : m_home;
    if (m_suspend.isValid())
        beg = m_suspend;
    else if (m_curFly+1 < m_missionItems.size())
        end = transToCoor(m_missionItems.at(m_curFly));

    if (m_curFly+1 >= m_missionItems.size())
    {
        m_customMode = GetModeMap()[Mode_Return].data;
        m_suspend = QGeoCoordinate();
        m_return = QGeoCoordinate();
        m_curFly = 0;
        return end;
    }
    else if(m_curFly >= m_missionItems.size())
    {
        m_bArm = false;
        m_customMode = GetModeMap()[Mode_Landing].data;
        return m_home;
    }

    double per = (m_routCur+= 2.5) / beg.distanceTo(end);
    if (per < 1)
        return getViaPos(beg, end, per);

    if (m_suspend.isValid())
        m_suspend = QGeoCoordinate();
    else if (m_curFly + 1 < m_missionItems.size() || !m_return.isValid())
        m_curFly++;
    m_routCur = 0;

    return end;
}

void TestCloud::sentGpsOrb(const mavlink_gps_raw_int_t &gps)
{
    vehicle_gps_position_s gpsOrb = { 0 };
    gpsOrb.lat = gps.lat;
    gpsOrb.lon = gps.lon;
    gpsOrb.fix_type = (gps.fix_type >> 6) & 0x03;

    if (!m_handGps)
        m_handGps = orb_advertise(ORB_ID(vehicle_gps_position), &gpsOrb);
    else
        orb_publish(ORB_ID(vehicle_gps_position), m_handGps, &gpsOrb);
}

void TestCloud::_sendGps()
{
    mavlink_gps_raw_int_t gpsRawInt = { 0 };
    mavlink_message_t msg;
    gpsRawInt.lat = m_home.latitude()*1e7;
    gpsRawInt.lon = m_home.longitude()*1e7;
    gpsRawInt.alt = m_home.altitude()*1e3;
    gpsRawInt.h_acc = 100;
    gpsRawInt.satellites_visible = m_ui->edit_sat->text().toInt();
    gpsRawInt.fix_type = m_ui->edit_type->text().toInt();
    mavlink_msg_gps_raw_int_encode(0, 0, &msg, &gpsRawInt);
    CloudLink::SendMavLink(msg);
    sentGpsOrb(gpsRawInt);

    mavlink_altitude_t altitude = { 0 };
    altitude.bottom_clearance = 3.4 + (rand() % 10) / 10.0;
    mavlink_msg_altitude_encode(0, 0, &msg, &altitude);
    CloudLink::SendMavLink(msg);
}

void TestCloud::_arm(bool b)
{
    m_bArm = b;
    mavlink_message_t msg;
    mavlink_msg_viga_event_pack(0, 0, &msg, b ? 1 : 2);
    CloudLink::SendMavLink(msg);
}

void TestCloud::sendHome()
{
    mavlink_message_t msg;
    int lat = m_home.latitude()*1e7;
    int lon = m_home.longitude()*1e7;
    int alt = m_home.altitude()*1e3;
    mavlink_msg_home_position_pack(0, 0, &msg, lat, lon,
        alt, 0, 0, 0, NULL, 0, 0, 0, QDateTime::currentMSecsSinceEpoch());
    CloudLink::SendMavLink(msg);
}

void TestCloud::sendHeartbeat()
{
    mavlink_message_t msgEn;
    mavlink_msg_heartbeat_pack_chan(0, 0, 0, &msgEn, 0, 1, m_baseMode, m_customMode, m_bArm ? MAV_STATE_ACTIVE : MAV_STATE_STANDBY);
    CloudLink::SendMavLink(msgEn);
}

void TestCloud::_sendAssist()
{
    mavlink_assist_position_t supports = {0};
    if (m_enter.isValid())
    {
        supports.assist_state |= 1;
        supports.start_latitude = m_enter.latitude() * 1e7;
        supports.start_longitude = m_enter.longitude() * 1e7;
        supports.start_altitude = m_enter.longitude() * 1e3;
    }
    if (m_return.isValid())
    {
        supports.assist_state |= 2;
        supports.end_latitude = m_return.latitude() * 1e7;
        supports.end_longitude = m_return.longitude() * 1e7;
        supports.end_altitude = m_return.longitude() * 1e3;
    }
    if (m_suspend.isValid())
    {
        supports.assist_state |= 4;
        supports.int_latitude = m_suspend.latitude() * 1e7;
        supports.int_longitude = m_suspend.longitude() * 1e7;
        supports.int_altitude = m_suspend.longitude() * 1e3;
    }
    mavlink_message_t msg;
    mavlink_msg_assist_position_encode(0, 0, &msg, &supports);
    CloudLink::SendMavLink(msg);
}

void TestCloud::prcsMissionCount(const mavlink_message_t &msg)
{
    mavlink_mission_count_t msCount;
    mavlink_msg_mission_count_decode(&msg, &msCount);
    m_countMissions = msCount.count;
    reqMission(0, msCount.mission_type);
    m_nLoad = 0;
    if (msCount.mission_type == MAV_MISSION_TYPE_MISSION)
    {
        m_ui->listWidget->clear();
        m_missionItems.clear();
        m_ui->listWidget->setCurrentRow(-1);
    }
    else if (msCount.mission_type == MAV_MISSION_TYPE_OBSTACLE)
    {
        static int n = 1;
        sSafeRoute.InitReadBoudary(n++);
    }
    m_nLoad = 0;
}

void TestCloud::prcsMissionItem(const mavlink_message_t &msg)
{
    mavlink_mission_item_int_t item;
    mavlink_msg_mission_item_int_decode(&msg, &item);
    if (item.seq != m_nLoad)
        return;

    m_nLoad++;
    if (item.mission_type == MAV_MISSION_TYPE_MISSION)
    {
        m_ui->listWidget->addItem(QString::number(item.seq));
        m_missionItems.append(item);
    }
    else if (item.mission_type == MAV_MISSION_TYPE_OBSTACLE)
    {
        mission_obstacle_point_s pnt;
        pnt.lat = item.x / 1e7;
        pnt.lon = item.y / 1e7;
        pnt.alt = item.z / 1e3;
        pnt.ob_num = item.param2;
        pnt.point_num = item.param3;
        sSafeRoute.AddBoudary(pnt);
    }
    reqMission(item.seq + 1, item.mission_type);
}

void TestCloud::prcsParamRead(const mavlink_message_t &msg)
{
    mavlink_param_request_read_t read;
    mavlink_msg_param_request_read_decode(&msg, &read);
    sendParam(read.param_id);
}

void TestCloud::prcsParamSet(const mavlink_message_t &msg)
{
    QVariant var;
    QString id = DecodeParameter(msg, var);
    if (!id.isEmpty() && var.isValid())
    {
        getParams()[id] = var;
        sendParam(id.toUtf8().data());
    }
}

void TestCloud::prcsSetMode(const mavlink_message_t &msg)
{
    mavlink_set_mode_t mode;
    mavlink_msg_set_mode_decode(&msg, &mode);
    m_customMode = mode.custom_mode;
    m_baseMode = mode.base_mode;
    if (GetModeMap()[Mode_Return].data == m_customMode)
        returnToL();
    sendCmdAck(MAV_CMD_DO_SET_MODE, true);
    sendHeartbeat();
}

void TestCloud::prcsMavCommand(const mavlink_message_t &msg)
{
    mavlink_command_int_t cmd;
    mavlink_msg_command_int_decode(&msg, &cmd);
    sendCmdAck(cmd.command, true);
    if (cmd.command == MAV_CMD_SET_START_POINT || cmd.command == MAV_CMD_SET_END_POINT)
        setAssist(cmd);
    else if (cmd.command == MAV_CMD_COMPONENT_ARM_DISARM)
        _arm(DoubleEqual(cmd.param1, 1));
}

void TestCloud::prcsMissionRequest(const mavlink_message_t &msg)
{
    mavlink_mission_request_t req;
    mavlink_msg_mission_request_decode(&msg, &req);
    if (int(req.seq) < sSafeRoute.GetRouteCount())
    {
        mission_rtl_path_point_s item = { 0 };
        if (sSafeRoute.GetRouteItem(item, req.seq))
        {
            mavlink_mission_item_int_t msItem = { 0 };
            msItem.seq = req.seq;
            msItem.x = item.lat*1e7;
            msItem.y = item.lon*1e7;
            msItem.command = MAV_CMD_NAV_WAYPOINT;
            msItem.frame = MAV_FRAME_GLOBAL;
            msItem.mission_type = 4;
            mavlink_message_t msgEn = { 0 };
            mavlink_msg_mission_item_int_encode(0, 0, &msgEn, &msItem);
            CloudLink::SendMavLink(msgEn);
        }
    }
}

void TestCloud::setAssist(const mavlink_command_int_t &cmd)
{
    if (DoubleEqual(cmd.param4, 1))
    {
        if (cmd.command == MAV_CMD_SET_START_POINT)
        {
            m_enter.setLatitude(cmd.x / 1e7);
            m_enter.setLongitude(cmd.y / 1e7);
            m_enter.setAltitude(cmd.y / 1e3);
        }
        else if (cmd.command == MAV_CMD_SET_END_POINT)
        {
            m_return.setLatitude(cmd.x / 1e7);
            m_return.setLongitude(cmd.y / 1e7);
            m_return.setAltitude(cmd.y / 1e3);
        }
    }
    else
    {
        if(cmd.command == MAV_CMD_SET_START_POINT)
            m_enter = QGeoCoordinate();
        else if(cmd.command == MAV_CMD_SET_END_POINT)
            m_return = QGeoCoordinate();
    }
    _sendAssist();
}

void TestCloud::reqMission(int req, uint8_t tp)
{
    if (req < m_countMissions)
    {
        mavlink_message_t msg;
        mavlink_msg_mission_request_int_pack(0, 0, &msg, 0, 0, req, tp);
        CloudLink::SendMavLink(msg);
    }
    else if (req == m_countMissions)
    {
        mavlink_message_t msg;
        mavlink_msg_mission_ack_pack(0, 0, &msg, 0, 0, MAV_MISSION_ACCEPTED, tp);
        CloudLink::SendMavLink(msg);
        if (tp== MAV_MISSION_TYPE_OBSTACLE)
        {
            m_view->Clear();
            m_view->AddPolygon(sSafeRoute.GetOutline(), 0);
            for (int i=0; i<sSafeRoute.CountBlocks(); ++i)
            {
                m_view->AddPolygon(*sSafeRoute.GetBlock(i), 1);
            }
        }
    }
}

void TestCloud::sendParam(const char *id)
{
    if (!id)
        return;

    QMap<QString, QVariant>::iterator itr = getParams().find(id);
    QVariant var = 1;
    if (itr != getParams().end())
        var = itr.value();

    mavlink_message_t msg;
    if (EncodeParameter(msg, id, var))
        CloudLink::SendMavLink(msg);
}

void TestCloud::sendCmdAck(uint32_t cmd, bool res)
{
    mavlink_message_t msg;
    mavlink_msg_command_ack_pack(0, 0, &msg, cmd, res ? MAV_RESULT_ACCEPTED : MAV_RESULT_DENIED, 0, 0, 0, 0);
    CloudLink::SendMavLink(msg);
    if (MAV_CMD_GET_HOME_POSITION == cmd)
        sendHome();
    else if (MAV_CMD_COMPONENT_ARM_DISARM == cmd)
        m_routCur = 0;
}

void TestCloud::returnToL()
{
    if (m_routCur >= 0 && m_curFly + 1 < m_missionItems.size())
    {
        m_suspend = checkPos();
        _sendAssist();
    }
}

void TestCloud::testRTL(double lat, double lon, double latEnd, double lonEnd)
{
    mission_rtl_path_point_s it1;
    it1.alt = 0;
    it1.lat = lat;
    it1.lon = lon;
    mission_rtl_path_point_s it2;
    it2.alt = 0;
    it2.lat = latEnd;
    it2.lon = lonEnd;
    sSafeRoute.GenerateSafeRoute(it1, it2);
}
