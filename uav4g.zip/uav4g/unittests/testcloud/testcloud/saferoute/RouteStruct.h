﻿#ifndef __R_STRUCT_H__
#define __R_STRUCT_H__

#include <vector>

#define  DoubleEqual(x, y) ((int)(((x) - (y)) * 0x00100000) == 0)
#define  DoubleLess(x, y) ((int)(((x) - (y)) * 0x00100000) < 0)

class VGVertex;
class VGPolyLine;
class VGPolygon;
class RoutePlanning;
class VGLine;

class  VGPoint
{
public:
    VGPoint(double x=0xffffffffffffffff, double y=0, double z=0);
    VGPoint(const VGPoint &oth);
    double &X();
    double &Y();
    double &Z();
    double GetX()const;
    double GetY()const;
    double GetZ()const;
    double DistanceTo(const VGPoint &oth)const;
    double DistanceSqureTo(const VGPoint &oth)const;
    bool IsValid()const;
    VGPoint operator-(const VGPoint &oth)const;
    VGPoint &operator-=(const VGPoint &oth);
    VGPoint operator+(const VGPoint &oth)const;
    VGPoint &operator+=(const VGPoint &oth);
    VGPoint operator-(const VGVertex &oth)const;
    VGPoint &operator-=(const VGVertex &oth);
    VGPoint operator+(const VGVertex &oth)const;
    VGPoint &operator+=(const VGVertex &oth);
    VGPoint operator*(double f)const;
    VGPoint &operator*=(double f);
    VGPoint operator/(double f)const;
    VGPoint &operator/=(double f);
    bool operator==(const VGPoint &oth)const;
    bool operator!=(const VGPoint &oth)const;
private:
    double m_x;
    double m_y;
    double m_z;
};

class  VGVertex  //向量
{
public:
    VGVertex(double x=0, double y=0, double z=0);
    VGVertex(bool b2d, double angleY, double angleXY = 0);
    VGVertex(const VGPoint &beg, const VGPoint &end);
    VGVertex(const VGVertex &oth);

    double &X();
    double &Y();
    double &Z();
    double GetX()const;
    double GetY()const;
    double GetZ()const;
    VGVertex operator-(const VGVertex &oth)const;
    VGVertex &operator-=(const VGVertex &oth);
    VGVertex operator+(const VGVertex &oth)const;
    VGVertex &operator+=(const VGVertex &oth);
    VGVertex operator*(double f)const;
    VGVertex &operator*=(double f);
    VGVertex operator/(double f)const;
    VGVertex &operator/=(double f);
    VGVertex CrossMultiply(const VGVertex &v = VGVertex(0.0, 0, 1))const;
    double  DotMultiply(const VGVertex &v)const;
    bool    IsValid()const;
    bool    operator==(const VGVertex &oth)const;
    bool    operator!=(const VGVertex &oth)const;
    double  UnitLength()const;
    double  UnitLengthSquare()const;
	VGVertex UnitVertex()const;
	double CrossX(const VGVertex &v = VGVertex(0.0, 0, 1))const;
	double CrossY(const VGVertex &v = VGVertex(0.0, 0, 1))const;
	double CrossZ(const VGVertex &v = VGVertex(0.0, 0, 1))const;
private:
    double m_x;
    double m_y;
    double m_z;
};

class VGSinAngle //(--360)
{
public:
    VGSinAngle(const VGPoint &pnt1, const VGPoint &pnt2, const VGPoint &pnt3);
    VGSinAngle(const VGVertex &v1, const VGVertex &v2);
    VGSinAngle(const VGLine &line, const VGPoint &pnt);
    VGSinAngle();

    double GetSinAngle()const;
    bool   IsAcute()const;
    double GetCos()const;
    bool   IsZero()const;

    bool        operator==(const VGSinAngle &oth)const;
    bool        operator!=(const VGSinAngle &oth)const;
    bool        operator<(const VGSinAngle &oth)const;
    bool        operator>(const VGSinAngle &oth)const;
    VGSinAngle  operator+(const VGSinAngle &oth)const;
    VGSinAngle  operator-(const VGSinAngle &oth)const; 
    VGSinAngle  TranceTriAngle()const;
private:
    double  _calculateSin(const VGLine &line, const VGPoint &pnt);
    double  _calculateCos(const VGLine &line, const VGPoint &pnt);
private:
    double  m_sin;
    double  m_cos;
};

class  VGSinAngleArea
{
public:
    VGSinAngleArea(const VGSinAngle &an = VGSinAngle());
    bool IsValid()const;
    bool Contains(const VGSinAngle &an)const;
    int AdjustByContains(const VGSinAngle &an);
    const VGSinAngle &GetBegin()const;
    const VGSinAngle &GetEnd()const;
private:
    VGSinAngle   m_angleBeg;
    VGSinAngle   m_angleEnd;
};

class VGLineSeg
{
public:
    VGLineSeg(const VGPoint &beg = VGPoint(0), const VGPoint &end = VGPoint(0));
    VGLineSeg(const VGLineSeg &oth);
    double Length()const;
    double LengthSqure()const;
    VGPoint NearestPoint(const VGPoint &point)const; //线段上离point最近点
    double NearestDistance(const VGPoint &point)const; //线段上离point最近点
    VGVertex GetVertex();
    VGPoint GetBegin()const;
    VGPoint GetEnd()const;
    VGPoint GetMid()const;
    VGVertex GetVertex()const;
    bool IsValid()const;
    VGPoint GetPoint(double t)const;
    double GetParam(const VGPoint &point)const;
    bool IsOnSeg(const VGPoint &point)const;
    VGLine GetRectLineFrom(const VGPoint &pnt, const VGVertex &vC= VGVertex(0.0,0,1.0))const;
private:
    VGPoint m_beg;
    VGPoint m_end;
};

class VGLine
{
public:
    class tag_Ponit
    {
    public:
        double dis;
        VGPoint pnt;
        tag_Ponit() : dis(0), pnt()
        {
        }
        tag_Ponit(double d, const VGPoint &p):dis(d), pnt(p)
        {
        }
    };
public:
    VGLine(const VGPoint &beg, const VGPoint &end);
    VGLine(const VGVertex &v, const VGPoint &pnt=VGPoint(0));
    VGLine(const VGLineSeg &v);
    VGLine(const VGLine &oth);
    VGLine();
    VGPoint GetOnePoint()const;
    void SetOnePoint(const VGPoint &p);
    VGVertex &Vertex();
    VGVertex GetVertex()const;
    void SetVertex(const VGVertex &v);
    std::vector<VGPoint> IntersectionsXY(const VGLineSeg &seg)const;//z=0投影交点
    std::vector<VGPoint> IntersectionsXY(const VGLine &oth)const;//z=0投影交点
    std::vector<tag_Ponit> IntersectionsXY(const VGPolygon &plg)const;
    double DistanceToPoint(const VGPoint &pnt)const;
    VGLine GetRectLineFrom(const VGPoint &pnt)const;
    VGPoint GetDistancePoint(const VGPoint &pnt, double dis)const;
    VGPoint RectPoint(const VGPoint &point)const;//垂直点
    VGPoint GetPoint(double t)const;
    double GetParam(const VGPoint &point)const;
    bool   IsOnLine(const VGPoint &poin)const;
    bool   operator==(const VGLine &oth)const;
    bool   operator!=(const VGLine &oth)const;
private:
    VGVertex    m_vertex;
    VGPoint     m_piont;
};

class VGPolyLine
{
public:
    VGPolyLine(const std::vector<VGPoint> &points = std::vector<VGPoint>());
    VGPolyLine(const VGPolyLine &oth);
    virtual ~VGPolyLine() {}

    double Length()const;
    VGLineSeg LineSegAt(int idx)const;
    int CountLineSeg()const;
    int CountPoint()const;
    void AddFrontPoint(const VGPoint &pnt);
    void AddRoutePoint(const VGPoint &pnt);
    void CalculateNearerWay(const VGPoint &pnt, const std::vector<VGPolygon> &, const VGPolygon &);
    void CalculateNearerWayFront(const VGPoint &pnt, const std::vector<VGPolygon> &);
    bool CutBeging(const VGPoint &pnt);
    void Clear();
    const VGPoint &First()const;
    const VGPoint &Last()const;
    VGPolyLine Revert()const;
    void RemoveAt(int i);
    bool Replace(const VGPoint &pnt, int i = -1);
    const std::vector<VGPoint> &RoutePoints()const;
protected:
    void _setPoint(int idx, const VGPoint &pnt);
private:
    std::vector<VGPoint> m_points;
};

class VGPolygon
{
protected:
    typedef struct EdgeChange {
        int index;
        double edgeShrink;
        EdgeChange(int idx, double p) :index(idx), edgeShrink(p) {}
    }EdgeChange;
public:
     VGPolygon();
     VGPolygon(const VGPolygon &oth);
     virtual ~VGPolygon(){}
     void SetPoint(double x, double y, double z=0, int idx=-1);
     void Clear();
     VGPoint GetCenter(bool bAverage=true)const;//bAverage, true平均位置, false 重心
     double CalculatePolygonArea()const;
     int CountLineSeg()const;
     const std::vector<VGPoint> &Points()const;

    double Length()const;
    VGLineSeg LineSegAt(int idx)const;
    bool IsValid()const;
    void SetPoint(const VGPoint &pnt, int idx=-1);
    void Remove(int idx);
    bool IsContains(const VGPoint &pnt, bool bContainsOnBoard = true)const;
    bool IsContains(const VGLineSeg &seg)const;
    bool IsContains(const VGPolyLine &pl, bool bContainsOnBoard = true)const;
    void GetTipPoint(const VGVertex &v, VGPoint &pntMin, VGPoint &pntMax);
    double NearestDistance(const VGPoint &pnt)const;
    VGPoint NearestPoint(const VGPoint &pnt, double dis=0.1)const;
    double Distance2LineSeg(const VGLineSeg &seg)const;//ret>0, 不相交
    std::vector<VGPoint> GetCornerPoint(const VGPoint &pnt1, const VGPoint &pnt2, const VGPolygon &outLine=VGPolygon())const;
    bool IsIntersect(const VGLine &line, bool bSkipByBord = true)const;
    bool IsSegOut(const VGLineSeg &se)const;
    bool RoundRoute(const VGPoint &pnt1, const VGPoint &pnt2, VGPolyLine &rt)const;
protected:
    bool _findRoundPnt(const VGPoint &pnt1, const VGPoint &pnt2, const VGPolygon &outLine, VGPoint &pnt)const;
    int _getOnBoarder(const VGPoint &pnt)const;
    int _getLongestLineSegIndex()const;
    bool _getRoundRoute(const VGPoint &pnt1, const VGPoint &pnt2, VGPolyLine &rt1, VGPolyLine &rt2)const;
protected:
    std::vector<VGPoint> m_points;
};

#endif //
