﻿#include "RouteStruct.h"
#include <math.h>
#include "SafeRoute.h"

using namespace std;

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#define EARTH_RADIOS 6367558.49686
/*
tansferGeoToXY tansferGeoFromXY是简单的经纬，直角坐标对应逆函数，是不准确的，
x=(lon-baseLon)*pi*r*cos(baseLat)/180才比较准确，这里需要的只是坐标转换且可逆就可以了
*/
static void tansferGeoToXY(const mission_rtl_path_point_s &base, double lat, double lon, VGPoint &pnt)
{
    pnt.X() = ((lon - base.lon)*M_PI*EARTH_RADIOS/180);
    pnt.Y() = ((lat - base.lat)*M_PI*EARTH_RADIOS/180);
}

static void tansferGeoFromXY(const mission_rtl_path_point_s &base, const VGPoint &pnt, double &lat, double &lon)
{
    lat = base.lat + pnt.GetY() * 180 / (M_PI*EARTH_RADIOS);
    lon = base.lon + pnt.GetX() * 180 / (M_PI*EARTH_RADIOS);
}
///////////////////////////////////////////////////////////////////////////////////
//PolygonDis
///////////////////////////////////////////////////////////////////////////////////
class PolygonDis
{
public:
    double dis;
    const VGPolygon *plg;
    PolygonDis() :dis(0), plg(NULL)
    {}
    PolygonDis(double d, const VGPolygon *p):dis(d), plg(p)
    {}
};
///////////////////////////////////////////////////////////////////////////////////
//SafeRouteData
///////////////////////////////////////////////////////////////////////////////////
class SafeRouteData {
public:
    SafeRouteData() :m_nNumb(0), m_initBase(false)
    {
    }
    bool InitReadBoudary(unsigned numb)
    {
        if (numb <= 0 || m_nNumb == numb)
            return true;

        m_nNumb = numb;
        m_route.Clear();
        m_outline.Clear();
        m_expBlocks.clear();
        m_initBase = false;
        return false;
    }
    void AddBoudary(const mission_obstacle_point_s &item)
    {
        if (!m_initBase)
        {
            m_firstGeo.lat = item.lat;
            m_firstGeo.lon = item.lon;
            m_firstGeo.alt = 0;
            m_initBase = true;
        }
        if (item.ob_num == m_expBlocks.size())
            m_expBlocks.push_back(VGPolygon());
        else if (item.ob_num != m_expBlocks.size() - 1)
            return;

        VGPoint pnt;
        tansferGeoToXY(m_firstGeo, item.lat, item.lon, pnt);
        if (0 == item.ob_num)
            m_outline.SetPoint(pnt, item.point_num);
        else
            m_expBlocks[item.ob_num].SetPoint(pnt, item.point_num);
    }
    bool GenerateSafeRoute(const mission_rtl_path_point_s &vPos, const mission_rtl_path_point_s &home)
    {
        m_route.Clear();
        if (m_expBlocks.size() == 0 || !m_initBase || m_outline.CountLineSeg()<=0)
            return false;

        bool bChageEnd = false;
        bool bRet = false;
        VGPoint pntChange;
        VGPoint pntBeg;
        VGPoint pntEnd;
        tansferGeoToXY(m_firstGeo, vPos.lat, vPos.lon, pntBeg);
        tansferGeoToXY(m_firstGeo, home.lat, home.lon, pntEnd);
        VGPoint via = _getPropertyViaPnt(pntBeg, pntEnd);
        VGPoint pntLast;

        if (m_outline.IsContains(pntBeg))
        {
            pntChange = pntEnd;
            bChageEnd = true;
            pntEnd = via;
        }
        else if (m_outline.IsContains(pntEnd))
        {
            pntChange = pntBeg;
            pntBeg = via;
        }
        else
        {
            return false;
        }
        
        pntLast = pntBeg;
        int res;
        for (int i = 0; i < 64; i++)
        {
            res = _getSafeRoute(pntBeg, pntEnd, m_route, pntLast);
            if (res<0)
                return false;
            if (res > 0)
            {
                bRet = true;
                break;
            }

            pntBeg = pntLast;
        }
        if (bRet && via!=pntChange)
        {
            if (bChageEnd)
                m_route.CalculateNearerWay(pntChange, m_expBlocks, VGPolygon());
            else
                m_route.CalculateNearerWayFront(pntChange, m_expBlocks);
        }
        return bRet;
    }
    bool GetRouteItem(int idx, double &lat, double &lon)
    {
        if (!m_initBase || idx < 0 || idx >= m_route.CountPoint())
            return false;

        const VGPoint &pnt = m_route.RoutePoints()[idx];
        tansferGeoFromXY(m_firstGeo, pnt, lat, lon);
        return true;
    }
    int GetRouteCount()const
    {
        return m_route.CountPoint();
    }
	void ClearRoute()
	{
        m_route.Clear();
	}
    void GenPropBreakPos(double &lat, double &lon)
    {
        if (!m_initBase)
            return;
        VGPoint pnt;
        tansferGeoToXY(m_firstGeo, lat, lon, pnt);
        VGPoint gen;
        if (!m_outline.IsContains(pnt))
        {
            gen = m_outline.NearestPoint(pnt);
        }
        else
        {
            for (const VGPolygon &plg : m_expBlocks)
            {
                if (plg.IsContains(pnt))
                {
                    gen = plg.NearestPoint(pnt);
                    break;
                }
            }
        }
        if (gen.IsValid())
            tansferGeoFromXY(m_firstGeo, gen, lat, lon);
    }
#if defined _WIN32 || defined WIN64
    const VGPolygon &GetOutline()const
    {
        return m_outline;
    }
    const VGPolyLine &GetRoute()const
    {
        return m_route;
    }
    const vector<VGPolygon> &GetBlocks()const
    {
        return m_expBlocks;
    }
    const mission_rtl_path_point_s &GetHome()const
    {
        return m_firstGeo;
    }
#endif //defined _WIN32 || defined WIN64
private:
	VGPoint _getPropertyCorner(const VGPoint &end, const VGPoint &cur, const vector<VGPoint> &pnts)
	{
		if (pnts.size() == 0)
			return VGPoint(0);

		double t = -1;
		VGPoint ret;
		for (const VGPoint &itr : pnts)
		{
			if (t < 0)
			{
				t = end.DistanceTo(itr) + cur.DistanceTo(itr);
				ret = itr;
				continue;
			}

			double tmp = end.DistanceTo(itr) + cur.DistanceTo(itr);
			if (tmp < t)
			{
				t = tmp;
				ret = itr;
			}
		}
		return ret;
	}
    int _getSafeRoute(const VGPoint &pnt1, const VGPoint &pnt2, VGPolyLine &rt, VGPoint &last)
    {
        if (m_outline.IsContains(VGLineSeg(pnt1, pnt2)))
        {
            int nSz = rt.CountPoint();
            if (nSz > 1)
                rt.CalculateNearerWay(pnt1, m_expBlocks, m_outline);
            else
                rt.AddRoutePoint(pnt1);

            vector<PolygonDis> blocks;
            VGLineSeg seg(pnt1, pnt2);
            _blockDistance(blocks, seg);
            nSz = int(blocks.size());
            if (nSz > 0)
            {
                double tmp = blocks.begin()->dis;
                const VGPolygon &plg = *blocks.begin()->plg;
                vector<VGPoint> pnts = plg.GetCornerPoint(pnt1, pnt2, m_outline);
                nSz = int(pnts.size());
                if (nSz == 0)
                    return -1;

                if (pnts.size() == 1)
                {
                    if (pnts.front() == pnt2)
                    {
                        rt.AddRoutePoint(pnt2);
                        return 1;
                    }
                    last = pnts.front();
                    return 0;
                }

                VGPoint pntLast = _getPropertyCorner(pnt1, pnt2, pnts);
                vector<PolygonDis> blocksTmp;
                _blockDistance(blocksTmp, VGLineSeg(pnt1, pntLast));
                if (blocksTmp.size() > 0 && nSz > 1)
                {
                    pntLast = pnts.back();
                    _blockDistance(blocksTmp, VGLineSeg(pnt1, pntLast));
                    if (blocksTmp.size() > 0)
                        pntLast = seg.GetPoint(tmp);
                }
                else if(blocksTmp.size() > 0)
                {
                    pntLast = seg.GetPoint(tmp);
                }

                last = pntLast;
                return 0;
            }
            rt.AddRoutePoint(pnt2);
            return 1;
        }

        if (m_outline.RoundRoute(pnt1, pnt2, rt))
            return -1;

        return 0;
    }
    void _blockDistance(vector<PolygonDis> &blocks, const VGLineSeg &seg)
    {
        VGLine line(seg);
        blocks.clear();
        for (const VGPolygon &plg : m_expBlocks)
        {
            if (!plg.IsIntersect(seg))
                continue;

            for (const VGLine::tag_Ponit &pnt : line.IntersectionsXY(plg))
            {
                if ((pnt.dis > 0 && pnt.dis < 1))
                {
                    vector<PolygonDis>::iterator itr = blocks.begin();
                    for (; itr != blocks.end(); ++itr)
                    {
                        if (pnt.dis < itr->dis)
                            break;
                    }
                    blocks.insert(itr, PolygonDis(pnt.dis, &plg));
                    break;
                }
            }
        }
    }
    VGPoint _getPropertyViaPnt(const VGPoint &beg, const VGPoint &end)
    {
        vector<VGLine::tag_Ponit> tmps = VGLine(beg, end).IntersectionsXY(m_outline);
        for (const VGLine::tag_Ponit &itr : tmps)
        {
            if (itr.dis > 0 && itr.dis < 1)
                return itr.pnt;
        }

        return end;
    }
private:
    unsigned                    m_nNumb;
    bool                        m_initBase;
    mission_rtl_path_point_s    m_firstGeo;
    vector<VGPolygon>           m_expBlocks;
    VGPolygon                   m_outline;
    VGPolyLine                  m_route;
};
///////////////////////////////////////////////////////////////////////////////////
//SafeRoute
///////////////////////////////////////////////////////////////////////////////////
SafeRoute::SafeRoute():m_data(new SafeRouteData)
{
}

SafeRoute::~SafeRoute()
{
    delete m_data;
}

bool SafeRoute::InitReadBoudary(unsigned numb)
{
    if (!m_data)
        return true;

    return m_data->InitReadBoudary(numb);
}

void SafeRoute::AddBoudary(const mission_obstacle_point_s &item)
{
    if (m_data)
        m_data->AddBoudary(item);
}

bool SafeRoute::GenerateSafeRoute(const mission_rtl_path_point_s &vPos, const mission_rtl_path_point_s &home)
{
    if (m_data)
        return m_data->GenerateSafeRoute(vPos, home);

    return false;
}

bool SafeRoute::GetRouteItem(mission_rtl_path_point_s &rt, int idx)
{
    if (m_data)
        return m_data->GetRouteItem(idx, rt.lat, rt.lon);

    return false;
}

int SafeRoute::GetRouteCount()const
{
    if (m_data)
        return m_data->GetRouteCount();
    return 0;
}

void SafeRoute::ClearRoute()
{
    if (m_data)
        return m_data->ClearRoute();
}

void SafeRoute::GenPropBreakPos(double &lat, double &lon)
{
    if (m_data)
        m_data->GenPropBreakPos(lat, lon);
}

#if defined _WIN32 || defined WIN64
const VGPolygon &SafeRoute::GetOutline() const
{
    return m_data->GetOutline();
}

const VGPolyLine &SafeRoute::GetRoute() const
{
    return m_data->GetRoute();
}

int SafeRoute::CountBlocks() const
{
    return m_data->GetBlocks().size();
}

const VGPolygon *SafeRoute::GetBlock(int i) const
{
    if (i>=0 && i<CountBlocks())
        return &m_data->GetBlocks().at(i);

    return NULL;
}

void SafeRoute::TansferGeoToXY(double lat, double lon, VGPoint &pnt)
{
    if (m_data)
        tansferGeoToXY(m_data->GetHome(), lat, lon, pnt);
}

void SafeRoute::TansferGeoFromXY(const VGPoint &pnt, double &lat, double &lon)
{
    if (m_data)
        tansferGeoFromXY(m_data->GetHome(), pnt, lat, lon);
}
#endif //defined _WIN32 || defined WIN64