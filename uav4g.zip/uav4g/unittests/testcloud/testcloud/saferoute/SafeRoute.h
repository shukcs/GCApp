﻿#ifndef __SAFEROUTE_H__
#define __SAFEROUTE_H__

#ifdef _WIN32
struct mission_obstacle_point_s {
    double lat;
    double lon;
    float alt;
    size_t ob_num;
    size_t point_num;
};

struct mission_rtl_path_point_s {
    double lat;
    double lon;
    float alt;
};
#else
#include "navigator.h"
#endif

class SafeRouteData;
class VGPolygon;
class VGPolyLine;
class VGPoint;

class SafeRoute {
public:
    SafeRoute();
    ~SafeRoute();
    bool InitReadBoudary(unsigned numb);
    void AddBoudary(const mission_obstacle_point_s &item);
    bool GenerateSafeRoute(const mission_rtl_path_point_s &vPos, const mission_rtl_path_point_s &home);
    bool GetRouteItem(mission_rtl_path_point_s &rt, int idx);
    int GetRouteCount()const;
	void ClearRoute(void);
    void GenPropBreakPos(double &lat, double &lon);
#if defined _WIN32 || defined WIN64
    const VGPolygon &GetOutline()const;
    const VGPolyLine &GetRoute()const;
    int CountBlocks()const;
    const VGPolygon *GetBlock(int i)const;

    void TansferGeoToXY(double lat, double lon, VGPoint &pnt);
    void TansferGeoFromXY(const VGPoint &pnt, double &lat, double &lon);
#endif // _WIN32 || defined WIN64
private:
    SafeRouteData   *m_data;
};

#endif //
