#ifndef __SYSFUNC_H__
#define __SYSFUNC_H__
#include <stdint.h>
#include <stdio.h>

#if defined(__cplusplus)
extern "C" {
#endif

typedef uint64_t hrt_abstime;

hrt_abstime hrt_absolute_time();
hrt_abstime hrt_elapsed_time(hrt_abstime *t);
void usleep(uint32_t us);
void cmdMsg(const char *file, int line, const char *fmt, ...);
void unexpectLog(FILE *f, char *fmt, ...);

#define  PX4_WARN(fmt, ...)     cmdMsg(NULL, __LINE__, fmt, ##__VA_ARGS__)
#define QXWZ_NTRIP_INFO(fmt, ...)	cmdMsg(NULL, __LINE__, fmt, ##__VA_ARGS__)
#define QXWZ_NTRIP_WARN(fmt, ...)	cmdMsg(NULL, __LINE__, fmt, ##__VA_ARGS__)
#define QXWZ_NTRIP_DEBUG(fmt, ...)	cmdMsg(NULL, __LINE__, fmt, ##__VA_ARGS__)

#ifdef __cplusplus
#  define __BEGIN_DECLS		extern "C" {
#  define __END_DECLS		}
#else
#  define __BEGIN_DECLS
#  define __END_DECLS
#endif

#if defined(__cplusplus)
}
#endif

#endif // !__SYSFUNC_H__

